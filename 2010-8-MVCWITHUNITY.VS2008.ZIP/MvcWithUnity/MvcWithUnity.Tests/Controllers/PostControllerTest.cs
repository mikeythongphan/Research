﻿// ReSharper disable InconsistentNaming
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MvcWithUnity.BlogEngine.Model;
using MvcWithUnity.BlogEngine.Services;
using MvcWithUnity.Controllers;
using Rhino.Mocks;

namespace MvcWithUnity.Tests.Controllers
{
    [TestClass]
    public class PostControllerTest
    {
        private IBlogPostService blogPostService;
        private ControllerContext controllerContext;
        private readonly IBlogPost[] EmptyList = new IBlogPost[0];
        private const string SlugOfNonExistingPost = "MISSING";
        private const string SlugOfExistingPost = "EXISTS";

        [TestInitialize]
        public void Setup()
        {
            blogPostService = MockRepository.GenerateStub<IBlogPostService>();
            
            controllerContext = new ControllerContext();
            controllerContext.RouteData.Values.Add("year", "2009");
            controllerContext.RouteData.Values.Add("month", "10");
            controllerContext.RouteData.Values.Add("day", "10");
        }

        [TestMethod]
        public void Post_PostExists_ReturnsResultWithPostAsModel()
        {
            controllerContext.RouteData.Values.Add("slug", SlugOfExistingPost);

            var expected = new BlogPost("title", SlugOfExistingPost, "body", new DateTime(2009, 10, 10));
            var blogPosts = new[] {expected};
            blogPostService.Expect(s => s.GetPosts())
                           .Repeat.AtLeastOnce()
                           .Return(blogPosts);
            var controller = CreateController();

            var result = (ViewResult) controller.Post();
            Assert.AreEqual(expected, result.ViewData.Model);
        }

        [TestMethod]
        public void Post_PostDoesNotExist_RedirectsToNotFound()
        {
            controllerContext.RouteData.Values.Add("slug", SlugOfNonExistingPost);

            blogPostService.Expect(s => s.GetPosts())
                .Repeat.AtLeastOnce()
                .Return(EmptyList);

            var httpContext = MockRepository.GenerateStub<HttpContextBase>();
            controllerContext.RequestContext = new RequestContext(
                httpContext, controllerContext.RouteData);
            httpContext.Expect(c => c.Request.Url)
                .Repeat.AtLeastOnce()
                .Return(new Uri("http://localhost/"));
            var controller = CreateController();

            var result = (ViewResult) controller.Post();
            Assert.AreEqual("NotFound", result.ViewName);
        }

        [TestMethod]
        public void Index_WhenCalled_ViewModelIsPostCollection()
        {
            var model = MockRepository.GenerateStub<IEnumerable<IBlogPost>>();
            blogPostService.Expect(s => s.GetPosts())
                .Repeat.AtLeastOnce()
                .Return(model);
            var controller = new PostController(blogPostService);

            var result = (ViewResult) controller.Index();
            Assert.AreEqual(model, result.ViewData.Model);
        }

        private PostController CreateController()
        {
            return new PostController(blogPostService)
            {
                ControllerContext = controllerContext
            };
        }
    }
}

// ReSharper restore InconsistentNaming