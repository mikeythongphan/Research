﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MvcWithUnity.Models;
using Rhino.Mocks;

namespace MvcWithUnity.Tests.Models {
    public class Ctrl : Controller {
        public ActionResult Bar() { return View(); }
    }

    [TestClass]
    public class BlogPostHtmlExtenderTest {
        //[TestMethod]
        public void ActionLink_Test() {
            ViewContext viewContext = new ViewContext();
            IViewDataContainer viewDataContainer = MockRepository.GenerateStub<IViewDataContainer>();
            HtmlHelper html = new HtmlHelper(viewContext, viewDataContainer);
            var link = html.ActionLink<Ctrl>("Foo", c => c.Bar());

            Assert.AreEqual("<a href=\"\">Foo</a>", link);
        }
    }
}
