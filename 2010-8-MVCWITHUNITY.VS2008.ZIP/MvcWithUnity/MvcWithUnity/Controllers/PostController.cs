using System;
using System.Linq;
using System.Web.Mvc;
using Microsoft.Practices.Unity;
using MvcWithUnity.BlogEngine.Model;
using MvcWithUnity.BlogEngine.Services;

namespace MvcWithUnity.Controllers {
    public class PostController : Controller {
        private readonly IBlogPostService blogPostService;

        [Dependency]
        public ILogWriter Logger { get; set; }

        public PostController(IBlogPostService blogPostService) {
            this.blogPostService = blogPostService;
        }

        public ActionResult Index() {
            return View(blogPostService.GetPosts());
        }

        public ActionResult Post() {
            var date = GetDate();
            var slug = GetSlug();
            var post = blogPostService.GetPosts()
                                      .WhereSlugEquals(slug)
                                      .WhereDateEquals(date)
                                      .FirstOrDefault();
            return post != null 
                ? View(post) 
                : NotFound();
        }

        private string GetSlug() {
            return RouteData.GetRequiredString("slug");
        }

        private DateTime GetDate() {
            var date = string.Format("{0}-{1}-{2}", 
                                       RouteData.GetRequiredString("year"),
                                       RouteData.GetRequiredString("month"),
                                       RouteData.GetRequiredString("day"));
            return DateTime.Parse(date);
        }

        public ActionResult NotFound() {
            if (ReferrerIsThisSite()) {
                Logger.Write(new { EventId = 100 });
            }

            return View("NotFound");
        }

        private bool ReferrerIsThisSite() {
            return Request.UrlReferrer != null && 
                   Request.Url.Authority == Request.UrlReferrer.Authority;
        }
    }
}

