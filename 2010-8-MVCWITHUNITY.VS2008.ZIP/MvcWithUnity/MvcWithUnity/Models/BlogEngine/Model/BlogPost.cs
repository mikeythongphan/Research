using System;

namespace MvcWithUnity.BlogEngine.Model {
    public class BlogPost : IBlogPost {
        public BlogPost(string title, string slug, string body, DateTime date) {
            Title = title;
            Slug = slug;
            Body = body;
            Date = date;
        }

        public string Title { get; private set; }
        public string Slug { get; private set; }
        public string Body { get; private set; }
        public DateTime Date { get; private set; }
    }
}