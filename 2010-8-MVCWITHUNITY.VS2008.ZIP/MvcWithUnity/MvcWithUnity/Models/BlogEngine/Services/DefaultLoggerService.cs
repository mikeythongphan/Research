using MvcWithUnity.BlogEngine.Model;

namespace MvcWithUnity.BlogEngine.Services {
    public class DefaultLoggerService : ILogWriter {
        public void Write(object logEntry) {}
    }
}