using System;
using System.Collections.Generic;
using MvcWithUnity.BlogEngine.Model;

namespace MvcWithUnity.BlogEngine.Services {
    public interface IBlogPostService {
        IBlogPost GetPostWhereSlugEquals(string slug);
        IEnumerable<IBlogPost> GetPosts();
    }
}