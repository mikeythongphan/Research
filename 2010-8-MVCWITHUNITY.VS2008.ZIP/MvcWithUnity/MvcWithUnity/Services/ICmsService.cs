namespace MvcWithUnity.Services {
    public interface ICmsService {
        string GetSomeText();
    }
}