namespace MvcWithUnity.Services {
    public interface ILogger {
        void Log(string message);
    }
}