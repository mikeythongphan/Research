using System;

namespace MvcWithUnity.Services {
    public interface ILoggingProvider {
        void Log(string message);
    }
}