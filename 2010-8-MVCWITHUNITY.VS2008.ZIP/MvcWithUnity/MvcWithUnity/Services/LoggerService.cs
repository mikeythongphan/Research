namespace MvcWithUnity.Services {
    public class LoggerService : ILogger {
        private readonly ILoggingProvider provider;

        public LoggerService(ILoggingProvider provider) {
            this.provider = provider;
        }

        public void Log(string message) {
            provider.Log(message);
        }
    }
}