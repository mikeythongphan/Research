using System;
using System.Web.Mvc;
using Microsoft.Practices.Unity;

namespace MvcWithUnity.Unity {
    public class UnityControllerFactory : DefaultControllerFactory {
        private readonly IUnityContainer container;
        public UnityControllerFactory(IUnityContainer container) {
            this.container = container;
        }
        protected override IController GetControllerInstance(Type controllerType) {
            return container.Resolve(controllerType) as IController;
        }
    }
}