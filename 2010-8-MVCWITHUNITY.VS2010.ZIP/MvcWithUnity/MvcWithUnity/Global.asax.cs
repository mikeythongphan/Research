﻿using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Microsoft.Practices.Unity;
using MvcWithUnity.BlogEngine.Model;
using MvcWithUnity.BlogEngine.Services;
using MvcWithUnity.Unity;

namespace MvcWithUnity {
    public class MvcApplication : HttpApplication {
        public static void RegisterRoutes(RouteCollection routes) {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                "BlogPost",
                "{year}/{month}/{day}/{slug}",
                new { controller = "Post", action = "Post"},
                new { year = @"\d{4}", month = @"\d{1,2}", day = @"\d{1,2}" }
            );

            routes.MapRoute(
                "Default",                                              // Route name
                "{controller}/{action}/{id}",                           // URL with parameters
                new { controller = "Post", action = "Index", id = "" }  // Parameter defaults
            );

            routes.MapRoute(
                "404",
                "*",
                new { controller = "Home", action = "PageNotFound" }
            );
        }

        protected void Application_Start() {
            RegisterRoutes(RouteTable.Routes);

            var container = new UnityContainer();
            container
                .RegisterType<IBlogPostService, BlogPostService>()
                .RegisterType<ILogWriter, DefaultLoggerService>();
   
            var controllerFactory = new UnityControllerFactory(container);
            ControllerBuilder.Current.SetControllerFactory(controllerFactory);
        }
    }
}