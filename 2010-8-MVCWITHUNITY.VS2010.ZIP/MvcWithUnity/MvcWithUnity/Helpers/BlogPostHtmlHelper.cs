using System.Web.Mvc;
using System.Web.Mvc.Html;
using MvcWithUnity.BlogEngine.Model;

namespace MvcWithUnity.Models {
    public static class BlogPostHtmlHelper {
        public static MvcHtmlString PostActionLink(this HtmlHelper html, string linkText, IBlogPost post) {
            return html.ActionLink(linkText, "Post", 
                new {year = post.Date.Year, month = post.Date.Month, day = post.Date.Day,
                slug = post.Slug});
        }
    }
}