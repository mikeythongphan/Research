using System;

namespace MvcWithUnity.BlogEngine.Model {
    public interface IBlogPost {
        string Title { get; }
        string Slug { get; }
        string Body { get; }
        DateTime Date { get; }
    }
}