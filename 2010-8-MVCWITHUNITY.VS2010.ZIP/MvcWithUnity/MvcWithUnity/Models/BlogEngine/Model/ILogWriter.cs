namespace MvcWithUnity.BlogEngine.Model {
    public interface ILogWriter {
        void Write(object logEntry);
    }
}