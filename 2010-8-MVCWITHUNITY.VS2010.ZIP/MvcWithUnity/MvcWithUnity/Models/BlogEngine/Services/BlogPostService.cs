using System;
using System.Collections.Generic;
using System.Linq;
using MvcWithUnity.BlogEngine.Model;

namespace MvcWithUnity.BlogEngine.Services {
    public class BlogPostService : IBlogPostService {
        private List<IBlogPost> posts;
        
        public BlogPostService() {
            posts = new List<IBlogPost> {
                new BlogPost("First blog post", "First-blog-post", "body of first post", new DateTime(2008,1,1)),
                new BlogPost("Second blog post", "Second-blog-post", "body of second post", new DateTime(2008,1,3)),
                new BlogPost("Wow, third blog post", "Wow-third-blog-post", "body of the 3rd post", new DateTime(2008,1,10))
                };
        }

        public IBlogPost GetPostWhereSlugEquals(string slug) {
            return posts.Where(p => p.Slug == slug).SingleOrDefault();
        }

        public IEnumerable<IBlogPost> GetPosts() {
            return posts;
        }
    }
}