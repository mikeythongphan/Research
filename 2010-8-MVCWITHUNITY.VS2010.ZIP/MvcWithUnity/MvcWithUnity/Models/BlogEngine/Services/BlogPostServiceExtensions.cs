﻿using System;
using System.Collections.Generic;
using System.Linq;
using MvcWithUnity.BlogEngine.Model;

namespace MvcWithUnity.BlogEngine.Services
{
    public static class BlogPostServiceExtensions {
        public static IEnumerable<IBlogPost> WhereSlugEquals(this IEnumerable<IBlogPost> posts, string slug) {
            return posts.Where(post => post.Slug == slug);
        }

        public static IEnumerable<IBlogPost> WhereDateEquals(this IEnumerable<IBlogPost> posts, DateTime date) {
            return posts.Where(post => post.Date == date);
        }

    }
}