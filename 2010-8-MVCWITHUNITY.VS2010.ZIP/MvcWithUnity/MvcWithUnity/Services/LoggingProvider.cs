namespace MvcWithUnity.Services {
    class LoggingProvider : ILoggingProvider {
        public void Log(string message) {
            
        }
    }
}