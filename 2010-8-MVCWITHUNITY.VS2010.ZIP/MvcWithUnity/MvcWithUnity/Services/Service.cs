using System;

namespace MvcWithUnity.Services {
    public class Service : ICmsService {
        public string GetSomeText() {
            return "Welcome to the world of dependecy injection!";
        }
    }
}