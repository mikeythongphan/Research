﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LITS.UI.Areas.AutoLoanCorporate.Controllers
{
    public class CIMasterController : Controller
    {
        // GET: AutoLoanPersonal/CIMaster
        public ActionResult Index()
        {
            return View();
        }
    }
}