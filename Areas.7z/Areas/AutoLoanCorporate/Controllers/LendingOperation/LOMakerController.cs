﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LITS.Interface.Repository.Main.SalesCoordinators;
using LITS.Interface.Service.Main.SalesCoordinators;
using LITS.Service.Main.SalesCoordinators;
using LITS.Model.Views.Main;
using LITS.UI.Custom;

namespace LITS.UI.Areas.AutoLoanCorporate.Controllers
{
    public class LOMakerController : Controller
    {

        #region variables



        #endregion

        // GET: LOMaker
        [ExceptionHandler]
        public ActionResult Index()
        {
            return View("~/Areas/AutoLoanCorporate/Views/LendingOperation/LendingOperation.cshtml");
        }



    }
}
