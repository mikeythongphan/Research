﻿AspNetMvc_EF_GenericPattern_IoC.controller('LandingPageController', ['$scope', function ($scope) {
    $scope.models = {
        helloAngular: 'It works!'
    };
}]);