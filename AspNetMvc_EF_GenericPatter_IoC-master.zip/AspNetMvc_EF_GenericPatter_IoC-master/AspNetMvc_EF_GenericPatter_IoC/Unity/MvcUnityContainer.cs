﻿using Microsoft.Practices.Unity;

namespace MVC.Unity
{
    /// <summary>
    /// Container
    /// </summary>
    public static class MvcUnityContainer
    {
        public static UnityContainer Container { get; set; }
    }   
}