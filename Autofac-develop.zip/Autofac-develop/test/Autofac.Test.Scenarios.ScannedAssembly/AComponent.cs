﻿namespace Autofac.Test.Scenarios.ScannedAssembly
{
    public class AComponent
    {
    }
}
