namespace Autofac.Test.Scenarios.ScannedAssembly
{
    public class CloseCommand : ICloseCommand
    {
        public void Execute(object data)
        {
        }
    }
}