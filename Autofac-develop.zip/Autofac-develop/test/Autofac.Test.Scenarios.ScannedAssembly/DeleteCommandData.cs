namespace Autofac.Test.Scenarios.ScannedAssembly
{
    /// <summary>
    /// A type to use as a generic parameter.
    /// </summary>
    public class DeleteCommandData
    {
    }
}
