namespace Autofac.Test.Scenarios.ScannedAssembly
{
    public interface ICloseCommand : ICommand<object>
    {
    }
}