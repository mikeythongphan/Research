using System;

namespace Autofac.Test.Scenarios.ScannedAssembly.MetadataAttributeScanningScenario
{
    public interface IHaveName
    {
        string Name { get; }
    }
}