using System;

namespace Autofac.Test.Scenarios.ScannedAssembly.MetadataAttributeScanningScenario
{
    [Name("My Name")]
    public class ScannedComponentWithName
    {
    }
}
