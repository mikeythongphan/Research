namespace Autofac.Test.Scenarios.ScannedAssembly
{
    public abstract class ModuleBase : Module
    {
    }
}