﻿using System.Reflection;

[assembly: AssemblyTitle("Autofac.Test.Scenarios.ScannedAssembly")]
