namespace Autofac.Test.Builder
{
    internal static class Properties
    {
        internal interface IProperties
        {
            int A { get; }

            string B { get; }
        }
    }
}