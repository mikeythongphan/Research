using System.Collections.Generic;
using System.ComponentModel;

namespace Autofac.Test.Features.Metadata.TestTypes
{
    public interface IMyMetaInterface
    {
        int TheInt { get; }
    }
}
