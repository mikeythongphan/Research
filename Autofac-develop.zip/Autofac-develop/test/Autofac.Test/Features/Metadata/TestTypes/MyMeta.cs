using System.Collections.Generic;
using System.ComponentModel;

namespace Autofac.Test.Features.Metadata.TestTypes
{
    public class MyMeta
    {
        public int TheInt { get; set; }
    }
}
