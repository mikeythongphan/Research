namespace CompanyA
{
     // Please note that this name is the same as FluentValidation's IValidator<T>
    internal interface IValidator<T>
    {
    }
}
