namespace CompanyB
{
     // Please note that this name is NOT the same as FluentValidation's IValidator<T>
    internal interface IValidatorSomeOtherName<T>
    {
    }
}
