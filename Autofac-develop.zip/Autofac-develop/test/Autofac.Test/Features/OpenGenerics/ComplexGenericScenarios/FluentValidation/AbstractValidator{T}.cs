namespace FluentValidation
{
    internal class AbstractValidator<T> : IValidator<T>
    {
    }
}
