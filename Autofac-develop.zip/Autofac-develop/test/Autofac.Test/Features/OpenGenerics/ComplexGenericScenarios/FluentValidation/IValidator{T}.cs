namespace FluentValidation
{
    internal interface IValidator<T>
    {
    }
}
