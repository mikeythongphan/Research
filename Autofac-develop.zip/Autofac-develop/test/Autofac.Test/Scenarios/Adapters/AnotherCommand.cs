﻿namespace Autofac.Test.Scenarios.Adapters
{
    public class AnotherCommand
    {
    }
}