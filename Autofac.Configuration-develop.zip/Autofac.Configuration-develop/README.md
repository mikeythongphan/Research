# Autofac.Configuration

Configuration support for [Autofac](http://autofac.org).

[![Build status](https://ci.appveyor.com/api/projects/status/u6ujehy60pw4vyi2?svg=true)](https://ci.appveyor.com/project/Autofac/autofac-configuration)

Please file issues and pull requests for this package in this repository rather than in the Autofac core repo.

- [Documentation](http://autofac.readthedocs.io/en/latest/configuration/xml.html)
- [NuGet](https://www.nuget.org/packages/Autofac.Configuration)
- [Contributing](http://autofac.readthedocs.io/en/latest/contributors.html)
