﻿using System.Reflection;

[assembly: AssemblyTitle("Autofac.Configuration.Test")]
