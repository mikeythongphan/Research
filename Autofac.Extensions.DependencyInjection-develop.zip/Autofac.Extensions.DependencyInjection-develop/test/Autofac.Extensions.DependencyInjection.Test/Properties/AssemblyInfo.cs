﻿using System.Reflection;

[assembly: AssemblyTitle("Autofac.Extensions.DependencyInjection.Test")]
