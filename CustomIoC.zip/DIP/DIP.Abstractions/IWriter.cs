﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DIP.Abstractions
{
    public interface IWriter
    {
        void Write(string data);
    }
}
