﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DIP.MyIoCContainer;
using DIP.Abstractions;
using DIP.Implementation;
using DIP.HighLevelModule;

namespace DIP.Consumer
{
    class Program
    {
        static void Main(string[] args)
        {
            Container container = new Container();
            DIRegistration(container);
            Copy copy = new Copy(container);

            copy.DoCopy();
            Console.Read();
        }

        static void DIRegistration(Container container)
        {
            container.Register<IReader, KeyboardReader>();
            container.Register<IWriter, PrinterWriter>();
        }
    }
}
