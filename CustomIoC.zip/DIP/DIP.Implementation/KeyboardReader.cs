﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DIP.Abstractions;

namespace DIP.Implementation
{
    public class KeyboardReader:IReader
    {
        public string Read()
        {
            return "Reading from \"Keyboard\"";
        }
    }
}
