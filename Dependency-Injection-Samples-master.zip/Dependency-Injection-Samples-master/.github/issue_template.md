# Summary of the issue



## Environment

```
The in-use version:
Operating system: 
IDE: (e.g. Visual Studio 2015)
```

## Example code/Steps to reproduce:

```
paste your core code
```

## Output:

```
Exception message:
Full Stack trace:
```

