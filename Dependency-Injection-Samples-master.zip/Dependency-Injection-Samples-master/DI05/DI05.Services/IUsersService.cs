﻿
namespace DI05.Services
{
    public interface IUsersService
    {
        string GetUserEmail(int id);
    }
}