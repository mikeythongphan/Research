﻿namespace DI06.Services.Contracts
{
    public interface ILogActionService
    {
        void Log(string data);
    }
}