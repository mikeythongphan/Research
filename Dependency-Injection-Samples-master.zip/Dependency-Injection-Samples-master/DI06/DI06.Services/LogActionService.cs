﻿using DI06.Services.Contracts;

namespace DI06.Services
{
    public class LogActionService : ILogActionService
    {
        public LogActionService()
        {

        }

        public void Log(string data)
        {
            //todo: ...
        }
    }
}