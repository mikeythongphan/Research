﻿
namespace DI07.Services
{
    public interface ITestService
    {
        string Test();
    }
}