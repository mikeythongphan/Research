﻿
namespace DI07.Services
{
    public class TestService: ITestService
    {
        public string Test()
        {
            return "براي آزمايش";
        }
    }
}