﻿
namespace DI07.Core
{
    public interface IViewModel // از اين اينترفيس خالي براي يافتن و علامتگذاري ويوو مدل‌ها استفاده مي‌كنيم
    {
    }
}