﻿namespace DI08.Services
{
    public interface IEmailsService
    {
        void SendEmail();
    }
}