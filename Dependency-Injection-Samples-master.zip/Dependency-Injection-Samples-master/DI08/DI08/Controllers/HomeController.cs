﻿using System.Web.Mvc;

namespace DI08.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
