﻿namespace SameInterfaceDifferentClasses.Services.Contracts
{
    public interface IMessageService
    {
        void Send(string message);
    }
}