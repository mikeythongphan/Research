namespace SameInterfaceDifferentClasses.Services.Contracts
{
    public interface IUsersManagerService
    {
        void ValidateUserByEmail(int id);
    }
}