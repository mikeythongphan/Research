﻿namespace DI10.Services
{
    public class OrderCanceledMessage
    {
        public int OrderId { set; get; }
    }
}