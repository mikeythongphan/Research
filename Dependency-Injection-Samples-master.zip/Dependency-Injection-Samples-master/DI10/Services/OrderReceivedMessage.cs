﻿namespace DI10.Services
{
    public class OrderReceivedMessage
    {
        public int UserId { set; get; }
        public int ProductId { set; get; }
    }
}