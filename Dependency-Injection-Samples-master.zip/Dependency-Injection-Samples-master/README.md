Dependency Injection Samples, mostly using StructureMap
