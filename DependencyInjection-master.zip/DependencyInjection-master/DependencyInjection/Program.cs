﻿using System;
using Microsoft.Practices.Unity;

namespace DependencyInjection
{
    //UI Layer
    class Program
    {
        static void Main(string[] args)
        {
            IUnityContainer container = new UnityContainer();
            container.RegisterType<Customer>();
            container.RegisterType<IDal, SQLServerDal>();
            container.RegisterType<IDal, OracleServerDal>();

            Customer obj = container.Resolve<Customer>();
            obj.CustomerName = "Ömer";
            obj.IsActive = true;
            obj.Add();

            Customer obj2 = container.Resolve<Customer>();

            bool esit = obj.Equals(obj2);
        }
    }

    //Middle Layer
    public class Customer
    {
        private IDal ODal;
        public bool IsActive { get; set; }
        public string CustomerName { get; set; }

        public Customer(IDal iOdal)
        {
            ODal = iOdal;
        }

        public void Add()
        {
            ODal.Add();
        }
    }

    //DAL Layer
    public interface IDal
    {
        void Add();
    }

    public class SQLServerDal : IDal
    {
        public void Add()
        {
            Console.WriteLine("SQL Server inserted.");
        }
    }

    public class OracleServerDal : IDal
    {
        public void Add()
        {
            Console.WriteLine("Oracle Server inserted.");
        }
    }
}
