﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Interface.Repository.AutoLoan.CreditInitiative
{
    public interface ICollateralInformationRepository : IRepository<CollateralInformationViewModel>
    { }
}
