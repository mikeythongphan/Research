﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;

namespace LITS.Interface.Repository.AutoLoan.LendingOperation
{
    public interface IPersonalDetailRepository : IRepository<PersonalDetailViewModel>
    { }
}
