﻿using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Interface.Repository.AutoLoan.OperationSupport
{
    public interface IAppliedLoanInformationRepository : IRepository<AppliedLoanInformationViewModel>
    { }
}
