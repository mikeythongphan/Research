﻿using LITS.Infrastructure.Factory;
using System;
using System.Linq;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Interface.Repository.AutoLoan.OperationSupport
{
    public interface ICustomerDemostrationRepository : IRepository<CustomerDemostrationViewModel>
    { }
}
