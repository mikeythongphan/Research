﻿using LITS.Infrastructure.Factory;
using System;
using System.Linq;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;

namespace LITS.Interface.Repository.AutoLoan.SalesCoordinators
{
    public interface ICustomerDemostrationRepository : IRepository<CustomerDemostrationViewModel>
    {
        CustomerDemostrationViewModel LoadIndex(CustomerDemostrationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
