﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.Main.WorkInProgress;
using LITS.Model.Views.Main;

namespace LITS.Interface.Repository.Main.WorkInProgress
{
    public interface IWorkInProgressMasterRepository : IRepository<WorkInProgressMasterViewModel>
    {
        List<WorkInProgressMasterCustomerViewModel> GetListCustomerLargeDatabase();
        List<WorkInProgressMasterCompanyViewModel> GetListCompanyLargeDatabase();
    }
}
