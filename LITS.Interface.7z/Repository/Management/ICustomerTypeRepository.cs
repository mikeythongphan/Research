﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ICustomerTypeRepository : IRepository<m_customer_type>
    {
        List<CustomerTypeViewModel> GetListAll();

        List<CustomerTypeViewModel> GetListById(int? Id);

        List<CustomerTypeViewModel> GetListByStatusId(int? StatusId);

        List<CustomerTypeViewModel> GetListByTypeId(int? TypeId);

        List<CustomerTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CustomerTypeViewModel> GetListActiveAll();

        List<CustomerTypeViewModel> GetListActiveById(int? Id);

        List<CustomerTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<CustomerTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<CustomerTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CustomerTypeViewModel objModel);

        bool Update(CustomerTypeViewModel objModel);

        bool Delete(CustomerTypeViewModel objModel);
    }
}
