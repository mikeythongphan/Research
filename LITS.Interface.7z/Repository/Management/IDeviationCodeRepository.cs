﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IDeviationCodeRepository : IRepository<m_deviation_code>
    {
        List<DeviationCodeViewModel> GetListAll();

        List<DeviationCodeViewModel> GetListById(int Id);

        List<DeviationCodeViewModel> GetListByStatusId(int StatusId);

        List<DeviationCodeViewModel> GetListByTypeId(int TypeId);

        List<DeviationCodeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId);

        List<DeviationCodeViewModel> GetListActiveAll();

        List<DeviationCodeViewModel> GetListActiveById(int Id);

        List<DeviationCodeViewModel> GetListActiveByStatusId(int StatusId);

        List<DeviationCodeViewModel> GetListActiveByTypeId(int TypeId);

        List<DeviationCodeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId);

        bool Create(DeviationCodeViewModel objModel);

        bool Update(DeviationCodeViewModel objModel);

        bool Delete(DeviationCodeViewModel objModel);
    }
}
