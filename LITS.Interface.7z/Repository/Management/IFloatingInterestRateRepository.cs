﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IFloatingInterestRateRepository : IRepository<m_floating_interest_rate>
    {
        List<FloatingInterestRateViewModel> GetListAll();

        List<FloatingInterestRateViewModel> GetListById(int? Id);

        List<FloatingInterestRateViewModel> GetListByStatusId(int? StatusId);

        List<FloatingInterestRateViewModel> GetListByTypeId(int? TypeId);

        List<FloatingInterestRateViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<FloatingInterestRateViewModel> GetListActiveAll();

        List<FloatingInterestRateViewModel> GetListActiveById(int? Id);

        List<FloatingInterestRateViewModel> GetListActiveByStatusId(int? StatusId);

        List<FloatingInterestRateViewModel> GetListActiveByTypeId(int? TypeId);

        List<FloatingInterestRateViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(FloatingInterestRateViewModel objModel);

        bool Update(FloatingInterestRateViewModel objModel);

        bool Delete(FloatingInterestRateViewModel objModel);
    }
}
