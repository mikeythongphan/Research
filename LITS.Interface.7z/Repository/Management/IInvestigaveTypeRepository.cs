﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IInvestigaveTypeRepository : IRepository<m_investigave_type>
    {
        List<InvestigaveTypeViewModel> GetListAll();

        List<InvestigaveTypeViewModel> GetListById(int Id);

        List<InvestigaveTypeViewModel> GetListByStatusId(int StatusId);

        List<InvestigaveTypeViewModel> GetListByTypeId(int TypeId);

        List<InvestigaveTypeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId);

        List<InvestigaveTypeViewModel> GetListActiveAll();

        List<InvestigaveTypeViewModel> GetListActiveById(int Id);

        List<InvestigaveTypeViewModel> GetListActiveByStatusId(int StatusId);

        List<InvestigaveTypeViewModel> GetListActiveByTypeId(int TypeId);

        List<InvestigaveTypeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId);

        bool Create(InvestigaveTypeViewModel objModel);

        bool Update(InvestigaveTypeViewModel objModel);

        bool Delete(InvestigaveTypeViewModel objModel);
    }
}
