﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ILabourContractTypeRepository : IRepository<m_labour_contract_type>
    {
        List<LabourContractTypeViewModel> GetListAll();

        List<LabourContractTypeViewModel> GetListById(int Id);

        List<LabourContractTypeViewModel> GetListByStatusId(int StatusId);

        List<LabourContractTypeViewModel> GetListByTypeId(int TypeId);

        List<LabourContractTypeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId);

        List<LabourContractTypeViewModel> GetListActiveAll();

        List<LabourContractTypeViewModel> GetListActiveById(int Id);

        List<LabourContractTypeViewModel> GetListActiveByStatusId(int StatusId);

        List<LabourContractTypeViewModel> GetListActiveByTypeId(int TypeId);

        List<LabourContractTypeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId);

        bool Create(LabourContractTypeViewModel objModel);

        bool Update(LabourContractTypeViewModel objModel);

        bool Delete(LabourContractTypeViewModel objModel);
    }
}
