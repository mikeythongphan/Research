﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ILoanTenorRepository : IRepository<m_loan_tenor>
    {
        List<LoanTenorViewModel> GetListAll();

        List<LoanTenorViewModel> GetListById(int Id);

        List<LoanTenorViewModel> GetListByStatusId(int StatusId);

        List<LoanTenorViewModel> GetListByTypeId(int TypeId);

        List<LoanTenorViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId);

        List<LoanTenorViewModel> GetListActiveAll();

        List<LoanTenorViewModel> GetListActiveById(int Id);

        List<LoanTenorViewModel> GetListActiveByStatusId(int StatusId);

        List<LoanTenorViewModel> GetListActiveByTypeId(int TypeId);

        List<LoanTenorViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId);

        bool Create(LoanTenorViewModel objModel);

        bool Update(LoanTenorViewModel objModel);

        bool Delete(LoanTenorViewModel objModel);
    }
}
