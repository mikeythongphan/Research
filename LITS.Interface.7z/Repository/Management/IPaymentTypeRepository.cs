﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IPaymentTypeRepository : IRepository<m_payment_type>
    {
        List<PaymentTypeViewModel> GetListAll();

        List<PaymentTypeViewModel> GetListById(int Id);

        List<PaymentTypeViewModel> GetListByStatusId(int StatusId);

        List<PaymentTypeViewModel> GetListByTypeId(int TypeId);

        List<PaymentTypeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId);

        List<PaymentTypeViewModel> GetListActiveAll();

        List<PaymentTypeViewModel> GetListActiveById(int Id);

        List<PaymentTypeViewModel> GetListActiveByStatusId(int StatusId);

        List<PaymentTypeViewModel> GetListActiveByTypeId(int TypeId);

        List<PaymentTypeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId);

        bool Create(PaymentTypeViewModel objModel);

        bool Update(PaymentTypeViewModel objModel);

        bool Delete(PaymentTypeViewModel objModel);
    }
}
