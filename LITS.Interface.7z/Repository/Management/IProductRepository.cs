﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IProductRepository : IRepository<m_product>
    {
        List<ProductViewModel> GetListAll();

        List<ProductViewModel> GetListById(int? Id);

        List<ProductViewModel> GetListByStatusId(int? StatusId);

        List<ProductViewModel> GetListByTypeId(int? TypeId);

        List<ProductViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<ProductViewModel> GetListActiveAll();

        List<ProductViewModel> GetListActiveById(int? Id);

        List<ProductViewModel> GetListActiveByStatusId(int? StatusId);

        List<ProductViewModel> GetListActiveByTypeId(int? TypeId);

        List<ProductViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(ProductViewModel objModel);

        bool Update(ProductViewModel objModel);

        bool Delete(ProductViewModel objModel);
    }
}
