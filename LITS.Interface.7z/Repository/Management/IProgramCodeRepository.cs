﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IProgramCodeRepository : IRepository<m_program_code>
    {
        List<ProgramCodeViewModel> GetListAll();

        List<ProgramCodeViewModel> GetListById(int? Id);

        List<ProgramCodeViewModel> GetListByStatusId(int? StatusId);

        List<ProgramCodeViewModel> GetListByTypeId(int? TypeId);

        List<ProgramCodeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<ProgramCodeViewModel> GetListActiveAll();

        List<ProgramCodeViewModel> GetListActiveById(int? Id);

        List<ProgramCodeViewModel> GetListActiveByStatusId(int? StatusId);

        List<ProgramCodeViewModel> GetListActiveByTypeId(int? TypeId);

        List<ProgramCodeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(ProgramCodeViewModel objModel);

        bool Update(ProgramCodeViewModel objModel);

        bool Delete(ProgramCodeViewModel objModel);
    }
}
