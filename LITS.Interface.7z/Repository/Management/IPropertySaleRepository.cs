﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IPropertySaleRepository : IRepository<m_property_sale>
    {
        List<PropertySaleViewModel> GetListAll();

        List<PropertySaleViewModel> GetListById(int? Id);

        List<PropertySaleViewModel> GetListByStatusId(int? StatusId);

        List<PropertySaleViewModel> GetListByTypeId(int? TypeId);

        List<PropertySaleViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<PropertySaleViewModel> GetListActiveAll();

        List<PropertySaleViewModel> GetListActiveById(int? Id);

        List<PropertySaleViewModel> GetListActiveByStatusId(int? StatusId);

        List<PropertySaleViewModel> GetListActiveByTypeId(int? TypeId);

        List<PropertySaleViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(PropertySaleViewModel objModel);

        bool Update(PropertySaleViewModel objModel);

        bool Delete(PropertySaleViewModel objModel);
    }
}
