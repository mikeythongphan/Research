﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface IResidenceOwnershipRepository : IRepository<m_residence_ownership>
    {
        List<ResidenceOwnershipViewModel> GetListAll();

        List<ResidenceOwnershipViewModel> GetListById(int? Id);

        List<ResidenceOwnershipViewModel> GetListByStatusId(int? StatusId);

        List<ResidenceOwnershipViewModel> GetListByTypeId(int? TypeId);

        List<ResidenceOwnershipViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<ResidenceOwnershipViewModel> GetListActiveAll();

        List<ResidenceOwnershipViewModel> GetListActiveById(int? Id);

        List<ResidenceOwnershipViewModel> GetListActiveByStatusId(int? StatusId);

        List<ResidenceOwnershipViewModel> GetListActiveByTypeId(int? TypeId);

        List<ResidenceOwnershipViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(ResidenceOwnershipViewModel objModel);

        bool Update(ResidenceOwnershipViewModel objModel);

        bool Delete(ResidenceOwnershipViewModel objModel);
    }
}
