﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

namespace LITS.Interface.Repository.Management
{
    public interface ITradingAreaRepository : IRepository<m_trading_area>
    {
        List<TradingAreaViewModel> GetListAll();

        List<TradingAreaViewModel> GetListById(int? Id);

        List<TradingAreaViewModel> GetListByStatusId(int? StatusId);

        List<TradingAreaViewModel> GetListByTypeId(int? TypeId);

        List<TradingAreaViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<TradingAreaViewModel> GetListActiveAll();

        List<TradingAreaViewModel> GetListActiveById(int? Id);

        List<TradingAreaViewModel> GetListActiveByStatusId(int? StatusId);

        List<TradingAreaViewModel> GetListActiveByTypeId(int? TypeId);

        List<TradingAreaViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(TradingAreaViewModel objModel);

        bool Update(TradingAreaViewModel objModel);

        bool Delete(TradingAreaViewModel objModel);
    }
}
