﻿using LITS.Model.PartialViews.AutoLoan.CreditInitiative;
using LITS.Model.Views.AutoLoan;

namespace LITS.Interface.Service.AutoLoan.CreditInitiative
{
    public interface ICreditInitiativeService
    {
        CreditInitiativeViewModel LoadIndex(CreditInitiativeViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
