﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.AutoLoan.CreditInitiative
{
    public interface ICustomerCreditBureauService
    {
        CustomerCreditBureauViewModel GetById(int Id);

        CustomerCreditBureauViewModel GetAll();

        //application_information GetApplicationInformation(int Id);

        void Create(CustomerCreditBureauViewModel obj);

        void Delete(CustomerCreditBureauViewModel obj);

        void Update(CustomerCreditBureauViewModel obj);
    }
}
