﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.AutoLoan.CreditInitiative
{
    public interface ICustomerInformationService
    {
        CustomerInformationViewModel GetById(int Id);

        CustomerInformationViewModel GetAll();

       // application_information GetApplicationInformation(int Id);

        void Create(CustomerInformationViewModel obj);

        void Delete(CustomerInformationViewModel obj);

        void Update(CustomerInformationViewModel obj);
    }
}
