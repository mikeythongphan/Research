﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.AutoLoan.LendingOperation
{
    public interface IDisbursementService
    {
        DisbursementViewModel GetById(int? Id);

        DisbursementViewModel GetAll();

        // application_information GetDisbursementInformation(int? Id);

        void Create(DisbursementViewModel obj);

        void Delete(DisbursementViewModel obj);

        void Update(DisbursementViewModel obj);
    }
}
