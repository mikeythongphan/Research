﻿using LITS.Model.Views.AutoLoan;

namespace LITS.Interface.Service.AutoLoan.LendingOperation
{
    public interface ILendingOperationService
    {
        LendingOperationViewModel LoadIndex(LendingOperationViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam);
    }
}
