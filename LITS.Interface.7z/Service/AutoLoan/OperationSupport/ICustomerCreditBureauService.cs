﻿using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Interface.Service.AutoLoan.OperationSupport
{
    public interface ICustomerCreditBureauService
    {
        CustomerCreditBureauViewModel GetById(int? Id);

        CustomerCreditBureauViewModel GetAll();

        //application_information GetApplicationInformation(int? Id);        

        void Create(CustomerCreditBureauViewModel obj);

        void Delete(CustomerCreditBureauViewModel obj);

        void Save();
    }
}
