﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.Main.SalesCoordinators;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.Main.SalesCoordinators
{
    public interface ICustomerInformationService
    {
        CustomerInformationViewModel GetById(int? Id);

        CustomerInformationViewModel GetAll();

        customer_information GetCustomerInformation(int? Id);

        IEnumerable<customer_identification> GetCustomerIdentificationByCustId(int CustId);

        void Create(CustomerInformationViewModel obj);

        void Delete(int? Id);

        void Save();
    }
}
