﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.PartialViews.Main.WorkInProgress;

namespace LITS.Interface.Service.Main.SearchApplication
{
    public interface ISearchApplicationTreelService
    {
        WorkInProgressTreeViewModel GetById(int? Id);

        WorkInProgressTreeViewModel GetAll();

        void Create(WorkInProgressTreeViewModel obj);

        void Delete(int? Id);

        void Save();
    }
}
