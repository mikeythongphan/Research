﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.Main.WorkInProgress;
using LITS.Model.Views.Main;

namespace LITS.Interface.Service.Main.WorkInProgress
{
    public interface IWorkInProgressMasterService
    {
        WorkInProgressMasterViewModel GetById(int? Id);

        WorkInProgressMasterViewModel GetAll();        

        void Create(WorkInProgressMasterViewModel obj);

        void Delete(int? Id);

        void Save();
    }
}
