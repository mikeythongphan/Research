﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
namespace LITS.Interface.Service.Management
{
    public interface ICampaignCodeService
    {
        List<CampaignCodeViewModel> GetListAll();

        List<CampaignCodeViewModel> GetListById(int? Id);

        List<CampaignCodeViewModel> GetListByStatusId(int? StatusId);

        List<CampaignCodeViewModel> GetListByTypeId(int? TypeId);

        List<CampaignCodeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CampaignCodeViewModel> GetListActiveAll();

        List<CampaignCodeViewModel> GetListActiveById(int? Id);

        List<CampaignCodeViewModel> GetListActiveByStatusId(int? StatusId);

        List<CampaignCodeViewModel> GetListActiveByTypeId(int? TypeId);

        List<CampaignCodeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CampaignCodeViewModel objModel);

        bool Update(CampaignCodeViewModel objModel);

        bool Delete(CampaignCodeViewModel objModel);
    }
}
