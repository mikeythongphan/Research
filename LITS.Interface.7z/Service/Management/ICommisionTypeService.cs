﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;
namespace LITS.Interface.Service.Management
{
    public interface ICommisionTypeService
    {
        List<CommisionTypeViewModel> GetListAll();

        List<CommisionTypeViewModel> GetListById(int? Id);

        List<CommisionTypeViewModel> GetListByStatusId(int? StatusId);

        List<CommisionTypeViewModel> GetListByTypeId(int? TypeId);

        List<CommisionTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CommisionTypeViewModel> GetListActiveAll();

        List<CommisionTypeViewModel> GetListActiveById(int? Id);

        List<CommisionTypeViewModel> GetListActiveByStatusId(int? StatusId);

        List<CommisionTypeViewModel> GetListActiveByTypeId(int? TypeId);

        List<CommisionTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CommisionTypeViewModel objModel);

        bool Update(CommisionTypeViewModel objModel);

        bool Delete(CommisionTypeViewModel objModel);
    }
}
