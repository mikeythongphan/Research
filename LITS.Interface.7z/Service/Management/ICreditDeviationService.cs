﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface ICreditDeviationService
    {
        List<CreditDeviationViewModel> GetListAll();

        List<CreditDeviationViewModel> GetListById(int? Id);

        List<CreditDeviationViewModel> GetListByStatusId(int? StatusId);

        List<CreditDeviationViewModel> GetListByTypeId(int? TypeId);

        List<CreditDeviationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<CreditDeviationViewModel> GetListActiveAll();

        List<CreditDeviationViewModel> GetListActiveById(int? Id);

        List<CreditDeviationViewModel> GetListActiveByStatusId(int? StatusId);

        List<CreditDeviationViewModel> GetListActiveByTypeId(int? TypeId);

        List<CreditDeviationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(CreditDeviationViewModel objModel);

        bool Update(CreditDeviationViewModel objModel);

        bool Delete(CreditDeviationViewModel objModel);
    }
}
