﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IDisbursalScenarioConditionService
    {
        List<DisbursalScenarioConditionViewModel> GetListAll();

        List<DisbursalScenarioConditionViewModel> GetListById(int? Id);

        List<DisbursalScenarioConditionViewModel> GetListByStatusId(int? StatusId);

        List<DisbursalScenarioConditionViewModel> GetListByTypeId(int? TypeId);

        List<DisbursalScenarioConditionViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<DisbursalScenarioConditionViewModel> GetListActiveAll();

        List<DisbursalScenarioConditionViewModel> GetListActiveById(int? Id);

        List<DisbursalScenarioConditionViewModel> GetListActiveByStatusId(int? StatusId);

        List<DisbursalScenarioConditionViewModel> GetListActiveByTypeId(int? TypeId);

        List<DisbursalScenarioConditionViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(DisbursalScenarioConditionViewModel objModel);

        bool Update(DisbursalScenarioConditionViewModel objModel);

        bool Delete(DisbursalScenarioConditionViewModel objModel);
    }
}
