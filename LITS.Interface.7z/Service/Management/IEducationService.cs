﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IEducationService
    {
        List<EducationViewModel> GetListAll();

        List<EducationViewModel> GetListById(int? Id);

        List<EducationViewModel> GetListByStatusId(int? StatusId);

        List<EducationViewModel> GetListByTypeId(int? TypeId);

        List<EducationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<EducationViewModel> GetListActiveAll();

        List<EducationViewModel> GetListActiveById(int? Id);

        List<EducationViewModel> GetListActiveByStatusId(int? StatusId);

        List<EducationViewModel> GetListActiveByTypeId(int? TypeId);

        List<EducationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(EducationViewModel objModel);

        bool Update(EducationViewModel objModel);

        bool Delete(EducationViewModel objModel);
    }
}
