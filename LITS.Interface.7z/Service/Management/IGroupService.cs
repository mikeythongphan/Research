﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IGroupService
    {
        List<GroupViewModel> GetListAll();

        List<GroupViewModel> GetListById(int? Id);

        List<GroupViewModel> GetListByParentId(int? ParentId);

        List<GroupViewModel> GetListActiveAll();

        List<GroupViewModel> GetListActiveById(int? Id);

        List<GroupViewModel> GetListActiveByParentId(int? ParentId);

        bool Create(GroupViewModel objModel);

        bool Update(GroupViewModel objModel);

        bool Delete(GroupViewModel objModel);
    }
}
