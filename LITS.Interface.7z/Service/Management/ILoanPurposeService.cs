﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface ILoanPurposeService
    {
        List<LoanPurposeViewModel> GetListAll();

        List<LoanPurposeViewModel> GetListById(int? Id);

        List<LoanPurposeViewModel> GetListByStatusId(int? StatusId);

        List<LoanPurposeViewModel> GetListByTypeId(int? TypeId);

        List<LoanPurposeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<LoanPurposeViewModel> GetListActiveAll();

        List<LoanPurposeViewModel> GetListActiveById(int? Id);

        List<LoanPurposeViewModel> GetListActiveByStatusId(int? StatusId);

        List<LoanPurposeViewModel> GetListActiveByTypeId(int? TypeId);

        List<LoanPurposeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(LoanPurposeViewModel objModel);

        bool Update(LoanPurposeViewModel objModel);

        bool Delete(LoanPurposeViewModel objModel);
    }
}
