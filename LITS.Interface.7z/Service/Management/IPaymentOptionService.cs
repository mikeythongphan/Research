﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IPaymentOptionService
    {
        List<PaymentOptionViewModel> GetListAll();

        List<PaymentOptionViewModel> GetListById(int? Id);

        List<PaymentOptionViewModel> GetListByStatusId(int? StatusId);

        List<PaymentOptionViewModel> GetListByTypeId(int? TypeId);

        List<PaymentOptionViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<PaymentOptionViewModel> GetListActiveAll();

        List<PaymentOptionViewModel> GetListActiveById(int? Id);

        List<PaymentOptionViewModel> GetListActiveByStatusId(int? StatusId);

        List<PaymentOptionViewModel> GetListActiveByTypeId(int? TypeId);

        List<PaymentOptionViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(PaymentOptionViewModel objModel);

        bool Update(PaymentOptionViewModel objModel);

        bool Delete(PaymentOptionViewModel objModel);
    }
}
