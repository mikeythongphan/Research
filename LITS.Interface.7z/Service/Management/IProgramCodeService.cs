﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Interface.Service.Management
{
    public interface IProgramCodeService
    {
        List<ProgramCodeViewModel> GetListAll();

        List<ProgramCodeViewModel> GetListById(int? Id);

        List<ProgramCodeViewModel> GetListByStatusId(int? StatusId);

        List<ProgramCodeViewModel> GetListByTypeId(int? TypeId);

        List<ProgramCodeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId);

        List<ProgramCodeViewModel> GetListActiveAll();

        List<ProgramCodeViewModel> GetListActiveById(int? Id);

        List<ProgramCodeViewModel> GetListActiveByStatusId(int? StatusId);

        List<ProgramCodeViewModel> GetListActiveByTypeId(int? TypeId);

        List<ProgramCodeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId);

        bool Create(ProgramCodeViewModel objModel);

        bool Update(ProgramCodeViewModel objModel);

        bool Delete(ProgramCodeViewModel objModel);
    }
}
