﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.Domain.AutoLoan
{
    public class CarDealerViewModel
    {
        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsEnabledID { get; set; }

        public string CarDealerName { get; set; }
        public bool IsVisibleCarDealerName { get; set; }
        public bool IsEnabledCarDealerName { get; set; }

        public string CarDealerAddress { get; set; }
        public bool IsVisibleCarDealerAddress { get; set; }
        public bool IsEnabledCarDealerAddress { get; set; }

        public string CarDealerWards { get; set; }
        public bool IsVisibleCarDealerWards { get; set; }
        public bool IsEnabledCarDealerWards { get; set; }

        public int? CarDealerDistrictID { get; set; }
        public string CarDealerDistrict { get; set; }
        public bool IsVisibleCarDealerDistrict { get; set; }
        public bool IsEnabledCarDealerDistrict { get; set; }

        public int? CarDealerCityID { get; set; }
        public string CarDealerCity { get; set; }
        public bool IsVisibleCarDealerCity { get; set; }
        public bool IsEnabledCarDealerCity { get; set; }

        public string Description { get; set; }
        public bool IsVisibleDescription { get; set; }
        public bool IsEnabledDescription { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisibleIsActive { get; set; }
        public bool IsEnabledIsActive { get; set; }

        public int TypeID { get; set; }
        public string Type { get; set; }
        public bool IsVisibleTypeID { get; set; }
        public bool IsEnabledTypeID { get; set; }

        public int StatusID { get; set; }
        public string Status { get; set; }
        public bool IsVisibleStatusID { get; set; }
        public bool IsEnabledStatusID { get; set; }

        public Nullable<DateTime> CreateDate { get; set; }
        public bool IsVisibleCreateDate { get; set; }
        public bool IsEnabledCreateDate { get; set; }

        public string CreateBy { get; set; }
        public bool IsVisibleCreateBy { get; set; }
        public bool IsEnabledCreateBy { get; set; }
    }
}
