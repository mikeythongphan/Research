﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.CreditInitiative
{
    public class ARTAViewModel
    {
        public bool IsActive { get; set; }
        #region ARTA
        public string ARTA { get; set; }
        public bool IsVisibleARTA { get; set; }
        public bool IsDisableARTA { get; set; }
        public int ARTAID { get; set; }
        public decimal ApplicationNumber { get; set; }
        public bool IsVisibleApplicationNumber { get; set; }
        public bool IsDisableApplicationNumber { get; set; }
        public string PaymentOption { get; set; }
        public bool IsVisiblePaymentOption { get; set; }
        public bool IsDisablePaymentOption { get; set; }
        public int PaymentOptionID { get; set; }
        public decimal LifeAssured { get; set; }
        public bool IsVisibleLifeAssured { get; set; }
        public bool IsDisableLifeAssured { get; set; }
        public decimal AppliedSumAssured { get; set; }
        public bool IsVisibleAppliedSumAssured { get; set; }
        public bool IsDisableAppliedSumAssured { get; set; }
        public decimal AppliedPremium { get; set; }
        public bool IsVisibleAppliedPremium { get; set; }
        public bool IsDisableAppliedPremium { get; set; }
        public decimal MRTAAmount { get; set; }
        public bool IsVisibleMRTAAmount { get; set; }
        public bool IsDisableMRTAAmount { get; set; }
        public decimal LoanAMTWithMRTA { get; set; }
        public bool IsVisibleLoanAMTWithMRTA { get; set; }
        public bool IsDisableLoanAMTWithMRTA { get; set; }
        public decimal LTVWithMRTA { get; set; }
        public bool IsVisibleLTVWithMRTA { get; set; }
        public bool IsDisableLTVWithMRTA { get; set; }
        public decimal EMIWithMRTA { get; set; }
        public bool IsVisibleEMIWithMRTA { get; set; }
        public bool IsDisableEMIWithMRTA { get; set; }
        public decimal EMIWithMRTA2Added { get; set; }
        public bool IsVisibleEMIWithMRTA2Added { get; set; }
        public bool IsDisableEMIWithMRTA2Added { get; set; }
        public decimal DBRWithMRTA2Added { get; set; }
        public bool IsVisibleDBRWithMRTA2Added { get; set; }
        public bool IsDisableDBRWithMRTA2Added { get; set; }
        #endregion

    }
}
