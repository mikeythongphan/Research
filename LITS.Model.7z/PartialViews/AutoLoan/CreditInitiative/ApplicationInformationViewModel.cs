﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.CreditInitiative
{
    public class ApplicationInformationViewModel
    {
        public bool IsActive { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Channel")]
        public string Channel { get; set; }
        public bool IsVisibleChannel { get; set; }
        public bool IsDisableChannel { get; set; }
        public int ChannelID { get; set; }

        public string PeoplewiseIDOfSaleStaf { get; set; }
        public bool IsVisiblePeoplewiseIDOfSaleStaf { get; set; }
        public bool IsDisablePeoplewiseIDOfSaleStaf { get; set; }
        public string ICT { get; set; }
        public bool IsVisibleICT { get; set; }
        public bool IsDisableICT { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Existing")]
        public string Existing { get; set; }
        public bool IsVisibleExisting { get; set; }
        public bool IsDisableExisting { get; set; }
        public int ExistingID { get; set; }


        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Hard Copy Application Date")]
        public Nullable<System.DateTime> HardCopyApplicationDate { get; set; }
        public bool IsVisibleHardCopyApplicationDate { get; set; }
        public bool IsDisableHardCopyApplicationDate { get; set; }
        public string ReasonForReWork { get; set; }
        public bool IsVisibleReasonForReWork { get; set; }
        public bool IsDisableReasonForReWork { get; set; }
        public Nullable<System.DateTime> RecevingDate { get; set; }
        public bool IsVisibleRecevingDate { get; set; }
        public bool IsDisableRecevingDate { get; set; }


        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Program Type")]
        public string ProgramType { get; set; }
        public bool IsVisibleProgramType { get; set; }
        public bool IsDisableProgramType { get; set; }
        public int ProgramTypeID { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Sale TMPW ID")]
        public string SaleTMPWID { get; set; }
        public bool IsVisibleSaleTMPWID { get; set; }
        public bool IsDisableSaleTMPWID { get; set; }


        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "CDD")]
        public string CDD { get; set; }
        public bool IsVisibleCDD { get; set; }
        public bool IsDisableCDD { get; set; }
        public int CDDID { get; set; }
        public string SalesCode { get; set; }
        public bool IsVisibleSalesCode { get; set; }
        public bool IsDisableSalesCode { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Branch Location")]
        public string BranchLocation { get; set; }
        public bool IsVisibleBranchLocation { get; set; }
        public bool IsDisableBranchLocation { get; set; }
        public int BranchLocationID { get; set; }
        public string ARMCode { get; set; }
        public bool IsVisibleARMCode { get; set; }
        public bool IsDisableARMCode { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Product Type")]
        public string ProductType { get; set; }
        public bool IsVisibleProductType { get; set; }
        public bool IsDisableProductType { get; set; }
        public int ProductTypeID { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Customer Type")]
        public string CustomerType { get; set; }
        public bool IsVisibleCustomerType { get; set; }
        public bool IsDisableCustomerType { get; set; }
        public int CustomerTypeID { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "Customer Segment")]
        public string CustomerSegment { get; set; }
        public bool IsVisibleCustomerSegment { get; set; }
        public bool IsDisableCustomerSegment { get; set; }
        public int CustomerSegmentID { get; set; }

        [Required(ErrorMessage = "The {0} is required.")]
        [Display(Name = "eOps Txn Reference")]
        public string eOpsTxnReference { get; set; }
        public bool IsVisibleeOpsTxnReference { get; set; }
        public bool IsDisableeOpsTxnReference { get; set; }
        public string Rework { get; set; }
        public bool IsVisibleRework { get; set; }
        public bool IsDisableRework { get; set; }

    }
}
