﻿using LITS.Infrastructure.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.CreditInitiative
{
    public class CustomerIncomeViewModel
    {
        #region Application ID
        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }
        #endregion

        #region Main

        #region ID
        public int CustomerID_Main { get; set; }
        public int ALCustomerID_Main { get; set; }
        public int CustomerIncomeID_Main { get; set; }
        #endregion

        #region SalariedClient

        #region Income1               
        public int ALCustomerIncomeID_Main_SalariedClientIncome_1 { get; set; }
        public int ALCustomerSalariedClientIncomeID_Main_Income_1 { get; set; }

        public int? CompanyCodeID_Main_Income_1 { get; set; }
        public string CompanyCode_Main_Income_1 { get; set; }
        public bool IsVisibleCompanyCode_Main_Income_1 { get; set; }
        public bool IsDisableCompanyCode_Main_Income_1 { get; set; }

        public string CompanyName_Main_Income_1 { get; set; }
        public bool IsVisibleCompanyName_Main_Income_1 { get; set; }
        public bool IsDisableCompanyName_Main_Income_1 { get; set; }

        public string CompanyAddress_Main_Income_1 { get; set; }
        public bool IsVisibleCompanyAddress_Main_Income_1 { get; set; }
        public bool IsDisableCompanyAddress_Main_Income_1 { get; set; }

        public string CompanyWard_Main_Income_1 { get; set; }
        public bool IsVisibleCompanyWard_Main_Income_1 { get; set; }
        public bool IsDisableCompanyWard_Main_Income_1 { get; set; }

        public int? CompanyDistrictID_Main_Income_1 { get; set; }
        public string CompanyDistrict_Main_Income_1 { get; set; }
        public bool IsVisibleCompanyDistrict_Main_Income_1 { get; set; }
        public bool IsDisableCompanyDistrict_Main_Income_1 { get; set; }

        public int? CompanyCityID_Main_Income_1 { get; set; }
        public string CompanyCity_Main_Income_1 { get; set; }
        public bool IsVisibleCompanyCity_Main_Income_1 { get; set; }
        public bool IsDisableCompanyCity_Main_Income_1 { get; set; }

        public string OfficeTel_Main_Income_1 { get; set; }
        public bool IsVisibleOfficeTel_Main_Income_1 { get; set; }
        public bool IsDisableOfficeTel_Main_Income_1 { get; set; }

        public int? CompanyNatureOfBusinessID_Main_Income_1 { get; set; }
        public string CompanyNatureOfBusiness_Main_Income_1 { get; set; }
        public bool IsVisibleCompanyNatureOfBusiness_Main_Income_1 { get; set; }
        public bool IsDisableCompanyNatureOfBusiness_Main_Income_1 { get; set; }

        public int? CompanyIndustryID_Main_Income_1 { get; set; }
        public string CompanyIndustry_Main_Income_1 { get; set; }
        public bool IsVisibleCompanyIndustry_Main_Income_1 { get; set; }
        public bool IsDisableCompanyIndustry_Main_Income_1 { get; set; }

        public int? OccupationID_Main_Income_1 { get; set; }
        public string Occupation_Main_Income_1 { get; set; }
        public bool IsVisibleOccupation_Main_Income_1 { get; set; }
        public bool IsDisableOccupation_Main_Income_1 { get; set; }

        public int? CurrentPositionID_Main_Income_1 { get; set; }
        public string CurrentPosition_Main_Income_1 { get; set; }
        public bool IsVisibleCurrentPosition_Main_Income_1 { get; set; }
        public bool IsDisableCurrentPosition_Main_Income_1 { get; set; }

        public int? EmploymentTypeID_Main_Income_1 { get; set; }
        public string EmploymentType_Main_Income_1 { get; set; }
        public bool IsVisibleEmploymentType_Main_Income_1 { get; set; }
        public bool IsDisableEmploymentType_Main_Income_1 { get; set; }

        public string WorkingAddress_Main_Income_1 { get; set; }
        public bool IsVisibleWorkingAddress_Main_Income_1 { get; set; }
        public bool IsDisableWorkingAddress_Main_Income_1 { get; set; }

        public string WorkingWard_Main_Income_1 { get; set; }
        public bool IsVisibleWorkingWard_Main_Income_1 { get; set; }
        public bool IsDisableWorkingWard_Main_Income_1 { get; set; }

        public int? DistrictWorkingID_Main_Income_1 { get; set; }
        public string District_Working_Main_Income_1 { get; set; }
        public bool IsVisibleDistrict_Working_Main_Income_1 { get; set; }
        public bool IsDisableDistrict_Working_Main_Income_1 { get; set; }

        public int? CityWorkingID_Main_Income_1 { get; set; }
        public string City_Working_Main_Income_1 { get; set; }
        public bool IsVisibleCity_Working_Main_Income_1 { get; set; }
        public bool IsDisableCity_Working_Main_Income_1 { get; set; }

        public decimal? PercentSharesInCompany_Main_Income_1 { get; set; }
        public bool IsVisiblePercentSharesInCompany_Main_Income_1 { get; set; }
        public bool IsDisablePercentSharesInCompany_Main_Income_1 { get; set; }

        public int? TypeOfLabourContractID_Main_Income_1 { get; set; }
        public string TypeOfLabourContract_Main_Income_1 { get; set; }
        public bool IsVisibleTypeOfLabourContract_Main_Income_1 { get; set; }
        public bool IsDisableTypeOfLabourContract_Main_Income_1 { get; set; }

        public int? ContractLengthID_Main_Income_1 { get; set; }
        public string ContractLength_Main_Income_1 { get; set; }
        public bool IsVisibleContractLength_Main_Income_1 { get; set; }
        public bool IsDisableContractLength_Main_Income_1 { get; set; }

        public Nullable<System.DateTime> StartDateAtCurrentCompany_Main_Income_1 { get; set; }
        public bool IsVisibleStartDateAtCurrentCompany_Main_Income_1 { get; set; }
        public bool IsDisableStartDateAtCurrentCompany_Main_Income_1 { get; set; }

        public int? TotalMonthsInCurrentCompany_Main_Income_1 { get; set; }
        public bool IsVisibleTotalMonthsInCurrentCompany_Main_Income_1 { get; set; }
        public bool IsDisableTotalMonthsInCurrentCompany_Main_Income_1 { get; set; }

        public int? TotalMonthsInWorkingExperience_Main_Income_1 { get; set; }
        public bool IsVisibleTotalMonthsInWorkingExperience_Main_Income_1 { get; set; }
        public bool IsDisableTotalMonthsInWorkingExperience_Main_Income_1 { get; set; }

        public int? IncometypeID_Main_Income_1 { get; set; }
        public string Incometype_Main_Income_1 { get; set; }
        public bool IsVisibleIncometype_Main_Income_1 { get; set; }
        public bool IsDisableIncometype_Main_Income_1 { get; set; }

        public decimal? MonthlyIncomeDeclared_Main_Income_1 { get; set; }
        public bool IsVisibleMonthlyIncomeDeclared_Main_Income_1 { get; set; }
        public bool IsDisableMonthlyIncomeDeclared_Main_Income_1 { get; set; }

        public int? PeriodOfSubmittedBSID_Main_Income_1 { get; set; }
        public string PeriodOfSubmittedBS_Main_Income_1 { get; set; }
        public bool IsVisiblePeriodOfSubmittedBS_Main_Income_1 { get; set; }
        public bool IsDisablePeriodOfSubmittedBS_Main_Income_1 { get; set; }

        public bool FreelanceIncome_Main_Income_1 { get; set; }
        public bool IsVisibleFreelanceIncome_Main_Income_1 { get; set; }
        public bool IsDisableFreelanceIncome_Main_Income_1 { get; set; }

        public decimal? GrossBaseSalary_Main_Income_1 { get; set; }
        public bool IsVisibleGrossBaseSalary_Main_Income_1 { get; set; }
        public bool IsDisableGrossBaseSalary_Main_Income_1 { get; set; }

        public decimal? BasicAllowance_Main_Income_1 { get; set; }
        public bool IsVisibleBasicAllowance_Main_Income_1 { get; set; }
        public bool IsDisableBasicAllowance_Main_Income_1 { get; set; }

        public decimal? EligibleFixedIncomeOnLC_Main_Income_1 { get; set; }
        public bool IsVisibleEligibleFixedIncomeOnLC_Main_Income_1 { get; set; }
        public bool IsDisableEligibleFixedIncomeOnLC_Main_Income_1 { get; set; }

        public decimal? FixedIncomeViaBS_Main_Income_1 { get; set; }
        public bool IsVisibleFixedIncomeViaBS_Main_Income_1 { get; set; }
        public bool IsDisableFixedIncomeViaBS_Main_Income_1 { get; set; }

        public decimal? TotalMonthlyIncomeViaBS_Main_Income_1 { get; set; }
        public bool IsVisibleTotalMonthlyIncomeViaBS_Main_Income_1 { get; set; }
        public bool IsDisableTotalMonthlyIncomeViaBS_Main_Income_1 { get; set; }

        public decimal? PerformanceBonus_Main_Income_1 { get; set; }
        public bool IsVisiblePerformanceBonus_Main_Income_1 { get; set; }
        public bool IsDisablePerformanceBonus_Main_Income_1 { get; set; }

        public decimal? FinalIncome_Main_Income_1 { get; set; }
        public bool IsVisibleFinalIncome_Main_Income_1 { get; set; }
        public bool IsDisableFinalIncome_Main_Income_1 { get; set; }

        public List<al_customer_income> lst_al_customer_income_salaried_main_income_1 { get; set; }
        public List<al_customer_bonus_monthly> lst_al_customer_bonus_salaried_main_income_1 { get; set; }
        #endregion

        #region Income2
        public int CustomerIncomeID_Main_SalariedClientIncome_2 { get; set; }
        public int ALCustomerIncomeID_Main_SalariedClientIncome_2 { get; set; }

        public int ALCustomerSalariedClientIncomeID_Main_Income_2 { get; set; }

        public int? CompanyCodeID_Main_Income_2 { get; set; }
        public string CompanyCode_Main_Income_2 { get; set; }
        public bool IsVisibleCompanyCode_Main_Income_2 { get; set; }
        public bool IsDisableCompanyCode_Main_Income_2 { get; set; }

        public string CompanyName_Main_Income_2 { get; set; }
        public bool IsVisibleCompanyName_Main_Income_2 { get; set; }
        public bool IsDisableCompanyName_Main_Income_2 { get; set; }

        public string CompanyAddress_Main_Income_2 { get; set; }
        public bool IsVisibleCompanyAddress_Main_Income_2 { get; set; }
        public bool IsDisableCompanyAddress_Main_Income_2 { get; set; }

        public string CompanyWard_Main_Income_2 { get; set; }
        public bool IsVisibleCompanyWard_Main_Income_2 { get; set; }
        public bool IsDisableCompanyWard_Main_Income_2 { get; set; }

        public int? CompanyDistrictID_Main_Income_2 { get; set; }
        public string CompanyDistrict_Main_Income_2 { get; set; }
        public bool IsVisibleCompanyDistrict_Main_Income_2 { get; set; }
        public bool IsDisableCompanyDistrict_Main_Income_2 { get; set; }

        public int? CompanyCityID_Main_Income_2 { get; set; }
        public string CompanyCity_Main_Income_2 { get; set; }
        public bool IsVisibleCompanyCity_Main_Income_2 { get; set; }
        public bool IsDisableCompanyCity_Main_Income_2 { get; set; }

        public string OfficeTel_Main_Income_2 { get; set; }
        public bool IsVisibleOfficeTel_Main_Income_2 { get; set; }
        public bool IsDisableOfficeTel_Main_Income_2 { get; set; }

        public int? CompanyNatureOfBusinessID_Main_Income_2 { get; set; }
        public string CompanyNatureOfBusiness_Main_Income_2 { get; set; }
        public bool IsVisibleCompanyNatureOfBusiness_Main_Income_2 { get; set; }
        public bool IsDisableCompanyNatureOfBusiness_Main_Income_2 { get; set; }

        public int? CompanyIndustryID_Main_Income_2 { get; set; }
        public string CompanyIndustry_Main_Income_2 { get; set; }
        public bool IsVisibleCompanyIndustry_Main_Income_2 { get; set; }
        public bool IsDisableCompanyIndustry_Main_Income_2 { get; set; }

        public int? OccupationID_Main_Income_2 { get; set; }
        public string Occupation_Main_Income_2 { get; set; }
        public bool IsVisibleOccupation_Main_Income_2 { get; set; }
        public bool IsDisableOccupation_Main_Income_2 { get; set; }

        public int? CurrentPositionID_Main_Income_2 { get; set; }
        public string CurrentPosition_Main_Income_2 { get; set; }
        public bool IsVisibleCurrentPosition_Main_Income_2 { get; set; }
        public bool IsDisableCurrentPosition_Main_Income_2 { get; set; }

        public int? EmploymentTypeID_Main_Income_2 { get; set; }
        public string EmploymentType_Main_Income_2 { get; set; }
        public bool IsVisibleEmploymentType_Main_Income_2 { get; set; }
        public bool IsDisableEmploymentType_Main_Income_2 { get; set; }

        public string WorkingAddress_Main_Income_2 { get; set; }
        public bool IsVisibleWorkingAddress_Main_Income_2 { get; set; }
        public bool IsDisableWorkingAddress_Main_Income_2 { get; set; }

        public string WorkingWard_Main_Income_2 { get; set; }
        public bool IsVisibleWorkingWard_Main_Income_2 { get; set; }
        public bool IsDisableWorkingWard_Main_Income_2 { get; set; }

        public int? DistrictWorkingID_Main_Income_2 { get; set; }
        public string District_Working_Main_Income_2 { get; set; }
        public bool IsVisibleDistrict_Working_Main_Income_2 { get; set; }
        public bool IsDisableDistrict_Working_Main_Income_2 { get; set; }

        public int? CityWorkingID_Main_Income_2 { get; set; }
        public string City_Working_Main_Income_2 { get; set; }
        public bool IsVisibleCity_Working_Main_Income_2 { get; set; }
        public bool IsDisableCity_Working_Main_Income_2 { get; set; }

        public decimal? PercentSharesInCompany_Main_Income_2 { get; set; }
        public bool IsVisiblePercentSharesInCompany_Main_Income_2 { get; set; }
        public bool IsDisablePercentSharesInCompany_Main_Income_2 { get; set; }

        public int? TypeOfLabourContractID_Main_Income_2 { get; set; }
        public string TypeOfLabourContract_Main_Income_2 { get; set; }
        public bool IsVisibleTypeOfLabourContract_Main_Income_2 { get; set; }
        public bool IsDisableTypeOfLabourContract_Main_Income_2 { get; set; }

        public int? ContractLengthID_Main_Income_2 { get; set; }
        public string ContractLength_Main_Income_2 { get; set; }
        public bool IsVisibleContractLength_Main_Income_2 { get; set; }
        public bool IsDisableContractLength_Main_Income_2 { get; set; }

        public Nullable<System.DateTime> StartDateAtCurrentCompany_Main_Income_2 { get; set; }
        public bool IsVisibleStartDateAtCurrentCompany_Main_Income_2 { get; set; }
        public bool IsDisableStartDateAtCurrentCompany_Main_Income_2 { get; set; }

        public int? TotalMonthsInCurrentCompany_Main_Income_2 { get; set; }
        public bool IsVisibleTotalMonthsInCurrentCompany_Main_Income_2 { get; set; }
        public bool IsDisableTotalMonthsInCurrentCompany_Main_Income_2 { get; set; }

        public int? TotalMonthsInWorkingExperience_Main_Income_2 { get; set; }
        public bool IsVisibleTotalMonthsInWorkingExperience_Main_Income_2 { get; set; }
        public bool IsDisableTotalMonthsInWorkingExperience_Main_Income_2 { get; set; }

        public int? IncometypeID_Main_Income_2 { get; set; }
        public string Incometype_Main_Income_2 { get; set; }
        public bool IsVisibleIncometype_Main_Income_2 { get; set; }
        public bool IsDisableIncometype_Main_Income_2 { get; set; }

        public decimal? MonthlyIncomeDeclared_Main_Income_2 { get; set; }
        public bool IsVisibleMonthlyIncomeDeclared_Main_Income_2 { get; set; }
        public bool IsDisableMonthlyIncomeDeclared_Main_Income_2 { get; set; }

        public int? PeriodOfSubmittedBSID_Main_Income_2 { get; set; }
        public string PeriodOfSubmittedBS_Main_Income_2 { get; set; }
        public bool IsVisiblePeriodOfSubmittedBS_Main_Income_2 { get; set; }
        public bool IsDisablePeriodOfSubmittedBS_Main_Income_2 { get; set; }

        public bool FreelanceIncome_Main_Income_2 { get; set; }
        public bool IsVisibleFreelanceIncome_Main_Income_2 { get; set; }
        public bool IsDisableFreelanceIncome_Main_Income_2 { get; set; }

        public decimal? GrossBaseSalary_Main_Income_2 { get; set; }
        public bool IsVisibleGrossBaseSalary_Main_Income_2 { get; set; }
        public bool IsDisableGrossBaseSalary_Main_Income_2 { get; set; }

        public decimal? BasicAllowance_Main_Income_2 { get; set; }
        public bool IsVisibleBasicAllowance_Main_Income_2 { get; set; }
        public bool IsDisableBasicAllowance_Main_Income_2 { get; set; }

        public decimal? EligibleFixedIncomeOnLC_Main_Income_2 { get; set; }
        public bool IsVisibleEligibleFixedIncomeOnLC_Main_Income_2 { get; set; }
        public bool IsDisableEligibleFixedIncomeOnLC_Main_Income_2 { get; set; }

        public decimal? FixedIncomeViaBS_Main_Income_2 { get; set; }
        public bool IsVisibleFixedIncomeViaBS_Main_Income_2 { get; set; }
        public bool IsDisableFixedIncomeViaBS_Main_Income_2 { get; set; }

        public decimal? TotalMonthlyIncomeViaBS_Main_Income_2 { get; set; }
        public bool IsVisibleTotalMonthlyIncomeViaBS_Main_Income_2 { get; set; }
        public bool IsDisableTotalMonthlyIncomeViaBS_Main_Income_2 { get; set; }

        public decimal? PerformanceBonus_Main_Income_2 { get; set; }
        public bool IsVisiblePerformanceBonus_Main_Income_2 { get; set; }
        public bool IsDisablePerformanceBonus_Main_Income_2 { get; set; }

        public decimal? FinalIncome_Main_Income_2 { get; set; }
        public bool IsVisibleFinalIncome_Main_Income_2 { get; set; }
        public bool IsDisableFinalIncome_Main_Income_2 { get; set; }

        public List<al_customer_income> lst_al_customer_income_salaried_main_Income_2 { get; set; }
        public List<al_customer_bonus_monthly> lst_al_customer_bonus_salaried_main_income_2 { get; set; }
        #endregion

        public float TotalSalariedIncome_Main { get; set; }
        public bool IsVisibleTotalSalariedIncome_Main { get; set; }
        public bool IsDisableTotalSalariedIncome_Main { get; set; }

        #endregion

        #region Rental

        #region House Rental

        #region Income1
        //public int CustomerIncomeID_Main_Income_1 { get; set; }
        //public int ALCustomerIncomeID_Main_Income_1 { get; set; }
        //public int ALCustomerSalariedIncomeID_Main_Income_1 { get; set; }
        public string DetailsOfPropertyForRent1 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent1 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent1 { get; set; }
        public string RentalPropertyAddress1 { get; set; }
        public bool IsVisibleRentalPropertyAddress1 { get; set; }
        public bool IsDisableRentalPropertyAddress1 { get; set; }
        public string RentalPropertyOwnershipName1 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName1 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName1 { get; set; }
        public string LesseeNameAddressContact1 { get; set; }
        public bool IsVisibleLesseeNameAddressContact1 { get; set; }
        public bool IsDisableLesseeNameAddressContact1 { get; set; }
        public string Ward1 { get; set; }
        public bool IsVisibleWard1 { get; set; }
        public bool IsDisableWard1 { get; set; }
        public string District1 { get; set; }
        public bool IsVisibleDistrict1 { get; set; }
        public bool IsDisableDistrict1 { get; set; }
        public int District1ID { get; set; }
        public string City1 { get; set; }
        public bool IsVisibleCity1 { get; set; }
        public bool IsDisableCity1 { get; set; }
        public int City1ID { get; set; }
        public string RentalContaclTenure1 { get; set; }
        public bool IsVisibleRentalContaclTenure1 { get; set; }
        public bool IsDisableRentalContaclTenure1 { get; set; }
        public string MonthlyRentalFee1 { get; set; }
        public bool IsVisibleMonthlyRentalFee1 { get; set; }
        public bool IsDisableMonthlyRentalFee1 { get; set; }
        public string RentalPurpose1 { get; set; }
        public bool IsVisibleRentalPurpose1 { get; set; }
        public bool IsDisableRentalPurpose1 { get; set; }
        public string RepaymentCycle1 { get; set; }
        public bool IsVisibleRepaymentCycle1 { get; set; }
        public bool IsDisableRepaymentCycle1 { get; set; }
        public int RepaymentCycle1ID { get; set; }
        public string IncomePaymentMethod1 { get; set; }
        public bool IsVisibleIncomePaymentMethod1 { get; set; }
        public bool IsDisableIncomePaymentMethod1 { get; set; }
        public int IncomePaymentMethod1ID { get; set; }
        public decimal TotalRentalIncome1 { get; set; }
        public bool IsVisibleTotalRentalIncome1 { get; set; }
        public bool IsDisableTotalRentalIncome1 { get; set; }

        #endregion

        #region Income2
        public string DetailsOfPropertyForRent2 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent2 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent2 { get; set; }
        public string RentalPropertyAddress2 { get; set; }
        public bool IsVisibleRentalPropertyAddress2 { get; set; }
        public bool IsDisableRentalPropertyAddress2 { get; set; }
        public string RentalPropertyOwnershipName2 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName2 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName2 { get; set; }
        public string LesseeNameAddressContact2 { get; set; }
        public bool IsVisibleLesseeNameAddressContact2 { get; set; }
        public bool IsDisableLesseeNameAddressContact2 { get; set; }
        public string Ward2 { get; set; }
        public bool IsVisibleWard2 { get; set; }
        public bool IsDisableWard2 { get; set; }
        public string District2 { get; set; }
        public bool IsVisibleDistrict2 { get; set; }
        public bool IsDisableDistrict2 { get; set; }
        public int District2ID { get; set; }
        public string City2 { get; set; }
        public bool IsVisibleCity2 { get; set; }
        public bool IsDisableCity2 { get; set; }
        public int City2ID { get; set; }
        public string RentalContaclTenure2 { get; set; }
        public bool IsVisibleRentalContaclTenure2 { get; set; }
        public bool IsDisableRentalContaclTenure2 { get; set; }
        public string MonthlyRentalFee2 { get; set; }
        public bool IsVisibleMonthlyRentalFee2 { get; set; }
        public bool IsDisableMonthlyRentalFee2 { get; set; }
        public string RentalPurpose2 { get; set; }
        public bool IsVisibleRentalPurpose2 { get; set; }
        public bool IsDisableRentalPurpose2 { get; set; }
        public string RepaymentCycle2 { get; set; }
        public bool IsVisibleRepaymentCycle2 { get; set; }
        public bool IsDisableRepaymentCycle2 { get; set; }
        public int RepaymentCycle2ID { get; set; }
        public string IncomePaymentMethod2 { get; set; }
        public bool IsVisibleIncomePaymentMethod2 { get; set; }
        public bool IsDisableIncomePaymentMethod2 { get; set; }
        public int IncomePaymentMethod2ID { get; set; }
        public decimal TotalRentalIncome2 { get; set; }
        public bool IsVisibleTotalRentalIncome2 { get; set; }
        public bool IsDisableTotalRentalIncome2 { get; set; }
        #endregion

        #region Income3
        public string DetailsOfPropertyForRent3 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent3 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent3 { get; set; }
        public string RentalPropertyAddress3 { get; set; }
        public bool IsVisibleRentalPropertyAddress3 { get; set; }
        public bool IsDisableRentalPropertyAddress3 { get; set; }
        public string RentalPropertyOwnershipName3 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName3 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName3 { get; set; }
        public string LesseeNameAddressContact3 { get; set; }
        public bool IsVisibleLesseeNameAddressContact3 { get; set; }
        public bool IsDisableLesseeNameAddressContact3 { get; set; }
        public string Ward3 { get; set; }
        public bool IsVisibleWard3 { get; set; }
        public bool IsDisableWard3 { get; set; }
        public string District3 { get; set; }
        public bool IsVisibleDistrict3 { get; set; }
        public bool IsDisableDistrict3 { get; set; }
        public int District3ID { get; set; }
        public string City3 { get; set; }
        public bool IsVisibleCity3 { get; set; }
        public bool IsDisableCity3 { get; set; }
        public int City3ID { get; set; }
        public string RentalContaclTenure3 { get; set; }
        public bool IsVisibleRentalContaclTenure3 { get; set; }
        public bool IsDisableRentalContaclTenure3 { get; set; }
        public string MonthlyRentalFee3 { get; set; }
        public bool IsVisibleMonthlyRentalFee3 { get; set; }
        public bool IsDisableMonthlyRentalFee3 { get; set; }
        public string RentalPurpose3 { get; set; }
        public bool IsVisibleRentalPurpose3 { get; set; }
        public bool IsDisableRentalPurpose3 { get; set; }
        public string RepaymentCycle3 { get; set; }
        public bool IsVisibleRepaymentCycle3 { get; set; }
        public bool IsDisableRepaymentCycle3 { get; set; }
        public int RepaymentCycle3ID { get; set; }
        public string IncomePaymentMethod3 { get; set; }
        public bool IsVisibleIncomePaymentMethod3 { get; set; }
        public bool IsDisableIncomePaymentMethod3 { get; set; }
        public int IncomePaymentMethod3ID { get; set; }
        public decimal TotalRentalIncome3 { get; set; }
        public bool IsVisibleTotalRentalIncome3 { get; set; }
        public bool IsDisableTotalRentalIncome3 { get; set; }
        #endregion

        #region Income4
        public string DetailsOfPropertyForRent4 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent4 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent4 { get; set; }
        public string RentalPropertyAddress4 { get; set; }
        public bool IsVisibleRentalPropertyAddress4 { get; set; }
        public bool IsDisableRentalPropertyAddress4 { get; set; }
        public string RentalPropertyOwnershipName4 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName4 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName4 { get; set; }
        public string LesseeNameAddressContact4 { get; set; }
        public bool IsVisibleLesseeNameAddressContact4 { get; set; }
        public bool IsDisableLesseeNameAddressContact4 { get; set; }
        public string Ward4 { get; set; }
        public bool IsVisibleWard4 { get; set; }
        public bool IsDisableWard4 { get; set; }
        public string District4 { get; set; }
        public bool IsVisibleDistrict4 { get; set; }
        public bool IsDisableDistrict4 { get; set; }
        public int District4ID { get; set; }
        public string City4 { get; set; }
        public bool IsVisibleCity4 { get; set; }
        public bool IsDisableCity4 { get; set; }
        public int City4ID { get; set; }
        public string RentalContaclTenure4 { get; set; }
        public bool IsVisibleRentalContaclTenure4 { get; set; }
        public bool IsDisableRentalContaclTenure4 { get; set; }
        public string MonthlyRentalFee4 { get; set; }
        public bool IsVisibleMonthlyRentalFee4 { get; set; }
        public bool IsDisableMonthlyRentalFee4 { get; set; }
        public string RentalPurpose4 { get; set; }
        public bool IsVisibleRentalPurpose4 { get; set; }
        public bool IsDisableRentalPurpose4 { get; set; }
        public string RepaymentCycle4 { get; set; }
        public bool IsVisibleRepaymentCycle4 { get; set; }
        public bool IsDisableRepaymentCycle4 { get; set; }
        public int RepaymentCycle4ID { get; set; }
        public string IncomePaymentMethod4 { get; set; }
        public bool IsVisibleIncomePaymentMethod4 { get; set; }
        public bool IsDisableIncomePaymentMethod4 { get; set; }
        public int IncomePaymentMethod4ID { get; set; }
        public decimal TotalRentalIncome4 { get; set; }
        public bool IsVisibleTotalRentalIncome4 { get; set; }
        public bool IsDisableTotalRentalIncome4 { get; set; }
        #endregion

        #region Income5
        public string DetailsOfPropertyForRent5 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent5 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent5 { get; set; }
        public string RentalPropertyAddress5 { get; set; }
        public bool IsVisibleRentalPropertyAddress5 { get; set; }
        public bool IsDisableRentalPropertyAddress5 { get; set; }
        public string RentalPropertyOwnershipName5 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName5 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName5 { get; set; }
        public string LesseeNameAddressContact5 { get; set; }
        public bool IsVisibleLesseeNameAddressContact5 { get; set; }
        public bool IsDisableLesseeNameAddressContact5 { get; set; }
        public string Ward5 { get; set; }
        public bool IsVisibleWard5 { get; set; }
        public bool IsDisableWard5 { get; set; }
        public string District5 { get; set; }
        public bool IsVisibleDistrict5 { get; set; }
        public bool IsDisableDistrict5 { get; set; }
        public int District5ID { get; set; }
        public string City5 { get; set; }
        public bool IsVisibleCity5 { get; set; }
        public bool IsDisableCity5 { get; set; }
        public int City5ID { get; set; }
        public string RentalContaclTenure5 { get; set; }
        public bool IsVisibleRentalContaclTenure5 { get; set; }
        public bool IsDisableRentalContaclTenure5 { get; set; }
        public string MonthlyRentalFee5 { get; set; }
        public bool IsVisibleMonthlyRentalFee5 { get; set; }
        public bool IsDisableMonthlyRentalFee5 { get; set; }
        public string RentalPurpose5 { get; set; }
        public bool IsVisibleRentalPurpose5 { get; set; }
        public bool IsDisableRentalPurpose5 { get; set; }
        public string RepaymentCycle5 { get; set; }
        public bool IsVisibleRepaymentCycle5 { get; set; }
        public bool IsDisableRepaymentCycle5 { get; set; }
        public int RepaymentCycle5ID { get; set; }
        public string IncomePaymentMethod5 { get; set; }
        public bool IsVisibleIncomePaymentMethod5 { get; set; }
        public bool IsDisableIncomePaymentMethod5 { get; set; }
        public int IncomePaymentMethod5ID { get; set; }
        public decimal TotalRentalIncome5 { get; set; }
        public bool IsVisibleTotalRentalIncome5 { get; set; }
        public bool IsDisableTotalRentalIncome5 { get; set; }
        #endregion

        #region Income6
        public string DetailsOfPropertyForRent6 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent6 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent6 { get; set; }
        public string RentalPropertyAddress6 { get; set; }
        public bool IsVisibleRentalPropertyAddress6 { get; set; }
        public bool IsDisableRentalPropertyAddress6 { get; set; }
        public string RentalPropertyOwnershipName6 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName6 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName6 { get; set; }
        public string LesseeNameAddressContact6 { get; set; }
        public bool IsVisibleLesseeNameAddressContact6 { get; set; }
        public bool IsDisableLesseeNameAddressContact6 { get; set; }
        public string Ward6 { get; set; }
        public bool IsVisibleWard6 { get; set; }
        public bool IsDisableWard6 { get; set; }
        public string District6 { get; set; }
        public bool IsVisibleDistrict6 { get; set; }
        public bool IsDisableDistrict6 { get; set; }
        public int District6ID { get; set; }
        public string City6 { get; set; }
        public bool IsVisibleCity6 { get; set; }
        public bool IsDisableCity6 { get; set; }
        public int City6ID { get; set; }
        public string RentalContaclTenure6 { get; set; }
        public bool IsVisibleRentalContaclTenure6 { get; set; }
        public bool IsDisableRentalContaclTenure6 { get; set; }
        public string MonthlyRentalFee6 { get; set; }
        public bool IsVisibleMonthlyRentalFee6 { get; set; }
        public bool IsDisableMonthlyRentalFee6 { get; set; }
        public string RentalPurpose6 { get; set; }
        public bool IsVisibleRentalPurpose6 { get; set; }
        public bool IsDisableRentalPurpose6 { get; set; }
        public string RepaymentCycle6 { get; set; }
        public bool IsVisibleRepaymentCycle6 { get; set; }
        public bool IsDisableRepaymentCycle6 { get; set; }
        public int RepaymentCycle6ID { get; set; }
        public string IncomePaymentMethod6 { get; set; }
        public bool IsVisibleIncomePaymentMethod6 { get; set; }
        public bool IsDisableIncomePaymentMethod6 { get; set; }
        public int IncomePaymentMethod6ID { get; set; }
        public decimal TotalRentalIncome6 { get; set; }
        public bool IsVisibleTotalRentalIncome6 { get; set; }
        public bool IsDisableTotalRentalIncome6 { get; set; }
        #endregion

        #endregion

        #region Car Rental

        #region Income1
        public string DetailsOfCarforRent1 { get; set; }
        public bool IsVisibleDetailsOfCarforRent1 { get; set; }
        public bool IsDisableDetailsOfCarforRent1 { get; set; }
        public string TypeOfCar1 { get; set; }
        public bool IsVisibleTypeOfCar1 { get; set; }
        public bool IsDisableTypeOfCar1 { get; set; }
        public string CarPlateNumber1 { get; set; }
        public bool IsVisibleCarPlateNumber1 { get; set; }
        public bool IsDisableCarPlateNumber1 { get; set; }
        public string CarOwnershipName1 { get; set; }
        public bool IsVisibleCarOwnershipName1 { get; set; }
        public bool IsDisableCarOwnershipName1 { get; set; }
        public string CarLesseeNameAddressContact1 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact1 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact1 { get; set; }
        public string RentalContractTenure1 { get; set; }
        public bool IsVisibleRentalContractTenure1 { get; set; }
        public bool IsDisableRentalContractTenure1 { get; set; }
        public string CarMonthlyRentalFee1 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee1 { get; set; }
        public bool IsCarDisableMonthlyRentalFee1 { get; set; }
        public string CarRepaymentCycle1 { get; set; }
        public bool IsCarVisibleRepaymentCycle1 { get; set; }
        public bool IsCarDisableRepaymentCycle1 { get; set; }
        public int CarRepaymentCycle1ID { get; set; }
        public string CarIncomePaymentMethod1 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod1 { get; set; }
        public bool IsCarDisableIncomePaymentMethod1 { get; set; }
        public int CarIncomePaymentMethod1ID { get; set; }
        public decimal TotalCarRentalIncome1 { get; set; }
        public bool IsVisibleTotalCarRentalIncome1 { get; set; }
        public bool IsDisableTotalCarRentalIncome1 { get; set; }
        #endregion

        #region Income2
        public string DetailsOfCarforRent2 { get; set; }
        public bool IsVisibleDetailsOfCarforRent2 { get; set; }
        public bool IsDisableDetailsOfCarforRent2 { get; set; }
        public string TypeOfCar2 { get; set; }
        public bool IsVisibleTypeOfCar2 { get; set; }
        public bool IsDisableTypeOfCar2 { get; set; }
        public string CarPlateNumber2 { get; set; }
        public bool IsVisibleCarPlateNumber2 { get; set; }
        public bool IsDisableCarPlateNumber2 { get; set; }
        public string CarOwnershipName2 { get; set; }
        public bool IsVisibleCarOwnershipName2 { get; set; }
        public bool IsDisableCarOwnershipName2 { get; set; }
        public string CarLesseeNameAddressContact2 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact2 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact2 { get; set; }
        public string RentalContractTenure2 { get; set; }
        public bool IsVisibleRentalContractTenure2 { get; set; }
        public bool IsDisableRentalContractTenure2 { get; set; }
        public string CarMonthlyRentalFee2 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee2 { get; set; }
        public bool IsCarDisableMonthlyRentalFee2 { get; set; }
        public string CarRepaymentCycle2 { get; set; }
        public bool IsCarVisibleRepaymentCycle2 { get; set; }
        public bool IsCarDisableRepaymentCycle2 { get; set; }
        public int CarRepaymentCycle2ID { get; set; }
        public string CarIncomePaymentMethod2 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod2 { get; set; }
        public bool IsCarDisableIncomePaymentMethod2 { get; set; }
        public int CarIncomePaymentMethod2ID { get; set; }
        public decimal TotalCarRentalIncome2 { get; set; }
        public bool IsVisibleTotalCarRentalIncome2 { get; set; }
        public bool IsDisableTotalCarRentalIncome2 { get; set; }
        #endregion

        #region Income3
        public string DetailsOfCarforRent3 { get; set; }
        public bool IsVisibleDetailsOfCarforRent3 { get; set; }
        public bool IsDisableDetailsOfCarforRent3 { get; set; }
        public string TypeOfCar3 { get; set; }
        public bool IsVisibleTypeOfCar3 { get; set; }
        public bool IsDisableTypeOfCar3 { get; set; }
        public string CarPlateNumber3 { get; set; }
        public bool IsVisibleCarPlateNumber3 { get; set; }
        public bool IsDisableCarPlateNumber3 { get; set; }
        public string CarOwnershipName3 { get; set; }
        public bool IsVisibleCarOwnershipName3 { get; set; }
        public bool IsDisableCarOwnershipName3 { get; set; }
        public string CarLesseeNameAddressContact3 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact3 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact3 { get; set; }
        public string RentalContractTenure3 { get; set; }
        public bool IsVisibleRentalContractTenure3 { get; set; }
        public bool IsDisableRentalContractTenure3 { get; set; }
        public string CarMonthlyRentalFee3 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee3 { get; set; }
        public bool IsCarDisableMonthlyRentalFee3 { get; set; }
        public string CarRepaymentCycle3 { get; set; }
        public bool IsCarVisibleRepaymentCycle3 { get; set; }
        public bool IsCarDisableRepaymentCycle3 { get; set; }
        public int CarRepaymentCycle3ID { get; set; }
        public string CarIncomePaymentMethod3 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod3 { get; set; }
        public bool IsCarDisableIncomePaymentMethod3 { get; set; }
        public int CarIncomePaymentMethod3ID { get; set; }
        public decimal TotalCarRentalIncome3 { get; set; }
        public bool IsVisibleTotalCarRentalIncome3 { get; set; }
        public bool IsDisableTotalCarRentalIncome3 { get; set; }
        #endregion

        #region Income4
        public string DetailsOfCarforRent4 { get; set; }
        public bool IsVisibleDetailsOfCarforRent4 { get; set; }
        public bool IsDisableDetailsOfCarforRent4 { get; set; }
        public string TypeOfCar4 { get; set; }
        public bool IsVisibleTypeOfCar4 { get; set; }
        public bool IsDisableTypeOfCar4 { get; set; }
        public string CarPlateNumber4 { get; set; }
        public bool IsVisibleCarPlateNumber4 { get; set; }
        public bool IsDisableCarPlateNumber4 { get; set; }
        public string CarOwnershipName4 { get; set; }
        public bool IsVisibleCarOwnershipName4 { get; set; }
        public bool IsDisableCarOwnershipName4 { get; set; }
        public string CarLesseeNameAddressContact4 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact4 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact4 { get; set; }
        public string RentalContractTenure4 { get; set; }
        public bool IsVisibleRentalContractTenure4 { get; set; }
        public bool IsDisableRentalContractTenure4 { get; set; }
        public string CarMonthlyRentalFee4 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee4 { get; set; }
        public bool IsCarDisableMonthlyRentalFee4 { get; set; }
        public string CarRepaymentCycle4 { get; set; }
        public bool IsCarVisibleRepaymentCycle4 { get; set; }
        public bool IsCarDisableRepaymentCycle4 { get; set; }
        public int CarRepaymentCycle4ID { get; set; }
        public string CarIncomePaymentMethod4 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod4 { get; set; }
        public bool IsCarDisableIncomePaymentMethod4 { get; set; }
        public int CarIncomePaymentMethod4ID { get; set; }
        public decimal TotalCarRentalIncome4 { get; set; }
        public bool IsVisibleTotalCarRentalIncome4 { get; set; }
        public bool IsDisableTotalCarRentalIncome4 { get; set; }
        #endregion

        #endregion

        #endregion

        #region SelfEmployed

        #region Income1
        public string CompanyName1 { get; set; }
        public bool IsVisibleCompanyName1 { get; set; }
        public bool IsDisableCompanyName1 { get; set; }
        public string BusinessLicenceNumber1 { get; set; }
        public bool IsVisibleBusinessLicenceNumber1 { get; set; }
        public bool IsDisableBusinessLicenceNumber1 { get; set; }
        public string TaxCode1 { get; set; }
        public bool IsVisibleTaxCode1 { get; set; }
        public bool IsDisableTaxCode1 { get; set; }
        public string CompanyAddress1 { get; set; }
        public bool IsVisibleCompanyAddress1 { get; set; }
        public bool IsDisableCompanyAddress1 { get; set; }
        public string SelfWard1 { get; set; }
        public bool IsVisibleSelfWard1 { get; set; }
        public bool IsDisableSelfWard1 { get; set; }
        public string DisTrict1 { get; set; }
        public bool IsVisibleDisTrict1 { get; set; }
        public bool IsDisableDisTrict1 { get; set; }
        public int DisTrict1ID { get; set; }
        public string SelfCity1 { get; set; }
        public bool IsVisibleSelfCity1 { get; set; }
        public bool IsDisableSelfCity1 { get; set; }
        public string SelfCity1ID { get; set; }
        public string Ofcetel1 { get; set; }
        public bool IsVisibleOfcetel1 { get; set; }
        public bool IsDisableOfcetel1 { get; set; }
        public string MainCompanyIndustry11 { get; set; }
        public bool IsVisibleMainCompanyIndustry11 { get; set; }
        public bool IsDisableMainCompanyIndustry11 { get; set; }
        public int MainCompanyIndustry11ID { get; set; }
        public string MainCompanyIndustry21 { get; set; }
        public bool IsVisibleMainCompanyIndustry21 { get; set; }
        public bool IsDisableMainCompanyIndustry21 { get; set; }
        public int MainCompanyIndustry21ID { get; set; }
        public string OtherCompanyIndustryBizNature1 { get; set; }
        public bool IsVisibleOtherCompanyIndustryBizNature1 { get; set; }
        public bool IsDisableOtherCompanyIndustryBizNature1 { get; set; }
        public string SeasonalIndustry1 { get; set; }
        public bool IsVisibleSeasonalIndustry1 { get; set; }
        public bool IsDisableSeasonalIndustry1 { get; set; }
        public Nullable<DateTime> EstablishedYear1 { get; set; }
        public bool IsVisibleEstablishedYear1 { get; set; }
        public bool IsDisableEstablishedYear1 { get; set; }
        public int TotalYearsInOperation1 { get; set; }
        public bool IsVisibleTotalYearsInOperation1 { get; set; }
        public bool IsDisableTotalYearsInOperation1 { get; set; }
        public int ShareholdingInCompany1 { get; set; }
        public bool IsVisibleShareholdingInCompany1 { get; set; }
        public bool IsDisableShareholdingInCompany1 { get; set; }
        public string ProfLossinLatestYear1 { get; set; }
        public bool IsVisibleProfLossinLatestYear1 { get; set; }
        public bool IsDisableProfLossinLatestYear1 { get; set; }
        public int ProfLossinLatestYear1ID { get; set; }
        public string TypeOfSelfEmploymentIncome1 { get; set; }
        public bool IsVisibleTypeOfSelfEmploymentIncome1 { get; set; }
        public bool IsDisableTypeOfSelfEmploymentIncome1 { get; set; }
        public int TypeOfSelfEmploymentIncome1ID { get; set; }
        public int TotalTurnoverinFS1 { get; set; }
        public bool IsVisibleTotalTurnoverinFS1 { get; set; }
        public bool IsDisableTotalTurnoverinFS1 { get; set; }
        public decimal MonthlyTurnoverinyear1 { get; set; }
        public bool IsVisibleMonthlyTurnoverinyear1 { get; set; }
        public bool IsDisableMonthlyTurnoverinyear1 { get; set; }
        /// <summary>
        /// /////
        /// </summary>
        /// 
        public decimal TotalUpdatedTurnover1 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover1 { get; set; }
        public bool IsDisableTotalUpdatedTurnover1 { get; set; }
        public decimal AverageMonthlyUpdatedTurnover1 { get; set; }
        public bool IsVisibleAverageMonthlyUpdatedTurnover1 { get; set; }
        public bool IsDisableAverageMonthlyUpdatedTurnover1 { get; set; }
        public decimal ComparedWithTurnOver1 { get; set; }
        public bool IsVisibleComparedWithTurnOver1 { get; set; }
        public bool IsDisableComparedWithTurnOver1 { get; set; }
        public decimal RevisedAverageMonthlyTurnover1 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnover1 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnover1 { get; set; }
        public int SplitupIndustry11 { get; set; }
        public bool IsVisibleSplitupIndustry11 { get; set; }
        public bool IsDisableSplitupIndustry11 { get; set; }
        public int SplitupIndustry21 { get; set; }
        public bool IsVisibleSplitupIndustry21 { get; set; }
        public bool IsDisableSplitupIndustry21 { get; set; }
        public int SplitupIndustry31 { get; set; }
        public bool IsVisibleSplitupIndustry31 { get; set; }
        public bool IsDisableSplitupIndustry31 { get; set; }
        public int IndustrialMargin11 { get; set; }
        public bool IsVisibleIndustrialMargin11 { get; set; }
        public bool IsDisableIndustrialMargin11 { get; set; }
        public int IndustrialMargin21 { get; set; }
        public bool IsVisibleIndustrialMargin21 { get; set; }
        public bool IsDisableIndustrialMargin21 { get; set; }
        public int IndustrialMargin31 { get; set; }
        public bool IsVisibleIndustrialMargin31 { get; set; }
        public bool IsDisableIndustrialMargin31 { get; set; }
        public string Remark1 { get; set; }
        public bool IsVisibleRemark1 { get; set; }
        public bool IsDisableRemark1 { get; set; }
        public decimal MonthlySeflEmployedIncome1 { get; set; }
        public bool IsVisibleMonthlySeflEmployedIncome1 { get; set; }
        public bool IsDisableMonthlySeflEmployedIncome1 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncome1 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncome1 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncome1 { get; set; }
        public int TotalTurnoverinFSBank1 { get; set; }
        public bool IsVisibleTotalTurnoverinFSBank1 { get; set; }
        public bool IsDisableTotalTurnoverinFSBank1 { get; set; }
        public decimal MonthlyTurnoverInyearBank1 { get; set; }
        public bool IsVisibleMonthlyTurnoverInyearBank1 { get; set; }
        public bool IsDisableMonthlyTurnoverInyearBank1 { get; set; }
        public int OtherMonthlyTurnover1 { get; set; }
        public bool IsVisibleOtherMonthlyTurnover1 { get; set; }
        public bool IsDisableOtherMonthlyTurnover1 { get; set; }
        public decimal AverageEligibleCreditBalance1 { get; set; }
        public bool IsVisibleAverageEligibleCreditBalance1 { get; set; }
        public bool IsDisableAverageEligibleCreditBalance1 { get; set; }
        public decimal TotalEligibleMonthlyIncome1 { get; set; }
        public bool IsVisibleTotalEligibleMonthlyIncome1 { get; set; }
        public bool IsDisableTotalEligibleMonthlyIncome1 { get; set; }
        public decimal RevisedAverageMonthlyTurnoverBank1 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnoverBank1 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnoverBank1 { get; set; }
        public int SplitupIndustry1Bank1 { get; set; }
        public bool IsVisibleSplitupIndustry1Bank1 { get; set; }
        public bool IsDisableSplitupIndustry1Bank1 { get; set; }
        public int SplitupIndustry2Bank1 { get; set; }
        public bool IsVisibleSplitupIndustry2Bank1 { get; set; }
        public bool IsDisableSplitupIndustry2Bank1 { get; set; }
        public int SplitupIndustry3Bank1 { get; set; }
        public bool IsVisibleSplitupIndustry3Bank1 { get; set; }
        public bool IsDisableSplitupIndustry3Bank1 { get; set; }
        public int IndustrialMargin1Bank1 { get; set; }
        public bool IsVisibleIndustrialMargin1Bank1 { get; set; }
        public bool IsDisableIndustrialMargin1Bank1 { get; set; }
        public int IndustrialMargin2Bank1 { get; set; }
        public bool IsVisibleIndustrialMargin2Bank1 { get; set; }
        public bool IsDisableIndustrialMargin2Bank1 { get; set; }
        public int IndustrialMargin3Bank1 { get; set; }
        public bool IsVisibleIndustrialMargin3Bank1 { get; set; }
        public bool IsDisableIndustrialMargin3Bank1 { get; set; }
        public string RemarkBank1 { get; set; }
        public bool IsVisibleRemarkBank1 { get; set; }
        public bool IsDisableRemarkBank1 { get; set; }
        public decimal MonthlySelfEmployedIncome1 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncome1 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncome1 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeBank1 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeBank1 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeBank1 { get; set; }
        public int TotalTurnoverInFS1 { get; set; }
        public bool IsVisibleTotalTurnoverInFS1 { get; set; }
        public bool IsDisableTotalTurnoverInFS1 { get; set; }
        public int ProftafertaxinLatestYear1 { get; set; }
        public bool IsVisibleProftafertaxinLatestYear1 { get; set; }
        public bool IsDisableProftafertaxinLatestYear1 { get; set; }
        public int Depreciation1 { get; set; }
        public bool IsVisibleDepreciation1 { get; set; }
        public bool IsDisableDepreciation1 { get; set; }
        public decimal MonthlyTurnoverInYear1 { get; set; }
        public bool IsVisibleMonthlyTurnoverInYear1 { get; set; }
        public bool IsDisableMonthlyTurnoverInYear1 { get; set; }
        public decimal MonthlySelfEmployedIncomeCPP1 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncomeCPP1 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncomeCPP1 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeCPP1 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeCPP1 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeCPP1 { get; set; }

        #endregion

        #region Income2
        public string CompanyName2 { get; set; }
        public bool IsVisibleCompanyName2 { get; set; }
        public bool IsDisableCompanyName2 { get; set; }
        public string BusinessLicenceNumber2 { get; set; }
        public bool IsVisibleBusinessLicenceNumber2 { get; set; }
        public bool IsDisableBusinessLicenceNumber2 { get; set; }
        public string TaxCode2 { get; set; }
        public bool IsVisibleTaxCode2 { get; set; }
        public bool IsDisableTaxCode2 { get; set; }
        public string CompanyAddress2 { get; set; }
        public bool IsVisibleCompanyAddress2 { get; set; }
        public bool IsDisableCompanyAddress2 { get; set; }
        public string SelfWard2 { get; set; }
        public bool IsVisibleSelfWard2 { get; set; }
        public bool IsDisableSelfWard2 { get; set; }
        public string DisTrict2 { get; set; }
        public bool IsVisibleDisTrict2 { get; set; }
        public bool IsDisableDisTrict2 { get; set; }
        public int DisTrict2ID { get; set; }
        public string SelfCity2 { get; set; }
        public bool IsVisibleSelfCity2 { get; set; }
        public bool IsDisableSelfCity2 { get; set; }
        public string SelfCity2ID { get; set; }
        public string Ofcetel2 { get; set; }
        public bool IsVisibleOfcetel2 { get; set; }
        public bool IsDisableOfcetel2 { get; set; }
        public string MainCompanyIndustry12 { get; set; }
        public bool IsVisibleMainCompanyIndustry12 { get; set; }
        public bool IsDisableMainCompanyIndustry12 { get; set; }
        public int MainCompanyIndustry12ID { get; set; }
        public string MainCompanyIndustry22 { get; set; }
        public bool IsVisibleMainCompanyIndustry22 { get; set; }
        public bool IsDisableMainCompanyIndustry22 { get; set; }
        public int MainCompanyIndustry22ID { get; set; }
        public string OtherCompanyIndustryBizNature2 { get; set; }
        public bool IsVisibleOtherCompanyIndustryBizNature2 { get; set; }
        public bool IsDisableOtherCompanyIndustryBizNature2 { get; set; }
        public string SeasonalIndustry2 { get; set; }
        public bool IsVisibleSeasonalIndustry2 { get; set; }
        public bool IsDisableSeasonalIndustry2 { get; set; }
        public Nullable<DateTime> EstablishedYear2 { get; set; }
        public bool IsVisibleEstablishedYear2 { get; set; }
        public bool IsDisableEstablishedYear2 { get; set; }
        public int TotalYearsInOperation2 { get; set; }
        public bool IsVisibleTotalYearsInOperation2 { get; set; }
        public bool IsDisableTotalYearsInOperation2 { get; set; }
        public int ShareholdingInCompany2 { get; set; }
        public bool IsVisibleShareholdingInCompany2 { get; set; }
        public bool IsDisableShareholdingInCompany2 { get; set; }
        public string ProfLossinLatestYear2 { get; set; }
        public bool IsVisibleProfLossinLatestYear2 { get; set; }
        public bool IsDisableProfLossinLatestYear2 { get; set; }
        public int ProfLossinLatestYear2ID { get; set; }
        public string TypeOfSelfEmploymentIncome2 { get; set; }
        public bool IsVisibleTypeOfSelfEmploymentIncome2 { get; set; }
        public bool IsDisableTypeOfSelfEmploymentIncome2 { get; set; }
        public int TypeOfSelfEmploymentIncome2ID { get; set; }
        public int TotalTurnoverinFS2 { get; set; }
        public bool IsVisibleTotalTurnoverinFS2 { get; set; }
        public bool IsDisableTotalTurnoverinFS2 { get; set; }
        public decimal MonthlyTurnoverinyear2 { get; set; }
        public bool IsVisibleMonthlyTurnoverinyear2 { get; set; }
        public bool IsDisableMonthlyTurnoverinyear2 { get; set; }
        /// <summary>
        /// ////
        /// </summary>
        /// 
        public decimal TotalUpdatedTurnover2 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover2 { get; set; }
        public bool IsDisableTotalUpdatedTurnover2 { get; set; }
        public decimal AverageMonthlyUpdatedTurnover2 { get; set; }
        public bool IsVisibleAverageMonthlyUpdatedTurnover2 { get; set; }
        public bool IsDisableAverageMonthlyUpdatedTurnover2 { get; set; }
        public decimal ComparedWithTurnOverBank2 { get; set; }
        public bool IsVisibleComparedWithTurnOverbank2 { get; set; }
        public bool IsDisableComparedWithTurnOverBank2 { get; set; }
        public decimal RevisedAverageMonthlyTurnover2 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnover2 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnover2 { get; set; }
        public int SplitupIndustry12 { get; set; }
        public bool IsVisibleSplitupIndustry12 { get; set; }
        public bool IsDisableSplitupIndustry12 { get; set; }
        public int SplitupIndustry22 { get; set; }
        public bool IsVisibleSplitupIndustry22 { get; set; }
        public bool IsDisableSplitupIndustry22 { get; set; }
        public int SplitupIndustry32 { get; set; }
        public bool IsVisibleSplitupIndustry32 { get; set; }
        public bool IsDisableSplitupIndustry32 { get; set; }
        public int IndustrialMargin12 { get; set; }
        public bool IsVisibleIndustrialMargin12 { get; set; }
        public bool IsDisableIndustrialMargin12 { get; set; }
        public int IndustrialMargin22 { get; set; }
        public bool IsVisibleIndustrialMargin22 { get; set; }
        public bool IsDisableIndustrialMargin22 { get; set; }
        public int IndustrialMargin32 { get; set; }
        public bool IsVisibleIndustrialMargin32 { get; set; }
        public bool IsDisableIndustrialMargin32 { get; set; }
        public string Remark2 { get; set; }
        public bool IsVisibleRemark2 { get; set; }
        public bool IsDisableRemark2 { get; set; }
        public decimal MonthlySeflEmployedIncome2 { get; set; }
        public bool IsVisibleMonthlySeflEmployedIncome2 { get; set; }
        public bool IsDisableMonthlySeflEmployedIncome2 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncome2 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncome2 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncome2 { get; set; }
        public int TotalTurnoverinFSBank2 { get; set; }
        public bool IsVisibleTotalTurnoverinFSBank2 { get; set; }
        public bool IsDisableTotalTurnoverinFSBank2 { get; set; }
        public decimal MonthlyTurnoverInyearBank2 { get; set; }
        public bool IsVisibleMonthlyTurnoverInyearBank2 { get; set; }
        public bool IsDisableMonthlyTurnoverInyearBank2 { get; set; }
        public int OtherMonthlyTurnover2 { get; set; }
        public bool IsVisibleOtherMonthlyTurnover2 { get; set; }
        public bool IsDisableOtherMonthlyTurnover2 { get; set; }
        public decimal AverageEligibleCreditBalance2 { get; set; }
        public bool IsVisibleAverageEligibleCreditBalance2 { get; set; }
        public bool IsDisableAverageEligibleCreditBalance2 { get; set; }
        public decimal TotalEligibleMonthlyIncome2 { get; set; }
        public bool IsVisibleTotalEligibleMonthlyIncome2 { get; set; }
        public bool IsDisableTotalEligibleMonthlyIncome2 { get; set; }
        public decimal RevisedAverageMonthlyTurnoverBank2 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnoverBank2 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnoverBank2 { get; set; }
        public int SplitupIndustry1Bank2 { get; set; }
        public bool IsVisibleSplitupIndustry1Bank2 { get; set; }
        public bool IsDisableSplitupIndustry1Bank2 { get; set; }
        public int SplitupIndustry2Bank2 { get; set; }
        public bool IsVisibleSplitupIndustry2Bank2 { get; set; }
        public bool IsDisableSplitupIndustry2Bank2 { get; set; }
        public int SplitupIndustry3Bank2 { get; set; }
        public bool IsVisibleSplitupIndustry3Bank2 { get; set; }
        public bool IsDisableSplitupIndustry3Bank2 { get; set; }
        public int IndustrialMargin1Bank2 { get; set; }
        public bool IsVisibleIndustrialMargin1Bank2 { get; set; }
        public bool IsDisableIndustrialMargin1Bank2 { get; set; }
        public int IndustrialMargin2Bank2 { get; set; }
        public bool IsVisibleIndustrialMargin2Bank2 { get; set; }
        public bool IsDisableIndustrialMargin2Bank2 { get; set; }
        public int IndustrialMargin3Bank2 { get; set; }
        public bool IsVisibleIndustrialMargin3Bank2 { get; set; }
        public bool IsDisableIndustrialMargin3Bank2 { get; set; }
        public string RemarkBank2 { get; set; }
        public bool IsVisibleRemarkBank2 { get; set; }
        public bool IsDisableRemarkBank2 { get; set; }
        public decimal MonthlySelfEmployedIncome2 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncome2 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncome2 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeBank2 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeBank2 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeBank2 { get; set; }
        public int TotalTurnoverInFS2 { get; set; }
        public bool IsVisibleTotalTurnoverInFS2 { get; set; }
        public bool IsDisableTotalTurnoverInFS2 { get; set; }
        public int ProftafertaxinLatestYear2 { get; set; }
        public bool IsVisibleProftafertaxinLatestYear2 { get; set; }
        public bool IsDisableProftafertaxinLatestYear2 { get; set; }
        public int Depreciation2 { get; set; }
        public bool IsVisibleDepreciation2 { get; set; }
        public bool IsDisableDepreciation2 { get; set; }
        public decimal MonthlyTurnoverInYear2 { get; set; }
        public bool IsVisibleMonthlyTurnoverInYear2 { get; set; }
        public bool IsDisableMonthlyTurnoverInYear2 { get; set; }
        public decimal MonthlySelfEmployedIncomeCPP2 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncomeCPP2 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncomeCPP2 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeCPP2 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeCPP2 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeCPP2 { get; set; }
        #endregion

        #endregion

        #region Other

        #region Income1
        public int DiscountRate1 { get; set; }
        public bool IsVisibleDiscountRate1 { get; set; }
        public bool IsDisableDiscountRate1 { get; set; }
        public decimal TotalUpdatedTurnover1_other { get; set; }
        public bool IsVisibleTotalUpdatedTurnover1_other { get; set; }
        public bool IsDisableTotalUpdatedTurnover1_other { get; set; }

        #endregion

        #region Income2
        public int DiscountRate2 { get; set; }
        public bool IsVisibleDiscountRate2 { get; set; }
        public bool IsDisableDiscountRate2 { get; set; }
        public decimal TotalUpdatedTurnover2_other { get; set; }
        public bool IsVisibleTotalUpdatedTurnover2_other { get; set; }
        public bool IsDisableTotalUpdatedTurnover2_other { get; set; }
        #endregion

        #region Income3
        public int DiscountRate3 { get; set; }
        public bool IsVisibleDiscountRate3 { get; set; }
        public bool IsDisableDiscountRate3 { get; set; }
        public decimal TotalUpdatedTurnover3_other { get; set; }
        public bool IsVisibleTotalUpdatedTurnover3_other { get; set; }
        public bool IsDisableTotalUpdatedTurnover3_other { get; set; }
        #endregion

        #region Income4
        public int DiscountRate4 { get; set; }
        public bool IsVisibleDiscountRate4 { get; set; }
        public bool IsDisableDiscountRate4 { get; set; }
        public decimal TotalUpdatedTurnover4_other { get; set; }
        public bool IsVisibleTotalUpdatedTurnover4_other { get; set; }
        public bool IsDisableTotalUpdatedTurnover4_other { get; set; }
        #endregion



        #endregion

        #region Total
        public float TotalIncome_Main { get; set; }
        public bool IsVisibleTotalIncome_Main { get; set; }
        public bool IsDisableTotalIncome_Main { get; set; }
        #endregion

        #endregion

        #region Co1

        #region SalariedClient
        #region Income1
        public string CompanyCode_Co1 { get; set; }
        public bool IsVisibleCompanyCode_Co1 { get; set; }
        public bool IsDisableCompanyCode_Co1 { get; set; }

        public string CompanyName_Co1 { get; set; }
        public bool IsVisibleCompanyName_Co1 { get; set; }
        public bool IsDisableCompanyName_Co1 { get; set; }

        public string CompanyAddress_Co1 { get; set; }
        public bool IsVisibleCompanyAddress_Co1 { get; set; }
        public bool IsDisableCompanyAddress_Co1 { get; set; }

        public string Ward_Company_Co1 { get; set; }
        public bool IsVisibleWard_Company_Co1 { get; set; }
        public bool IsDisableWard_Company_Co1 { get; set; }

        public string District_Company_Co1 { get; set; }
        public bool IsVisibleDistrict_Company_Co1 { get; set; }
        public bool IsDisableDistrict_Company_Co1 { get; set; }

        public string City_Company_Co1 { get; set; }
        public bool IsVisibleCity_Company_Co1 { get; set; }
        public bool IsDisableCity_Company_Co1 { get; set; }
        public int CityID_Company_Co1 { get; set; }

        public string OfceTel_Co1 { get; set; }
        public bool IsVisibleOfceTel_Co1 { get; set; }
        public bool IsDisableOfceTel_Co1 { get; set; }

        public string CompanyNatureOfBusiness_Co1 { get; set; }
        public bool IsVisibleCompanyNatureOfBusiness_Co1 { get; set; }
        public bool IsDisableCompanyNatureOfBusiness_Co1 { get; set; }
        public int CompanyNatureOfBusinessID_Co1 { get; set; }

        public string CompanyIndustry_Co1 { get; set; }
        public bool IsVisibleCompanyIndustry_Co1 { get; set; }
        public bool IsDisableCompanyIndustry_Co1 { get; set; }
        public int CompanyIndustryID_Co1 { get; set; }

        public string Occupation_Co1 { get; set; }
        public bool IsVisibleOccupation_Co1 { get; set; }
        public bool IsDisableOccupation_Co1 { get; set; }
        public int OccupationID_Co1 { get; set; }

        public string CurrentPosition_Co1 { get; set; }
        public bool IsVisibleCurrentPosition_Co1 { get; set; }
        public bool IsDisableCurrentPosition_Co1 { get; set; }
        public int CurrentPositionID_Co1 { get; set; }

        public string EmploymentType_Co1 { get; set; }
        public bool IsVisibleEmploymentType_Co1 { get; set; }
        public bool IsDisableEmploymentType_Co1 { get; set; }
        public int EmploymentTypeID_Co1 { get; set; }

        public string WorkingAddress_Co1 { get; set; }
        public bool IsVisibleWorkingAddress_Co1 { get; set; }
        public bool IsDisableWorkingAddress_Co1 { get; set; }

        public string Ward_Working_Co1 { get; set; }
        public bool IsVisibleWard_Working_Co1 { get; set; }
        public bool IsDisableWard_Working_Co1 { get; set; }

        public string District_Working_Co1 { get; set; }
        public bool IsVisibleDistrict_Working_Co1 { get; set; }
        public bool IsDisableDistrict_Working_Co1 { get; set; }
        public int DistrictID_Working_Co1 { get; set; }

        public string City_Working_Co1 { get; set; }
        public bool IsVisibleCity_Working_Co1 { get; set; }
        public bool IsDisableCity_Working_Co1 { get; set; }

        public string PercentSharesInCompany_Co1 { get; set; }
        public bool IsVisiblePercentSharesInCompany_Co1 { get; set; }
        public bool IsDisablePercentSharesInCompany_Co1 { get; set; }

        public string TypeOfLabourContract_Co1 { get; set; }
        public bool IsVisibleTypeOfLabourContract_Co1 { get; set; }
        public bool IsDisableTypeOfLabourContract_Co1 { get; set; }
        public int TypeOfLabourContractID_Co1 { get; set; }

        public string ContractLength_Co1 { get; set; }
        public bool IsVisibleContractLength_Co1 { get; set; }
        public bool IsDisableContractLength_Co1 { get; set; }
        public int ContractLengthID_Co1 { get; set; }

        public Nullable<System.DateTime> StartDateAtCurrentCompany_Co1 { get; set; }
        public bool IsVisibleStartDateAtCurrentCompany_Co1 { get; set; }
        public bool IsDisableStartDateAtCurrentCompany_Co1 { get; set; }

        public int TotalMonthsInCurrentCompany_Co1 { get; set; }
        public bool IsVisibleTotalMonthsInCurrentCompany_Co1 { get; set; }
        public bool IsDisableTotalMonthsInCurrentCompany_Co1 { get; set; }

        public int TotalMonthsInWorkingExperience_Co1 { get; set; }
        public bool IsVisibleTotalMonthsInWorkingExperience_Co1 { get; set; }
        public bool IsDisableTotalMonthsInWorkingExperience_Co1 { get; set; }

        public string Incometype_Co1 { get; set; }
        public bool IsVisibleIncometype_Co1 { get; set; }
        public bool IsDisableIncometype_Co1 { get; set; }
        public int IncometypeID_Co1 { get; set; }

        public float MonthlyIncome_Co1 { get; set; }
        public bool IsVisibleMonthlyIncome_Co1 { get; set; }
        public bool IsDisableMonthlyIncome_Co1 { get; set; }

        public string PeriodOfSubmittedBS_Co1 { get; set; }
        public bool IsVisiblePeriodOfSubmittedBS_Co1 { get; set; }
        public bool IsDisablePeriodOfSubmittedBS_Co1 { get; set; }
        public int PeriodOfSubmittedBSID_Co1 { get; set; }

        public bool FreelanceIncome_Co1 { get; set; }
        public bool IsVisibleFreelanceIncome_Co1 { get; set; }
        public bool IsDisableFreelanceIncome_Co1 { get; set; }

        public float GrossBaseSalary_Co1 { get; set; }
        public bool IsVisibleGrossBaseSalary_Co1 { get; set; }
        public bool IsDisableGrossBaseSalary_Co1 { get; set; }

        public float BasicAllowance_Co1 { get; set; }
        public bool IsVisibleBasicAllowance_Co1 { get; set; }
        public bool IsDisableBasicAllowance_Co1 { get; set; }

        public float EligibleFixedIncomeOnLC_Co1 { get; set; }
        public bool IsVisibleEligibleFixedIncomeOnLC_Co1 { get; set; }
        public bool IsDisableEligibleFixedIncomeOnLC_Co1 { get; set; }

        public float FixedIncomeViaBS_Co1 { get; set; }
        public bool IsVisibleFixedIncomeViaBS_Co1 { get; set; }
        public bool IsDisableFixedIncomeViaBS_Co1 { get; set; }

        public float TotalMonthlyIncomeViaBS_Co1 { get; set; }
        public bool IsVisibleTotalMonthlyIncomeViaBS_Co1 { get; set; }
        public bool IsDisableTotalMonthlyIncomeViaBS_Co1 { get; set; }

        public float PerformanceBonus_Co1 { get; set; }
        public bool IsVisiblePerformanceBonus_Co1 { get; set; }
        public bool IsDisablePerformanceBonus_Co1 { get; set; }

        public float FinalIncome_Co1 { get; set; }
        public bool IsVisibleFinalIncome_Co1 { get; set; }
        public bool IsDisableFinalIncome_Co1 { get; set; }
        #endregion
        #region Income2       
        #endregion
        public float TotalSalariedIncome_Co1 { get; set; }
        public bool IsVisibleTotalSalariedIncome_Co1 { get; set; }
        public bool IsDisableTotalSalariedIncome_Co1 { get; set; }
        #endregion

        #region Rental

        #region House Rental

        #region Income1
        //public int CustomerIncomeID_Main_Income_1 { get; set; }
        //public int ALCustomerIncomeID_Main_Income_1 { get; set; }
        //public int ALCustomerSalariedIncomeID_Main_Income_1 { get; set; }
        public string DetailsOfPropertyForRent1_Co1 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent1_Co1 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent1_Co1 { get; set; }
        public string RentalPropertyAddress1_Co1 { get; set; }
        public bool IsVisibleRentalPropertyAddress1_Co1 { get; set; }
        public bool IsDisableRentalPropertyAddress1_Co1 { get; set; }
        public string RentalPropertyOwnershipName1_Co1 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName1_Co1 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName1_Co1 { get; set; }
        public string LesseeNameAddressContact1_Co1 { get; set; }
        public bool IsVisibleLesseeNameAddressContact1_Co1 { get; set; }
        public bool IsDisableLesseeNameAddressContact1_Co1 { get; set; }
        public string Ward1_Co1 { get; set; }
        public bool IsVisibleWard1_Co1 { get; set; }
        public bool IsDisableWard1_Co1 { get; set; }
        public string District1_Co1 { get; set; }
        public bool IsVisibleDistrict1_Co1 { get; set; }
        public bool IsDisableDistrict1_Co1 { get; set; }
        public int District1ID_Co1 { get; set; }
        public string City1_Co1 { get; set; }
        public bool IsVisibleCity1_Co1 { get; set; }
        public bool IsDisableCity1_Co1 { get; set; }
        public int City1ID_Co1 { get; set; }
        public string RentalContaclTenure1_Co1 { get; set; }
        public bool IsVisibleRentalContaclTenure1_Co1 { get; set; }
        public bool IsDisableRentalContaclTenure1_Co1 { get; set; }
        public string MonthlyRentalFee1_Co1 { get; set; }
        public bool IsVisibleMonthlyRentalFee1_Co1 { get; set; }
        public bool IsDisableMonthlyRentalFee1_Co1 { get; set; }
        public string RentalPurpose1_Co1 { get; set; }
        public bool IsVisibleRentalPurpose1_Co1 { get; set; }
        public bool IsDisableRentalPurpose1_Co1 { get; set; }
        public string RepaymentCycle1_Co1 { get; set; }
        public bool IsVisibleRepaymentCycle1_Co1 { get; set; }
        public bool IsDisableRepaymentCycle1_Co1 { get; set; }
        public int RepaymentCycle1ID_Co1 { get; set; }
        public string IncomePaymentMethod1_Co1 { get; set; }
        public bool IsVisibleIncomePaymentMethod1_Co1 { get; set; }
        public bool IsDisableIncomePaymentMethod1_Co1 { get; set; }
        public int IncomePaymentMethod1ID_Co1 { get; set; }
        public decimal TotalRentalIncome1_Co1 { get; set; }
        public bool IsVisibleTotalRentalIncome1_Co1 { get; set; }
        public bool IsDisableTotalRentalIncome1_Co1 { get; set; }

        #endregion

        #region Income2
        public string DetailsOfPropertyForRent2_Co1 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent2_Co1 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent2_Co1 { get; set; }
        public string RentalPropertyAddress2_Co1 { get; set; }
        public bool IsVisibleRentalPropertyAddress2_Co1 { get; set; }
        public bool IsDisableRentalPropertyAddress2_Co1 { get; set; }
        public string RentalPropertyOwnershipName2_Co1 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName2_Co1 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName2_Co1 { get; set; }
        public string LesseeNameAddressContact2_Co1 { get; set; }
        public bool IsVisibleLesseeNameAddressContact2_Co1 { get; set; }
        public bool IsDisableLesseeNameAddressContact2_Co1 { get; set; }
        public string Ward2_Co1 { get; set; }
        public bool IsVisibleWard2_Co1 { get; set; }
        public bool IsDisableWard2_Co1 { get; set; }
        public string District2_Co1 { get; set; }
        public bool IsVisibleDistrict2_Co1 { get; set; }
        public bool IsDisableDistrict2_Co1 { get; set; }
        public int District2ID_Co1 { get; set; }
        public string City2_Co1 { get; set; }
        public bool IsVisibleCity2_Co1 { get; set; }
        public bool IsDisableCity2_Co1 { get; set; }
        public int City2ID_Co1 { get; set; }
        public string RentalContaclTenure2_Co1 { get; set; }
        public bool IsVisibleRentalContaclTenure2_Co1 { get; set; }
        public bool IsDisableRentalContaclTenure2_Co1 { get; set; }
        public string MonthlyRentalFee2_Co1 { get; set; }
        public bool IsVisibleMonthlyRentalFee2_Co1 { get; set; }
        public bool IsDisableMonthlyRentalFee2_Co1 { get; set; }
        public string RentalPurpose2_Co1 { get; set; }
        public bool IsVisibleRentalPurpose2_Co1 { get; set; }
        public bool IsDisableRentalPurpose2_Co1 { get; set; }
        public string RepaymentCycle2_Co1 { get; set; }
        public bool IsVisibleRepaymentCycle2_Co1 { get; set; }
        public bool IsDisableRepaymentCycle2_Co1 { get; set; }
        public int RepaymentCycle2ID_Co1 { get; set; }
        public string IncomePaymentMethod2_Co1 { get; set; }
        public bool IsVisibleIncomePaymentMethod2_Co1 { get; set; }
        public bool IsDisableIncomePaymentMethod2_Co1 { get; set; }
        public int IncomePaymentMethod2ID_Co1 { get; set; }
        public decimal TotalRentalIncome2_Co1 { get; set; }
        public bool IsVisibleTotalRentalIncome2_Co1 { get; set; }
        public bool IsDisableTotalRentalIncome2_Co1 { get; set; }
        #endregion

        #region Income3
        public string DetailsOfPropertyForRent3_Co1 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent3_Co1 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent3_Co1 { get; set; }
        public string RentalPropertyAddress3_Co1 { get; set; }
        public bool IsVisibleRentalPropertyAddress3_Co1 { get; set; }
        public bool IsDisableRentalPropertyAddress3_Co1 { get; set; }
        public string RentalPropertyOwnershipName3_Co1 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName3_Co1 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName3_Co1 { get; set; }
        public string LesseeNameAddressContact3_Co1 { get; set; }
        public bool IsVisibleLesseeNameAddressContact3_Co1 { get; set; }
        public bool IsDisableLesseeNameAddressContact3_Co1 { get; set; }
        public string Ward3_Co1 { get; set; }
        public bool IsVisibleWard3_Co1 { get; set; }
        public bool IsDisableWard3_Co1 { get; set; }
        public string District3_Co1 { get; set; }
        public bool IsVisibleDistrict3_Co1 { get; set; }
        public bool IsDisableDistrict3_Co1 { get; set; }
        public int District3ID_Co1 { get; set; }
        public string City3_Co1 { get; set; }
        public bool IsVisibleCity3_Co1 { get; set; }
        public bool IsDisableCity3_Co1 { get; set; }
        public int City3ID_Co1 { get; set; }
        public string RentalContaclTenure3_Co1 { get; set; }
        public bool IsVisibleRentalContaclTenure3_Co1 { get; set; }
        public bool IsDisableRentalContaclTenure3_Co1 { get; set; }
        public string MonthlyRentalFee3_Co1 { get; set; }
        public bool IsVisibleMonthlyRentalFee3_Co1 { get; set; }
        public bool IsDisableMonthlyRentalFee3_Co1 { get; set; }
        public string RentalPurpose3_Co1 { get; set; }
        public bool IsVisibleRentalPurpose3_Co1 { get; set; }
        public bool IsDisableRentalPurpose3_Co1 { get; set; }
        public string RepaymentCycle3_Co1 { get; set; }
        public bool IsVisibleRepaymentCycle3_Co1 { get; set; }
        public bool IsDisableRepaymentCycle3_Co1 { get; set; }
        public int RepaymentCycle3ID_Co1 { get; set; }
        public string IncomePaymentMethod3_Co1 { get; set; }
        public bool IsVisibleIncomePaymentMethod3_Co1 { get; set; }
        public bool IsDisableIncomePaymentMethod3_Co1 { get; set; }
        public int IncomePaymentMethod3ID_Co1 { get; set; }
        public decimal TotalRentalIncome3_Co1 { get; set; }
        public bool IsVisibleTotalRentalIncome3_Co1 { get; set; }
        public bool IsDisableTotalRentalIncome3_Co1 { get; set; }
        #endregion

        #region Income4
        public string DetailsOfPropertyForRent4_Co1 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent4_Co1 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent4_Co1 { get; set; }
        public string RentalPropertyAddress4_Co1 { get; set; }
        public bool IsVisibleRentalPropertyAddress4_Co1 { get; set; }
        public bool IsDisableRentalPropertyAddress4_Co1 { get; set; }
        public string RentalPropertyOwnershipName4_Co1 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName4_Co1 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName4_Co1 { get; set; }
        public string LesseeNameAddressContact4_Co1 { get; set; }
        public bool IsVisibleLesseeNameAddressContact4_Co1 { get; set; }
        public bool IsDisableLesseeNameAddressContact4_Co1 { get; set; }
        public string Ward4_Co1 { get; set; }
        public bool IsVisibleWard4_Co1 { get; set; }
        public bool IsDisableWard4_Co1 { get; set; }
        public string District4_Co1 { get; set; }
        public bool IsVisibleDistrict4_Co1 { get; set; }
        public bool IsDisableDistrict4_Co1 { get; set; }
        public int District4ID_Co1 { get; set; }
        public string City4_Co1 { get; set; }
        public bool IsVisibleCity4_Co1 { get; set; }
        public bool IsDisableCity4_Co1 { get; set; }
        public int City4ID_Co1 { get; set; }
        public string RentalContaclTenure4_Co1 { get; set; }
        public bool IsVisibleRentalContaclTenure4_Co1 { get; set; }
        public bool IsDisableRentalContaclTenure4_Co1 { get; set; }
        public string MonthlyRentalFee4_Co1 { get; set; }
        public bool IsVisibleMonthlyRentalFee4_Co1 { get; set; }
        public bool IsDisableMonthlyRentalFee4_Co1 { get; set; }
        public string RentalPurpose4_Co1 { get; set; }
        public bool IsVisibleRentalPurpose4_Co1 { get; set; }
        public bool IsDisableRentalPurpose4_Co1 { get; set; }
        public string RepaymentCycle4_Co1 { get; set; }
        public bool IsVisibleRepaymentCycle4_Co1 { get; set; }
        public bool IsDisableRepaymentCycle4_Co1 { get; set; }
        public int RepaymentCycle4ID_Co1 { get; set; }
        public string IncomePaymentMethod4_Co1 { get; set; }
        public bool IsVisibleIncomePaymentMethod4_Co1 { get; set; }
        public bool IsDisableIncomePaymentMethod4_Co1 { get; set; }
        public int IncomePaymentMethod4ID_Co1 { get; set; }
        public decimal TotalRentalIncome4_Co1 { get; set; }
        public bool IsVisibleTotalRentalIncome4_Co1 { get; set; }
        public bool IsDisableTotalRentalIncome4_Co1 { get; set; }
        #endregion

        #region Income5
        public string DetailsOfPropertyForRent5_Co1 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent5_Co1 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent5_Co1 { get; set; }
        public string RentalPropertyAddress5_Co1 { get; set; }
        public bool IsVisibleRentalPropertyAddress5_Co1 { get; set; }
        public bool IsDisableRentalPropertyAddress5_Co1 { get; set; }
        public string RentalPropertyOwnershipName5_Co1 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName5_Co1 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName5_Co1 { get; set; }
        public string LesseeNameAddressContact5_Co1 { get; set; }
        public bool IsVisibleLesseeNameAddressContact5_Co1 { get; set; }
        public bool IsDisableLesseeNameAddressContact5_Co1 { get; set; }
        public string Ward5_Co1 { get; set; }
        public bool IsVisibleWard5_Co1 { get; set; }
        public bool IsDisableWard5_Co1 { get; set; }
        public string District5_Co1 { get; set; }
        public bool IsVisibleDistrict5_Co1 { get; set; }
        public bool IsDisableDistrict5_Co1 { get; set; }
        public int District5ID_Co1 { get; set; }
        public string City5_Co1 { get; set; }
        public bool IsVisibleCity5_Co1 { get; set; }
        public bool IsDisableCity5_Co1 { get; set; }
        public int City5ID_Co1 { get; set; }
        public string RentalContaclTenure5_Co1 { get; set; }
        public bool IsVisibleRentalContaclTenure5_Co1 { get; set; }
        public bool IsDisableRentalContaclTenure5_Co1 { get; set; }
        public string MonthlyRentalFee5_Co1 { get; set; }
        public bool IsVisibleMonthlyRentalFee5_Co1 { get; set; }
        public bool IsDisableMonthlyRentalFee5_Co1 { get; set; }
        public string RentalPurpose5_Co1 { get; set; }
        public bool IsVisibleRentalPurpose5_Co1 { get; set; }
        public bool IsDisableRentalPurpose5_Co1 { get; set; }
        public string RepaymentCycle5_Co1 { get; set; }
        public bool IsVisibleRepaymentCycle5_Co1 { get; set; }
        public bool IsDisableRepaymentCycle5_Co1 { get; set; }
        public int RepaymentCycle5ID_Co1 { get; set; }
        public string IncomePaymentMethod5_Co1 { get; set; }
        public bool IsVisibleIncomePaymentMethod5_Co1 { get; set; }
        public bool IsDisableIncomePaymentMethod5_Co1 { get; set; }
        public int IncomePaymentMethod5ID_Co1 { get; set; }
        public decimal TotalRentalIncome5_Co1 { get; set; }
        public bool IsVisibleTotalRentalIncome5_Co1 { get; set; }
        public bool IsDisableTotalRentalIncome5_Co1 { get; set; }
        #endregion

        #region Income6
        public string DetailsOfPropertyForRent6_Co1 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent6_Co1 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent6_Co1 { get; set; }
        public string RentalPropertyAddress6_Co1 { get; set; }
        public bool IsVisibleRentalPropertyAddress6_Co1 { get; set; }
        public bool IsDisableRentalPropertyAddress6_Co1 { get; set; }
        public string RentalPropertyOwnershipName6_Co1 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName6_Co1 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName6_Co1 { get; set; }
        public string LesseeNameAddressContact6_Co1 { get; set; }
        public bool IsVisibleLesseeNameAddressContact6_Co1 { get; set; }
        public bool IsDisableLesseeNameAddressContact6_Co1 { get; set; }
        public string Ward6_Co1 { get; set; }
        public bool IsVisibleWard6_Co1 { get; set; }
        public bool IsDisableWard6_Co1 { get; set; }
        public string District6_Co1 { get; set; }
        public bool IsVisibleDistrict6_Co1 { get; set; }
        public bool IsDisableDistrict6_Co1 { get; set; }
        public int District6ID_Co1 { get; set; }
        public string City6_Co1 { get; set; }
        public bool IsVisibleCity6_Co1 { get; set; }
        public bool IsDisableCity6_Co1 { get; set; }
        public int City6ID_Co1 { get; set; }
        public string RentalContaclTenure6_Co1 { get; set; }
        public bool IsVisibleRentalContaclTenure6_Co1 { get; set; }
        public bool IsDisableRentalContaclTenure6_Co1 { get; set; }
        public string MonthlyRentalFee6_Co1 { get; set; }
        public bool IsVisibleMonthlyRentalFee6_Co1 { get; set; }
        public bool IsDisableMonthlyRentalFee6_Co1 { get; set; }
        public string RentalPurpose6_Co1 { get; set; }
        public bool IsVisibleRentalPurpose6_Co1 { get; set; }
        public bool IsDisableRentalPurpose6_Co1 { get; set; }
        public string RepaymentCycle6_Co1 { get; set; }
        public bool IsVisibleRepaymentCycle6_Co1 { get; set; }
        public bool IsDisableRepaymentCycle6_Co1 { get; set; }
        public int RepaymentCycle6ID_Co1 { get; set; }
        public string IncomePaymentMethod6_Co1 { get; set; }
        public bool IsVisibleIncomePaymentMethod6_Co1 { get; set; }
        public bool IsDisableIncomePaymentMethod6_Co1 { get; set; }
        public int IncomePaymentMethod6ID_Co1 { get; set; }
        public decimal TotalRentalIncome6_Co1 { get; set; }
        public bool IsVisibleTotalRentalIncome6_Co1 { get; set; }
        public bool IsDisableTotalRentalIncome6_Co1 { get; set; }
        #endregion
        #endregion

        #region Car Rental

        #region Income1
        public string DetailsOfCarforRent1_Co1 { get; set; }
        public bool IsVisibleDetailsOfCarforRent1_Co1 { get; set; }
        public bool IsDisableDetailsOfCarforRent1_Co1 { get; set; }
        public string TypeOfCar1_Co1 { get; set; }
        public bool IsVisibleTypeOfCar1_Co1 { get; set; }
        public bool IsDisableTypeOfCar1_Co1 { get; set; }
        public string CarPlateNumber1_Co1 { get; set; }
        public bool IsVisibleCarPlateNumber1_Co1 { get; set; }
        public bool IsDisableCarPlateNumber1_Co1 { get; set; }
        public string CarOwnershipName1_Co1 { get; set; }
        public bool IsVisibleCarOwnershipName1_Co1 { get; set; }
        public bool IsDisableCarOwnershipName1_Co1 { get; set; }
        public string CarLesseeNameAddressContact1_Co1 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact1_Co1 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact1_Co1 { get; set; }
        public string RentalContractTenure1_Co1 { get; set; }
        public bool IsVisibleRentalContractTenure1_Co1 { get; set; }
        public bool IsDisableRentalContractTenure1_Co1 { get; set; }
        public string CarMonthlyRentalFee1_Co1 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee1_Co1 { get; set; }
        public bool IsCarDisableMonthlyRentalFee1_Co1 { get; set; }
        public string CarRepaymentCycle1_Co1 { get; set; }
        public bool IsCarVisibleRepaymentCycle1_Co1 { get; set; }
        public bool IsCarDisableRepaymentCycle1_Co1 { get; set; }
        public int CarRepaymentCycle1ID_Co1 { get; set; }
        public string CarIncomePaymentMethod1_Co1 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod1_Co1 { get; set; }
        public bool IsCarDisableIncomePaymentMethod1_Co1 { get; set; }
        public int CarIncomePaymentMethod1ID_Co1 { get; set; }
        public decimal TotalCarRentalIncome1_Co1 { get; set; }
        public bool IsVisibleTotalCarRentalIncome1_Co1 { get; set; }
        public bool IsDisableTotalCarRentalIncome1_Co1 { get; set; }
        #endregion

        #region Income2
        public string DetailsOfCarforRent2_Co1 { get; set; }
        public bool IsVisibleDetailsOfCarforRent2_Co1 { get; set; }
        public bool IsDisableDetailsOfCarforRent2_Co1 { get; set; }
        public string TypeOfCar2_Co1 { get; set; }
        public bool IsVisibleTypeOfCar2_Co1 { get; set; }
        public bool IsDisableTypeOfCar2_Co1 { get; set; }
        public string CarPlateNumber2_Co1 { get; set; }
        public bool IsVisibleCarPlateNumber2_Co1 { get; set; }
        public bool IsDisableCarPlateNumber2_Co1 { get; set; }
        public string CarOwnershipName2_Co1 { get; set; }
        public bool IsVisibleCarOwnershipName2_Co1 { get; set; }
        public bool IsDisableCarOwnershipName2_Co1 { get; set; }
        public string CarLesseeNameAddressContact2_Co1 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact2_Co1 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact2_Co1 { get; set; }
        public string RentalContractTenure2_Co1 { get; set; }
        public bool IsVisibleRentalContractTenure2_Co1 { get; set; }
        public bool IsDisableRentalContractTenure2_Co1 { get; set; }
        public string CarMonthlyRentalFee2_Co1 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee2_Co1 { get; set; }
        public bool IsCarDisableMonthlyRentalFee2_Co1 { get; set; }
        public string CarRepaymentCycle2_Co1 { get; set; }
        public bool IsCarVisibleRepaymentCycle2_Co1 { get; set; }
        public bool IsCarDisableRepaymentCycle2_Co1 { get; set; }
        public int CarRepaymentCycle2ID_Co1 { get; set; }
        public string CarIncomePaymentMethod2_Co1 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod2_Co1 { get; set; }
        public bool IsCarDisableIncomePaymentMethod2_Co1 { get; set; }
        public int CarIncomePaymentMethod2ID_Co1 { get; set; }
        public decimal TotalCarRentalIncome2_Co1 { get; set; }
        public bool IsVisibleTotalCarRentalIncome2_Co1 { get; set; }
        public bool IsDisableTotalCarRentalIncome2_Co1 { get; set; }
        #endregion

        #region Income3
        public string DetailsOfCarforRent3_Co1 { get; set; }
        public bool IsVisibleDetailsOfCarforRent3_Co1 { get; set; }
        public bool IsDisableDetailsOfCarforRent3_Co1 { get; set; }
        public string TypeOfCar3_Co1 { get; set; }
        public bool IsVisibleTypeOfCar3_Co1 { get; set; }
        public bool IsDisableTypeOfCar3_Co1 { get; set; }
        public string CarPlateNumber3_Co1 { get; set; }
        public bool IsVisibleCarPlateNumber3_Co1 { get; set; }
        public bool IsDisableCarPlateNumber3_Co1 { get; set; }
        public string CarOwnershipName3_Co1 { get; set; }
        public bool IsVisibleCarOwnershipName3_Co1 { get; set; }
        public bool IsDisableCarOwnershipName3_Co1 { get; set; }
        public string CarLesseeNameAddressContact3_Co1 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact3_Co1 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact3_Co1 { get; set; }
        public string RentalContractTenure3_Co1 { get; set; }
        public bool IsVisibleRentalContractTenure3_Co1 { get; set; }
        public bool IsDisableRentalContractTenure3_Co1 { get; set; }
        public string CarMonthlyRentalFee3_Co1 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee3_Co1 { get; set; }
        public bool IsCarDisableMonthlyRentalFee3_Co1 { get; set; }
        public string CarRepaymentCycle3_Co1 { get; set; }
        public bool IsCarVisibleRepaymentCycle3_Co1 { get; set; }
        public bool IsCarDisableRepaymentCycle3_Co1 { get; set; }
        public int CarRepaymentCycle3ID_Co1 { get; set; }
        public string CarIncomePaymentMethod3_Co1 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod3_Co1 { get; set; }
        public bool IsCarDisableIncomePaymentMethod3_Co1 { get; set; }
        public int CarIncomePaymentMethod3ID_Co1 { get; set; }
        public decimal TotalCarRentalIncome3_Co1 { get; set; }
        public bool IsVisibleTotalCarRentalIncome3_Co1 { get; set; }
        public bool IsDisableTotalCarRentalIncome3_Co1 { get; set; }
        #endregion

        #region Income4
        public string DetailsOfCarforRent4_Co1 { get; set; }
        public bool IsVisibleDetailsOfCarforRent4_Co1 { get; set; }
        public bool IsDisableDetailsOfCarforRent4_Co1 { get; set; }
        public string TypeOfCar4_Co1 { get; set; }
        public bool IsVisibleTypeOfCar4_Co1 { get; set; }
        public bool IsDisableTypeOfCar4_Co1 { get; set; }
        public string CarPlateNumber4_Co1 { get; set; }
        public bool IsVisibleCarPlateNumber4_Co1 { get; set; }
        public bool IsDisableCarPlateNumber4_Co1 { get; set; }
        public string CarOwnershipName4_Co1 { get; set; }
        public bool IsVisibleCarOwnershipName4_Co1 { get; set; }
        public bool IsDisableCarOwnershipName4_Co1 { get; set; }
        public string CarLesseeNameAddressContact4_Co1 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact4_Co1 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact4_Co1 { get; set; }
        public string RentalContractTenure4_Co1 { get; set; }
        public bool IsVisibleRentalContractTenure4_Co1 { get; set; }
        public bool IsDisableRentalContractTenure4_Co1 { get; set; }
        public string CarMonthlyRentalFee4_Co1 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee4_Co1 { get; set; }
        public bool IsCarDisableMonthlyRentalFee4_Co1 { get; set; }
        public string CarRepaymentCycle4_Co1 { get; set; }
        public bool IsCarVisibleRepaymentCycle4_Co1 { get; set; }
        public bool IsCarDisableRepaymentCycle4_Co1 { get; set; }
        public int CarRepaymentCycle4ID_Co1 { get; set; }
        public string CarIncomePaymentMethod4_Co1 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod4_Co1 { get; set; }
        public bool IsCarDisableIncomePaymentMethod4_Co1 { get; set; }
        public int CarIncomePaymentMethod4ID_Co1 { get; set; }
        public decimal TotalCarRentalIncome4_Co1 { get; set; }
        public bool IsVisibleTotalCarRentalIncome4_Co1 { get; set; }
        public bool IsDisableTotalCarRentalIncome4_Co1 { get; set; }
        #endregion

        #endregion

        #endregion

        #region SelfEmployed

        #region Income1
        public string CompanyName1_Co1 { get; set; }
        public bool IsVisibleCompanyName1_Co1 { get; set; }
        public bool IsDisableCompanyName1_Co1 { get; set; }
        public string BusinessLicenceNumber1_Co1 { get; set; }
        public bool IsVisibleBusinessLicenceNumber1_Co1 { get; set; }
        public bool IsDisableBusinessLicenceNumber1_Co1 { get; set; }
        public string TaxCode1_Co1 { get; set; }
        public bool IsVisibleTaxCode1_Co1 { get; set; }
        public bool IsDisableTaxCode1_Co1 { get; set; }
        public string CompanyAddress1_Co1 { get; set; }
        public bool IsVisibleCompanyAddress1_Co1 { get; set; }
        public bool IsDisableCompanyAddress1_Co1 { get; set; }
        public string SelfWard1_Co1 { get; set; }
        public bool IsVisibleSelfWard1_Co1 { get; set; }
        public bool IsDisableSelfWard1_Co1 { get; set; }
        public string DisTrict1_Co1 { get; set; }
        public bool IsVisibleDisTrict1_Co1 { get; set; }
        public bool IsDisableDisTrict1_Co1 { get; set; }
        public int DisTrict1ID_Co1 { get; set; }
        public string SelfCity1_Co1 { get; set; }
        public bool IsVisibleSelfCity1_Co1 { get; set; }
        public bool IsDisableSelfCity1_Co1 { get; set; }
        public string SelfCity1ID_Co1 { get; set; }
        public string Ofcetel1_Co1 { get; set; }
        public bool IsVisibleOfcetel1_Co1 { get; set; }
        public bool IsDisableOfcetel1_Co1 { get; set; }
        public string MainCompanyIndustry11_Co1 { get; set; }
        public bool IsVisibleMainCompanyIndustry11_Co1 { get; set; }
        public bool IsDisableMainCompanyIndustry11_Co1 { get; set; }
        public int MainCompanyIndustry11ID_Co1 { get; set; }
        public string MainCompanyIndustry21_Co1 { get; set; }
        public bool IsVisibleMainCompanyIndustry21_Co1 { get; set; }
        public bool IsDisableMainCompanyIndustry21_Co1 { get; set; }
        public int MainCompanyIndustry21ID_Co1 { get; set; }
        public string OtherCompanyIndustryBizNature1_Co1 { get; set; }
        public bool IsVisibleOtherCompanyIndustryBizNature1_Co1 { get; set; }
        public bool IsDisableOtherCompanyIndustryBizNature1_Co1 { get; set; }
        public string SeasonalIndustry1_Co1 { get; set; }
        public bool IsVisibleSeasonalIndustry1_Co1 { get; set; }
        public bool IsDisableSeasonalIndustry1_Co1 { get; set; }
        public Nullable<DateTime> EstablishedYear1_Co1 { get; set; }
        public bool IsVisibleEstablishedYear1_Co1 { get; set; }
        public bool IsDisableEstablishedYear1_Co1 { get; set; }
        public int TotalYearsInOperation1_Co1 { get; set; }
        public bool IsVisibleTotalYearsInOperation1_Co1 { get; set; }
        public bool IsDisableTotalYearsInOperation1_Co1 { get; set; }
        public int ShareholdingInCompany1_Co1 { get; set; }
        public bool IsVisibleShareholdingInCompany1_Co1 { get; set; }
        public bool IsDisableShareholdingInCompany1_Co1 { get; set; }
        public string ProfLossinLatestYear1_Co1 { get; set; }
        public bool IsVisibleProfLossinLatestYear1_Co1 { get; set; }
        public bool IsDisableProfLossinLatestYear1_Co1 { get; set; }
        public int ProfLossinLatestYear1ID_Co1 { get; set; }
        public string TypeOfSelfEmploymentIncome1_Co1 { get; set; }
        public bool IsVisibleTypeOfSelfEmploymentIncome1_Co1 { get; set; }
        public bool IsDisableTypeOfSelfEmploymentIncome1_Co1 { get; set; }
        public int TypeOfSelfEmploymentIncome1ID_Co1 { get; set; }
        public int TotalTurnoverinFS1_Co1 { get; set; }
        public bool IsVisibleTotalTurnoverinFS1_Co1 { get; set; }
        public bool IsDisableTotalTurnoverinFS1_Co1 { get; set; }
        public decimal MonthlyTurnoverinyear1_Co1 { get; set; }
        public bool IsVisibleMonthlyTurnoverinyear1_Co1 { get; set; }
        public bool IsDisableMonthlyTurnoverinyear1_Co1 { get; set; }
        /// <summary>
        /// /////
        /// </summary>
        /// 
        public decimal TotalUpdatedTurnover1_Co1 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover1_Co1 { get; set; }
        public bool IsDisableTotalUpdatedTurnover1_Co1 { get; set; }
        public decimal AverageMonthlyUpdatedTurnover1_Co1 { get; set; }
        public bool IsVisibleAverageMonthlyUpdatedTurnover1_Co1 { get; set; }
        public bool IsDisableAverageMonthlyUpdatedTurnover1_Co1 { get; set; }
        public decimal ComparedWithTurnOver1_Co1 { get; set; }
        public bool IsVisibleComparedWithTurnOver1_Co1 { get; set; }
        public bool IsDisableComparedWithTurnOver1_Co1 { get; set; }
        public decimal RevisedAverageMonthlyTurnover1_Co1 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnover1_Co1 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnover1_Co1 { get; set; }
        public int SplitupIndustry11_Co1 { get; set; }
        public bool IsVisibleSplitupIndustry11_Co1 { get; set; }
        public bool IsDisableSplitupIndustry11_Co1 { get; set; }
        public int SplitupIndustry21_Co1 { get; set; }
        public bool IsVisibleSplitupIndustry21_Co1 { get; set; }
        public bool IsDisableSplitupIndustry21_Co1 { get; set; }
        public int SplitupIndustry31_Co1 { get; set; }
        public bool IsVisibleSplitupIndustry31_Co1 { get; set; }
        public bool IsDisableSplitupIndustry31_Co1 { get; set; }
        public int IndustrialMargin11_Co1 { get; set; }
        public bool IsVisibleIndustrialMargin11_Co1 { get; set; }
        public bool IsDisableIndustrialMargin11_Co1 { get; set; }
        public int IndustrialMargin21_Co1 { get; set; }
        public bool IsVisibleIndustrialMargin21_Co1 { get; set; }
        public bool IsDisableIndustrialMargin21_Co1 { get; set; }
        public int IndustrialMargin31_Co1 { get; set; }
        public bool IsVisibleIndustrialMargin31_Co1 { get; set; }
        public bool IsDisableIndustrialMargin31_Co1 { get; set; }
        public string Remark1_Co1 { get; set; }
        public bool IsVisibleRemark1_Co1 { get; set; }
        public bool IsDisableRemark1_Co1 { get; set; }
        public decimal MonthlySeflEmployedIncome1_Co1 { get; set; }
        public bool IsVisibleMonthlySeflEmployedIncome1_Co1 { get; set; }
        public bool IsDisableMonthlySeflEmployedIncome1_Co1 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncome1_Co1 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncome1_Co1 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncome1_Co1 { get; set; }
        public int TotalTurnoverinFSBank1_Co1 { get; set; }
        public bool IsVisibleTotalTurnoverinFSBank1_Co1 { get; set; }
        public bool IsDisableTotalTurnoverinFSBank1_Co1 { get; set; }
        public decimal MonthlyTurnoverInyearBank1_Co1 { get; set; }
        public bool IsVisibleMonthlyTurnoverInyearBank1_Co1 { get; set; }
        public bool IsDisableMonthlyTurnoverInyearBank1_Co1 { get; set; }
        public int OtherMonthlyTurnover1_Co1 { get; set; }
        public bool IsVisibleOtherMonthlyTurnover1_Co1 { get; set; }
        public bool IsDisableOtherMonthlyTurnover1_Co1 { get; set; }
        public decimal AverageEligibleCreditBalance1_Co1 { get; set; }
        public bool IsVisibleAverageEligibleCreditBalance1_Co1 { get; set; }
        public bool IsDisableAverageEligibleCreditBalance1_Co1 { get; set; }
        public decimal TotalEligibleMonthlyIncome1_Co1 { get; set; }
        public bool IsVisibleTotalEligibleMonthlyIncome1_Co1 { get; set; }
        public bool IsDisableTotalEligibleMonthlyIncome1_Co1 { get; set; }
        public decimal RevisedAverageMonthlyTurnoverBank1_Co1 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnoverBank1_Co1 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnoverBank1_Co1 { get; set; }
        public int SplitupIndustry1Bank1_Co1 { get; set; }
        public bool IsVisibleSplitupIndustry1Bank1_Co1 { get; set; }
        public bool IsDisableSplitupIndustry1Bank1_Co1 { get; set; }
        public int SplitupIndustry2Bank1_Co1 { get; set; }
        public bool IsVisibleSplitupIndustry2Bank1_Co1 { get; set; }
        public bool IsDisableSplitupIndustry2Bank1_Co1 { get; set; }
        public int SplitupIndustry3Bank1_Co1 { get; set; }
        public bool IsVisibleSplitupIndustry3Bank1_Co1 { get; set; }
        public bool IsDisableSplitupIndustry3Bank1_Co1 { get; set; }
        public int IndustrialMargin1Bank1_Co1 { get; set; }
        public bool IsVisibleIndustrialMargin1Bank1_Co1 { get; set; }
        public bool IsDisableIndustrialMargin1Bank1_Co1 { get; set; }
        public int IndustrialMargin2Bank1_Co1 { get; set; }
        public bool IsVisibleIndustrialMargin2Bank1_Co1 { get; set; }
        public bool IsDisableIndustrialMargin2Bank1_Co1 { get; set; }
        public int IndustrialMargin3Bank1_Co1 { get; set; }
        public bool IsVisibleIndustrialMargin3Bank1_Co1 { get; set; }
        public bool IsDisableIndustrialMargin3Bank1_Co1 { get; set; }
        public string RemarkBank1_Co1 { get; set; }
        public bool IsVisibleRemarkBank1_Co1 { get; set; }
        public bool IsDisableRemarkBank1_Co1 { get; set; }
        public decimal MonthlySelfEmployedIncome1_Co1 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncome1_Co1 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncome1_Co1 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeBank1_Co1 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeBank1_Co1 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeBank1_Co1 { get; set; }
        public int TotalTurnoverInFS1_Co1 { get; set; }
        public bool IsVisibleTotalTurnoverInFS1_Co1 { get; set; }
        public bool IsDisableTotalTurnoverInFS1_Co1 { get; set; }
        public int ProftafertaxinLatestYear1_Co1 { get; set; }
        public bool IsVisibleProftafertaxinLatestYear1_Co1 { get; set; }
        public bool IsDisableProftafertaxinLatestYear1_Co1 { get; set; }
        public int Depreciation1_Co1 { get; set; }
        public bool IsVisibleDepreciation1_Co1 { get; set; }
        public bool IsDisableDepreciation1_Co1 { get; set; }
        public decimal MonthlyTurnoverInYear1_Co1 { get; set; }
        public bool IsVisibleMonthlyTurnoverInYear1_Co1 { get; set; }
        public bool IsDisableMonthlyTurnoverInYear1_Co1 { get; set; }
        public decimal MonthlySelfEmployedIncomeCPP1_Co1 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncomeCPP1_Co1 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncomeCPP1_Co1 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeCPP1_Co1 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeCPP1_Co1 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeCPP1_Co1 { get; set; }

        #endregion

        #region Income2
        public string CompanyName2_Co1 { get; set; }
        public bool IsVisibleCompanyName2_Co1 { get; set; }
        public bool IsDisableCompanyName2_Co1 { get; set; }
        public string BusinessLicenceNumber2_Co1 { get; set; }
        public bool IsVisibleBusinessLicenceNumber2_Co1 { get; set; }
        public bool IsDisableBusinessLicenceNumber2_Co1 { get; set; }
        public string TaxCode2_Co1 { get; set; }
        public bool IsVisibleTaxCode2_Co1 { get; set; }
        public bool IsDisableTaxCode2_Co1 { get; set; }
        public string CompanyAddress2_Co1 { get; set; }
        public bool IsVisibleCompanyAddress2_Co1 { get; set; }
        public bool IsDisableCompanyAddress2_Co1 { get; set; }
        public string SelfWard2_Co1 { get; set; }
        public bool IsVisibleSelfWard2_Co1 { get; set; }
        public bool IsDisableSelfWard2_Co1 { get; set; }
        public string DisTrict2_Co1 { get; set; }
        public bool IsVisibleDisTrict2_Co1 { get; set; }
        public bool IsDisableDisTrict2_Co1 { get; set; }
        public int DisTrict2ID_Co1 { get; set; }
        public string SelfCity2_Co1 { get; set; }
        public bool IsVisibleSelfCity2_Co1 { get; set; }
        public bool IsDisableSelfCity2_Co1 { get; set; }
        public string SelfCity2ID_Co1 { get; set; }
        public string Ofcetel2_Co1 { get; set; }
        public bool IsVisibleOfcetel2_Co1 { get; set; }
        public bool IsDisableOfcetel2_Co1 { get; set; }
        public string MainCompanyIndustry12_Co1 { get; set; }
        public bool IsVisibleMainCompanyIndustry12_Co1 { get; set; }
        public bool IsDisableMainCompanyIndustry12_Co1 { get; set; }
        public int MainCompanyIndustry12ID_Co1 { get; set; }
        public string MainCompanyIndustry22_Co1 { get; set; }
        public bool IsVisibleMainCompanyIndustry22_Co1 { get; set; }
        public bool IsDisableMainCompanyIndustry22_Co1 { get; set; }
        public int MainCompanyIndustry22ID_Co1 { get; set; }
        public string OtherCompanyIndustryBizNature2_Co1 { get; set; }
        public bool IsVisibleOtherCompanyIndustryBizNature2_Co1 { get; set; }
        public bool IsDisableOtherCompanyIndustryBizNature2_Co1 { get; set; }
        public string SeasonalIndustry2_Co1 { get; set; }
        public bool IsVisibleSeasonalIndustry2_Co1 { get; set; }
        public bool IsDisableSeasonalIndustry2_Co1 { get; set; }
        public Nullable<DateTime> EstablishedYear2_Co1 { get; set; }
        public bool IsVisibleEstablishedYear2_Co1 { get; set; }
        public bool IsDisableEstablishedYear2_Co1 { get; set; }
        public int TotalYearsInOperation2_Co1 { get; set; }
        public bool IsVisibleTotalYearsInOperation2_Co1 { get; set; }
        public bool IsDisableTotalYearsInOperation2_Co1 { get; set; }
        public int ShareholdingInCompany2_Co1 { get; set; }
        public bool IsVisibleShareholdingInCompany2_Co1 { get; set; }
        public bool IsDisableShareholdingInCompany2_Co1 { get; set; }
        public string ProfLossinLatestYear2_Co1 { get; set; }
        public bool IsVisibleProfLossinLatestYear2_Co1 { get; set; }
        public bool IsDisableProfLossinLatestYear2_Co1 { get; set; }
        public int ProfLossinLatestYear2ID_Co1 { get; set; }
        public string TypeOfSelfEmploymentIncome2_Co1 { get; set; }
        public bool IsVisibleTypeOfSelfEmploymentIncome2_Co1 { get; set; }
        public bool IsDisableTypeOfSelfEmploymentIncome2_Co1 { get; set; }
        public int TypeOfSelfEmploymentIncome2ID_Co1 { get; set; }
        public int TotalTurnoverinFS2_Co1 { get; set; }
        public bool IsVisibleTotalTurnoverinFS2_Co1 { get; set; }
        public bool IsDisableTotalTurnoverinFS2_Co1 { get; set; }
        public decimal MonthlyTurnoverinyear2_Co1 { get; set; }
        public bool IsVisibleMonthlyTurnoverinyear2_Co1 { get; set; }
        public bool IsDisableMonthlyTurnoverinyear2_Co1 { get; set; }
        /// <summary>
        /// ////
        /// </summary>
        /// 
        public decimal TotalUpdatedTurnover2_Co1 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover2_Co1 { get; set; }
        public bool IsDisableTotalUpdatedTurnover2_Co1 { get; set; }
        public decimal AverageMonthlyUpdatedTurnover2_Co1 { get; set; }
        public bool IsVisibleAverageMonthlyUpdatedTurnover2_Co1 { get; set; }
        public bool IsDisableAverageMonthlyUpdatedTurnover2_Co1 { get; set; }
        public decimal ComparedWithTurnOverBank2_Co1 { get; set; }
        public bool IsVisibleComparedWithTurnOverbank2_Co1 { get; set; }
        public bool IsDisableComparedWithTurnOverBank2_Co1 { get; set; }
        public decimal RevisedAverageMonthlyTurnover2_Co1 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnover2_Co1 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnover2_Co1 { get; set; }
        public int SplitupIndustry12_Co1 { get; set; }
        public bool IsVisibleSplitupIndustry12_Co1 { get; set; }
        public bool IsDisableSplitupIndustry12_Co1 { get; set; }
        public int SplitupIndustry22_Co1 { get; set; }
        public bool IsVisibleSplitupIndustry22_Co1 { get; set; }
        public bool IsDisableSplitupIndustry22_Co1 { get; set; }
        public int SplitupIndustry32_Co1 { get; set; }
        public bool IsVisibleSplitupIndustry32_Co1 { get; set; }
        public bool IsDisableSplitupIndustry32_Co1 { get; set; }
        public int IndustrialMargin12_Co1 { get; set; }
        public bool IsVisibleIndustrialMargin12_Co1 { get; set; }
        public bool IsDisableIndustrialMargin12_Co1 { get; set; }
        public int IndustrialMargin22_Co1 { get; set; }
        public bool IsVisibleIndustrialMargin22_Co1 { get; set; }
        public bool IsDisableIndustrialMargin22_Co1 { get; set; }
        public int IndustrialMargin32_Co1 { get; set; }
        public bool IsVisibleIndustrialMargin32_Co1 { get; set; }
        public bool IsDisableIndustrialMargin32_Co1 { get; set; }
        public string Remark2_Co1 { get; set; }
        public bool IsVisibleRemark2_Co1 { get; set; }
        public bool IsDisableRemark2_Co1 { get; set; }
        public decimal MonthlySeflEmployedIncome2_Co1 { get; set; }
        public bool IsVisibleMonthlySeflEmployedIncome2_Co1 { get; set; }
        public bool IsDisableMonthlySeflEmployedIncome2_Co1 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncome2_Co1 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncome2_Co1 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncome2_Co1 { get; set; }
        public int TotalTurnoverinFSBank2_Co1 { get; set; }
        public bool IsVisibleTotalTurnoverinFSBank2_Co1 { get; set; }
        public bool IsDisableTotalTurnoverinFSBank2_Co1 { get; set; }
        public decimal MonthlyTurnoverInyearBank2_Co1 { get; set; }
        public bool IsVisibleMonthlyTurnoverInyearBank2_Co1 { get; set; }
        public bool IsDisableMonthlyTurnoverInyearBank2_Co1 { get; set; }
        public int OtherMonthlyTurnover2_Co1 { get; set; }
        public bool IsVisibleOtherMonthlyTurnover2_Co1 { get; set; }
        public bool IsDisableOtherMonthlyTurnover2_Co1 { get; set; }
        public decimal AverageEligibleCreditBalance2_Co1 { get; set; }
        public bool IsVisibleAverageEligibleCreditBalance2_Co1 { get; set; }
        public bool IsDisableAverageEligibleCreditBalance2_Co1 { get; set; }
        public decimal TotalEligibleMonthlyIncome2_Co1 { get; set; }
        public bool IsVisibleTotalEligibleMonthlyIncome2_Co1 { get; set; }
        public bool IsDisableTotalEligibleMonthlyIncome2_Co1 { get; set; }
        public decimal RevisedAverageMonthlyTurnoverBank2_Co1 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnoverBank2_Co1 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnoverBank2_Co1 { get; set; }
        public int SplitupIndustry1Bank2_Co1 { get; set; }
        public bool IsVisibleSplitupIndustry1Bank2_Co1 { get; set; }
        public bool IsDisableSplitupIndustry1Bank2_Co1 { get; set; }
        public int SplitupIndustry2Bank2_Co1 { get; set; }
        public bool IsVisibleSplitupIndustry2Bank2_Co1 { get; set; }
        public bool IsDisableSplitupIndustry2Bank2_Co1 { get; set; }
        public int SplitupIndustry3Bank2_Co1 { get; set; }
        public bool IsVisibleSplitupIndustry3Bank2_Co1 { get; set; }
        public bool IsDisableSplitupIndustry3Bank2_Co1 { get; set; }
        public int IndustrialMargin1Bank2_Co1 { get; set; }
        public bool IsVisibleIndustrialMargin1Bank2_Co1 { get; set; }
        public bool IsDisableIndustrialMargin1Bank2_Co1 { get; set; }
        public int IndustrialMargin2Bank2_Co1 { get; set; }
        public bool IsVisibleIndustrialMargin2Bank2_Co1 { get; set; }
        public bool IsDisableIndustrialMargin2Bank2_Co1 { get; set; }
        public int IndustrialMargin3Bank2_Co1 { get; set; }
        public bool IsVisibleIndustrialMargin3Bank2_Co1 { get; set; }
        public bool IsDisableIndustrialMargin3Bank2_Co1 { get; set; }
        public string RemarkBank2_Co1 { get; set; }
        public bool IsVisibleRemarkBank2_Co1 { get; set; }
        public bool IsDisableRemarkBank2_Co1 { get; set; }
        public decimal MonthlySelfEmployedIncome2_Co1 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncome2_Co1 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncome2_Co1 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeBank2_Co1 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeBank2_Co1 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeBank2_Co1 { get; set; }
        public int TotalTurnoverInFS2_Co1 { get; set; }
        public bool IsVisibleTotalTurnoverInFS2_Co1 { get; set; }
        public bool IsDisableTotalTurnoverInFS2_Co1 { get; set; }
        public int ProftafertaxinLatestYear2_Co1 { get; set; }
        public bool IsVisibleProftafertaxinLatestYear2_Co1 { get; set; }
        public bool IsDisableProftafertaxinLatestYear2_Co1 { get; set; }
        public int Depreciation2_Co1 { get; set; }
        public bool IsVisibleDepreciation2_Co1 { get; set; }
        public bool IsDisableDepreciation2_Co1 { get; set; }
        public decimal MonthlyTurnoverInYear2_Co1 { get; set; }
        public bool IsVisibleMonthlyTurnoverInYear2_Co1 { get; set; }
        public bool IsDisableMonthlyTurnoverInYear2_Co1 { get; set; }
        public decimal MonthlySelfEmployedIncomeCPP2_Co1 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncomeCPP2_Co1 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncomeCPP2_Co1 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeCPP2_Co1 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeCPP2_Co1 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeCPP2_Co1 { get; set; }
        #endregion

        #endregion

        #region Other

        #region Income1
        public int DiscountRate1_Co1 { get; set; }
        public bool IsVisibleDiscountRate1_Co1 { get; set; }
        public bool IsDisableDiscountRate1_Co1 { get; set; }
        public decimal TotalUpdatedTurnover1_other_Co1 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover1_other_Co1 { get; set; }
        public bool IsDisableTotalUpdatedTurnover1_other_Co1 { get; set; }

        #endregion

        #region Income2
        public int DiscountRate2_Co1 { get; set; }
        public bool IsVisibleDiscountRate2_Co1 { get; set; }
        public bool IsDisableDiscountRate2_Co1 { get; set; }
        public decimal TotalUpdatedTurnover2_other_Co1 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover2_other_Co1 { get; set; }
        public bool IsDisableTotalUpdatedTurnover2_other_Co1 { get; set; }
        #endregion

        #region Income3
        public int DiscountRate3_Co1 { get; set; }
        public bool IsVisibleDiscountRate3_Co1 { get; set; }
        public bool IsDisableDiscountRate3_Co1 { get; set; }
        public decimal TotalUpdatedTurnover3_other_Co1 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover3_other_Co1 { get; set; }
        public bool IsDisableTotalUpdatedTurnover3_other_Co1 { get; set; }
        #endregion

        #region Income4
        public int DiscountRate4_Co1 { get; set; }
        public bool IsVisibleDiscountRate4_Co1 { get; set; }
        public bool IsDisableDiscountRate4_Co1 { get; set; }
        public decimal TotalUpdatedTurnover4_other_Co1 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover4_other_Co1 { get; set; }
        public bool IsDisableTotalUpdatedTurnover4_other_Co1 { get; set; }
        #endregion



        #endregion

        public float TotalIncome_Co1 { get; set; }
        public bool IsVisibleTotalIncome_Co1 { get; set; }
        public bool IsDisableTotalIncome_Co1 { get; set; }
        #endregion

        #region Co2


        #region SalariedClient
        #region Income1
        public string CompanyCode_Co2 { get; set; }
        public bool IsVisibleCompanyCode_Co2 { get; set; }
        public bool IsDisableCompanyCode_Co2 { get; set; }

        public string CompanyName_Co2 { get; set; }
        public bool IsVisibleCompanyName_Co2 { get; set; }
        public bool IsDisableCompanyName_Co2 { get; set; }

        public string CompanyAddress_Co2 { get; set; }
        public bool IsVisibleCompanyAddress_Co2 { get; set; }
        public bool IsDisableCompanyAddress_Co2 { get; set; }

        public string Ward_Company_Co2 { get; set; }
        public bool IsVisibleWard_Company_Co2 { get; set; }
        public bool IsDisableWard_Company_Co2 { get; set; }

        public string District_Company_Co2 { get; set; }
        public bool IsVisibleDistrict_Company_Co2 { get; set; }
        public bool IsDisableDistrict_Company_Co2 { get; set; }

        public string City_Company_Co2 { get; set; }
        public bool IsVisibleCity_Company_Co2 { get; set; }
        public bool IsDisableCity_Company_Co2 { get; set; }

        public int CityID_Company_Co2 { get; set; }
        public bool IsVisibleCityID_Company_Co2 { get; set; }
        public bool IsDisableCityID_Company_Co2 { get; set; }

        public string OfceTel_Co2 { get; set; }
        public bool IsVisibleOfceTel_Co2 { get; set; }
        public bool IsDisableOfceTel_Co2 { get; set; }

        public string CompanyNatureOfBusiness_Co2 { get; set; }
        public bool IsVisibleCompanyNatureOfBusiness_Co2 { get; set; }
        public bool IsDisableCompanyNatureOfBusiness_Co2 { get; set; }
        public int CompanyNatureOfBusinessID_Co2 { get; set; }

        public string CompanyIndustry_Co2 { get; set; }
        public bool IsVisibleCompanyIndustry_Co2 { get; set; }
        public bool IsDisableCompanyIndustry_Co2 { get; set; }
        public int CompanyIndustryID_Co2 { get; set; }

        public string Occupation_Co2 { get; set; }
        public bool IsVisibleOccupation_Co2 { get; set; }
        public bool IsDisableOccupation_Co2 { get; set; }
        public int OccupationID_Co2 { get; set; }

        public string CurrentPosition_Co2 { get; set; }
        public bool IsVisibleCurrentPosition_Co2 { get; set; }
        public bool IsDisableCurrentPosition_Co2 { get; set; }
        public int CurrentPositionID_Co2 { get; set; }

        public string EmploymentType_Co2 { get; set; }
        public bool IsVisibleEmploymentType_Co2 { get; set; }
        public bool IsDisableEmploymentType_Co2 { get; set; }
        public int EmploymentTypeID_Co2 { get; set; }

        public string WorkingAddress_Co2 { get; set; }
        public bool IsVisibleWorkingAddress_Co2 { get; set; }
        public bool IsDisableWorkingAddress_Co2 { get; set; }

        public string Ward_Working_Co2 { get; set; }
        public bool IsVisibleWard_Working_Co2 { get; set; }
        public bool IsDisableWard_Working_Co2 { get; set; }

        public string District_Working_Co2 { get; set; }
        public bool IsVisibleDistrict_Working_Co2 { get; set; }
        public bool IsDisableDistrict_Working_Co2 { get; set; }
        public int DistrictID_Working_Co2 { get; set; }

        public string City_Working_Co2 { get; set; }
        public bool IsVisibleCity_Working_Co2 { get; set; }
        public bool IsDisableCity_Working_Co2 { get; set; }

        public string PercentSharesInCompany_Co2 { get; set; }
        public bool IsVisiblePercentSharesInCompany_Co2 { get; set; }
        public bool IsDisablePercentSharesInCompany_Co2 { get; set; }

        public string TypeOfLabourContract_Co2 { get; set; }
        public bool IsVisibleTypeOfLabourContract_Co2 { get; set; }
        public bool IsDisableTypeOfLabourContract_Co2 { get; set; }
        public int TypeOfLabourContractID_Co2 { get; set; }

        public string ContractLength_Co2 { get; set; }
        public bool IsVisibleContractLength_Co2 { get; set; }
        public bool IsDisableContractLength_Co2 { get; set; }
        public int ContractLengthID_Co2 { get; set; }

        public Nullable<System.DateTime> StartDateAtCurrentCompany_Co2 { get; set; }
        public bool IsVisibleStartDateAtCurrentCompany_Co2 { get; set; }
        public bool IsDisableStartDateAtCurrentCompany_Co2 { get; set; }

        public int TotalMonthsInCurrentCompany_Co2 { get; set; }
        public bool IsVisibleTotalMonthsInCurrentCompany_Co2 { get; set; }
        public bool IsDisableTotalMonthsInCurrentCompany_Co2 { get; set; }

        public int TotalMonthsInWorkingExperience_Co2 { get; set; }
        public bool IsVisibleTotalMonthsInWorkingExperience_Co2 { get; set; }
        public bool IsDisableTotalMonthsInWorkingExperience_Co2 { get; set; }

        public string Incometype_Co2 { get; set; }
        public bool IsVisibleIncometype_Co2 { get; set; }
        public bool IsDisableIncometype_Co2 { get; set; }
        public int IncometypeID_Co2 { get; set; }

        public float MonthlyIncome_Co2 { get; set; }
        public bool IsVisibleMonthlyIncome_Co2 { get; set; }
        public bool IsDisableMonthlyIncome_Co2 { get; set; }

        public string PeriodOfSubmittedBS_Co2 { get; set; }
        public bool IsVisiblePeriodOfSubmittedBS_Co2 { get; set; }
        public bool IsDisablePeriodOfSubmittedBS_Co2 { get; set; }
        public int PeriodOfSubmittedBSID_Co2 { get; set; }

        public bool FreelanceIncome_Co2 { get; set; }
        public bool IsVisibleFreelanceIncome_Co2 { get; set; }
        public bool IsDisableFreelanceIncome_Co2 { get; set; }

        public float GrossBaseSalary_Co2 { get; set; }
        public bool IsVisibleGrossBaseSalary_Co2 { get; set; }
        public bool IsDisableGrossBaseSalary_Co2 { get; set; }

        public float BasicAllowance_Co2 { get; set; }
        public bool IsVisibleBasicAllowance_Co2 { get; set; }
        public bool IsDisableBasicAllowance_Co2 { get; set; }

        public float EligibleFixedIncomeOnLC_Co2 { get; set; }
        public bool IsVisibleEligibleFixedIncomeOnLC_Co2 { get; set; }
        public bool IsDisableEligibleFixedIncomeOnLC_Co2 { get; set; }

        public float FixedIncomeViaBS_Co2 { get; set; }
        public bool IsVisibleFixedIncomeViaBS_Co2 { get; set; }
        public bool IsDisableFixedIncomeViaBS_Co2 { get; set; }

        public float TotalMonthlyIncomeViaBS_Co2 { get; set; }
        public bool IsVisibleTotalMonthlyIncomeViaBS_Co2 { get; set; }
        public bool IsDisableTotalMonthlyIncomeViaBS_Co2 { get; set; }

        public float PerformanceBonus_Co2 { get; set; }
        public bool IsVisiblePerformanceBonus_Co2 { get; set; }
        public bool IsDisablePerformanceBonus_Co2 { get; set; }

        public float FinalIncome_Co2 { get; set; }
        public bool IsVisibleFinalIncome_Co2 { get; set; }
        public bool IsDisableFinalIncome_Co2 { get; set; }
        #endregion
        #region Income2       
        #endregion
        public float TotalSalariedIncome_Co2 { get; set; }
        public bool IsVisibleTotalSalariedIncome_Co2 { get; set; }
        public bool IsDisableTotalSalariedIncome_Co2 { get; set; }
        #endregion

        #region Rental

        #region House Rental

        #region Income1
        //public int CustomerIncomeID_Main_Income_1 { get; set; }
        //public int ALCustomerIncomeID_Main_Income_1 { get; set; }
        //public int ALCustomerSalariedIncomeID_Main_Income_1 { get; set; }
        public string DetailsOfPropertyForRent1_Co2 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent1_Co2 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent1_Co2 { get; set; }
        public string RentalPropertyAddress1_Co2 { get; set; }
        public bool IsVisibleRentalPropertyAddress1_Co2 { get; set; }
        public bool IsDisableRentalPropertyAddress1_Co2 { get; set; }
        public string RentalPropertyOwnershipName1_Co2 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName1_Co2 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName1_Co2 { get; set; }
        public string LesseeNameAddressContact1_Co2 { get; set; }
        public bool IsVisibleLesseeNameAddressContact1_Co2 { get; set; }
        public bool IsDisableLesseeNameAddressContact1_Co2 { get; set; }
        public string Ward1_Co2 { get; set; }
        public bool IsVisibleWard1_Co2 { get; set; }
        public bool IsDisableWard1_Co2 { get; set; }
        public string District1_Co2 { get; set; }
        public bool IsVisibleDistrict1_Co2 { get; set; }
        public bool IsDisableDistrict1_Co2 { get; set; }
        public int District1ID_Co2 { get; set; }
        public string City1_Co2 { get; set; }
        public bool IsVisibleCity1_Co2 { get; set; }
        public bool IsDisableCity1_Co2 { get; set; }
        public int City1ID_Co2 { get; set; }
        public string RentalContaclTenure1_Co2 { get; set; }
        public bool IsVisibleRentalContaclTenure1_Co2 { get; set; }
        public bool IsDisableRentalContaclTenure1_Co2 { get; set; }
        public string MonthlyRentalFee1_Co2 { get; set; }
        public bool IsVisibleMonthlyRentalFee1_Co2 { get; set; }
        public bool IsDisableMonthlyRentalFee1_Co2 { get; set; }
        public string RentalPurpose1_Co2 { get; set; }
        public bool IsVisibleRentalPurpose1_Co2 { get; set; }
        public bool IsDisableRentalPurpose1_Co2 { get; set; }
        public string RepaymentCycle1_Co2 { get; set; }
        public bool IsVisibleRepaymentCycle1_Co2 { get; set; }
        public bool IsDisableRepaymentCycle1_Co2 { get; set; }
        public int RepaymentCycle1ID_Co2 { get; set; }
        public string IncomePaymentMethod1_Co2 { get; set; }
        public bool IsVisibleIncomePaymentMethod1_Co2 { get; set; }
        public bool IsDisableIncomePaymentMethod1_Co2 { get; set; }
        public int IncomePaymentMethod1ID_Co2 { get; set; }
        public decimal TotalRentalIncome1_Co2 { get; set; }
        public bool IsVisibleTotalRentalIncome1_Co2 { get; set; }
        public bool IsDisableTotalRentalIncome1_Co2 { get; set; }

        #endregion

        #region Income2
        public string DetailsOfPropertyForRent2_Co2 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent2_Co2 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent2_Co2 { get; set; }
        public string RentalPropertyAddress2_Co2 { get; set; }
        public bool IsVisibleRentalPropertyAddress2_Co2 { get; set; }
        public bool IsDisableRentalPropertyAddress2_Co2 { get; set; }
        public string RentalPropertyOwnershipName2_Co2 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName2_Co2 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName2_Co2 { get; set; }
        public string LesseeNameAddressContact2_Co2 { get; set; }
        public bool IsVisibleLesseeNameAddressContact2_Co2 { get; set; }
        public bool IsDisableLesseeNameAddressContact2_Co2 { get; set; }
        public string Ward2_Co2 { get; set; }
        public bool IsVisibleWard2_Co2 { get; set; }
        public bool IsDisableWard2_Co2 { get; set; }
        public string District2_Co2 { get; set; }
        public bool IsVisibleDistrict2_Co2 { get; set; }
        public bool IsDisableDistrict2_Co2 { get; set; }
        public int District2ID_Co2 { get; set; }
        public string City2_Co2 { get; set; }
        public bool IsVisibleCity2_Co2 { get; set; }
        public bool IsDisableCity2_Co2 { get; set; }
        public int City2ID_Co2 { get; set; }
        public string RentalContaclTenure2_Co2 { get; set; }
        public bool IsVisibleRentalContaclTenure2_Co2 { get; set; }
        public bool IsDisableRentalContaclTenure2_Co2 { get; set; }
        public string MonthlyRentalFee2_Co2 { get; set; }
        public bool IsVisibleMonthlyRentalFee2_Co2 { get; set; }
        public bool IsDisableMonthlyRentalFee2_Co2 { get; set; }
        public string RentalPurpose2_Co2 { get; set; }
        public bool IsVisibleRentalPurpose2_Co2 { get; set; }
        public bool IsDisableRentalPurpose2_Co2 { get; set; }
        public string RepaymentCycle2_Co2 { get; set; }
        public bool IsVisibleRepaymentCycle2_Co2 { get; set; }
        public bool IsDisableRepaymentCycle2_Co2 { get; set; }
        public int RepaymentCycle2ID_Co2 { get; set; }
        public string IncomePaymentMethod2_Co2 { get; set; }
        public bool IsVisibleIncomePaymentMethod2_Co2 { get; set; }
        public bool IsDisableIncomePaymentMethod2_Co2 { get; set; }
        public int IncomePaymentMethod2ID_Co2 { get; set; }
        public decimal TotalRentalIncome2_Co2 { get; set; }
        public bool IsVisibleTotalRentalIncome2_Co2 { get; set; }
        public bool IsDisableTotalRentalIncome2_Co2 { get; set; }
        #endregion

        #region Income3
        public string DetailsOfPropertyForRent3_Co2 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent3_Co2 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent3_Co2 { get; set; }
        public string RentalPropertyAddress3_Co2 { get; set; }
        public bool IsVisibleRentalPropertyAddress3_Co2 { get; set; }
        public bool IsDisableRentalPropertyAddress3_Co2 { get; set; }
        public string RentalPropertyOwnershipName3_Co2 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName3_Co2 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName3_Co2 { get; set; }
        public string LesseeNameAddressContact3_Co2 { get; set; }
        public bool IsVisibleLesseeNameAddressContact3_Co2 { get; set; }
        public bool IsDisableLesseeNameAddressContact3_Co2 { get; set; }
        public string Ward3_Co2 { get; set; }
        public bool IsVisibleWard3_Co2 { get; set; }
        public bool IsDisableWard3_Co2 { get; set; }
        public string District3_Co2 { get; set; }
        public bool IsVisibleDistrict3_Co2 { get; set; }
        public bool IsDisableDistrict3_Co2 { get; set; }
        public int District3ID_Co2 { get; set; }
        public string City3_Co2 { get; set; }
        public bool IsVisibleCity3_Co2 { get; set; }
        public bool IsDisableCity3_Co2 { get; set; }
        public int City3ID_Co2 { get; set; }
        public string RentalContaclTenure3_Co2 { get; set; }
        public bool IsVisibleRentalContaclTenure3_Co2 { get; set; }
        public bool IsDisableRentalContaclTenure3_Co2 { get; set; }
        public string MonthlyRentalFee3_Co2 { get; set; }
        public bool IsVisibleMonthlyRentalFee3_Co2 { get; set; }
        public bool IsDisableMonthlyRentalFee3_Co2 { get; set; }
        public string RentalPurpose3_Co2 { get; set; }
        public bool IsVisibleRentalPurpose3_Co2 { get; set; }
        public bool IsDisableRentalPurpose3_Co2 { get; set; }
        public string RepaymentCycle3_Co2 { get; set; }
        public bool IsVisibleRepaymentCycle3_Co2 { get; set; }
        public bool IsDisableRepaymentCycle3_Co2 { get; set; }
        public int RepaymentCycle3ID_Co2 { get; set; }
        public string IncomePaymentMethod3_Co2 { get; set; }
        public bool IsVisibleIncomePaymentMethod3_Co2 { get; set; }
        public bool IsDisableIncomePaymentMethod3_Co2 { get; set; }
        public int IncomePaymentMethod3ID_Co2 { get; set; }
        public decimal TotalRentalIncome3_Co2 { get; set; }
        public bool IsVisibleTotalRentalIncome3_Co2 { get; set; }
        public bool IsDisableTotalRentalIncome3_Co2 { get; set; }
        #endregion

        #region Income4
        public string DetailsOfPropertyForRent4_Co2 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent4_Co2 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent4_Co2 { get; set; }
        public string RentalPropertyAddress4_Co2 { get; set; }
        public bool IsVisibleRentalPropertyAddress4_Co2 { get; set; }
        public bool IsDisableRentalPropertyAddress4_Co2 { get; set; }
        public string RentalPropertyOwnershipName4_Co2 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName4_Co2 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName4_Co2 { get; set; }
        public string LesseeNameAddressContact4_Co2 { get; set; }
        public bool IsVisibleLesseeNameAddressContact4_Co2 { get; set; }
        public bool IsDisableLesseeNameAddressContact4_Co2 { get; set; }
        public string Ward4_Co2 { get; set; }
        public bool IsVisibleWard4_Co2 { get; set; }
        public bool IsDisableWard4_Co2 { get; set; }
        public string District4_Co2 { get; set; }
        public bool IsVisibleDistrict4_Co2 { get; set; }
        public bool IsDisableDistrict4_Co2 { get; set; }
        public int District4ID_Co2 { get; set; }
        public string City4_Co2 { get; set; }
        public bool IsVisibleCity4_Co2 { get; set; }
        public bool IsDisableCity4_Co2 { get; set; }
        public int City4ID_Co2 { get; set; }
        public string RentalContaclTenure4_Co2 { get; set; }
        public bool IsVisibleRentalContaclTenure4_Co2 { get; set; }
        public bool IsDisableRentalContaclTenure4_Co2 { get; set; }
        public string MonthlyRentalFee4_Co2 { get; set; }
        public bool IsVisibleMonthlyRentalFee4_Co2 { get; set; }
        public bool IsDisableMonthlyRentalFee4_Co2 { get; set; }
        public string RentalPurpose4_Co2 { get; set; }
        public bool IsVisibleRentalPurpose4_Co2 { get; set; }
        public bool IsDisableRentalPurpose4_Co2 { get; set; }
        public string RepaymentCycle4_Co2 { get; set; }
        public bool IsVisibleRepaymentCycle4_Co2 { get; set; }
        public bool IsDisableRepaymentCycle4_Co2 { get; set; }
        public int RepaymentCycle4ID_Co2 { get; set; }
        public string IncomePaymentMethod4_Co2 { get; set; }
        public bool IsVisibleIncomePaymentMethod4_Co2 { get; set; }
        public bool IsDisableIncomePaymentMethod4_Co2 { get; set; }
        public int IncomePaymentMethod4ID_Co2 { get; set; }
        public decimal TotalRentalIncome4_Co2 { get; set; }
        public bool IsVisibleTotalRentalIncome4_Co2 { get; set; }
        public bool IsDisableTotalRentalIncome4_Co2 { get; set; }
        #endregion

        #region Income5
        public string DetailsOfPropertyForRent5_Co2 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent5_Co2 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent5_Co2 { get; set; }
        public string RentalPropertyAddress5_Co2 { get; set; }
        public bool IsVisibleRentalPropertyAddress5_Co2 { get; set; }
        public bool IsDisableRentalPropertyAddress5_Co2 { get; set; }
        public string RentalPropertyOwnershipName5_Co2 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName5_Co2 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName5_Co2 { get; set; }
        public string LesseeNameAddressContact5_Co2 { get; set; }
        public bool IsVisibleLesseeNameAddressContact5_Co2 { get; set; }
        public bool IsDisableLesseeNameAddressContact5_Co2 { get; set; }
        public string Ward5_Co2 { get; set; }
        public bool IsVisibleWard5_Co2 { get; set; }
        public bool IsDisableWard5_Co2 { get; set; }
        public string District5_Co2 { get; set; }
        public bool IsVisibleDistrict5_Co2 { get; set; }
        public bool IsDisableDistrict5_Co2 { get; set; }
        public int District5ID_Co2 { get; set; }
        public string City5_Co2 { get; set; }
        public bool IsVisibleCity5_Co2 { get; set; }
        public bool IsDisableCity5_Co2 { get; set; }
        public int City5ID_Co2 { get; set; }
        public string RentalContaclTenure5_Co2 { get; set; }
        public bool IsVisibleRentalContaclTenure5_Co2 { get; set; }
        public bool IsDisableRentalContaclTenure5_Co2 { get; set; }
        public string MonthlyRentalFee5_Co2 { get; set; }
        public bool IsVisibleMonthlyRentalFee5_Co2 { get; set; }
        public bool IsDisableMonthlyRentalFee5_Co2 { get; set; }
        public string RentalPurpose5_Co2 { get; set; }
        public bool IsVisibleRentalPurpose5_Co2 { get; set; }
        public bool IsDisableRentalPurpose5_Co2 { get; set; }
        public string RepaymentCycle5_Co2 { get; set; }
        public bool IsVisibleRepaymentCycle5_Co2 { get; set; }
        public bool IsDisableRepaymentCycle5_Co2 { get; set; }
        public int RepaymentCycle5ID_Co2 { get; set; }
        public string IncomePaymentMethod5_Co2 { get; set; }
        public bool IsVisibleIncomePaymentMethod5_Co2 { get; set; }
        public bool IsDisableIncomePaymentMethod5_Co2 { get; set; }
        public int IncomePaymentMethod5ID_Co2 { get; set; }
        public decimal TotalRentalIncome5_Co2 { get; set; }
        public bool IsVisibleTotalRentalIncome5_Co2 { get; set; }
        public bool IsDisableTotalRentalIncome5_Co2 { get; set; }
        #endregion

        #region Income6
        public string DetailsOfPropertyForRent6_Co2 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent6_Co2 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent6_Co2 { get; set; }
        public string RentalPropertyAddress6_Co2 { get; set; }
        public bool IsVisibleRentalPropertyAddress6_Co2 { get; set; }
        public bool IsDisableRentalPropertyAddress6_Co2 { get; set; }
        public string RentalPropertyOwnershipName6_Co2 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName6_Co2 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName6_Co2 { get; set; }
        public string LesseeNameAddressContact6_Co2 { get; set; }
        public bool IsVisibleLesseeNameAddressContact6_Co2 { get; set; }
        public bool IsDisableLesseeNameAddressContact6_Co2 { get; set; }
        public string Ward6_Co2 { get; set; }
        public bool IsVisibleWard6_Co2 { get; set; }
        public bool IsDisableWard6_Co2 { get; set; }
        public string District6_Co2 { get; set; }
        public bool IsVisibleDistrict6_Co2 { get; set; }
        public bool IsDisableDistrict6_Co2 { get; set; }
        public int District6ID_Co2 { get; set; }
        public string City6_Co2 { get; set; }
        public bool IsVisibleCity6_Co2 { get; set; }
        public bool IsDisableCity6_Co2 { get; set; }
        public int City6ID_Co2 { get; set; }
        public string RentalContaclTenure6_Co2 { get; set; }
        public bool IsVisibleRentalContaclTenure6_Co2 { get; set; }
        public bool IsDisableRentalContaclTenure6_Co2 { get; set; }
        public string MonthlyRentalFee6_Co2 { get; set; }
        public bool IsVisibleMonthlyRentalFee6_Co2 { get; set; }
        public bool IsDisableMonthlyRentalFee6_Co2 { get; set; }
        public string RentalPurpose6_Co2 { get; set; }
        public bool IsVisibleRentalPurpose6_Co2 { get; set; }
        public bool IsDisableRentalPurpose6_Co2 { get; set; }
        public string RepaymentCycle6_Co2 { get; set; }
        public bool IsVisibleRepaymentCycle6_Co2 { get; set; }
        public bool IsDisableRepaymentCycle6_Co2 { get; set; }
        public int RepaymentCycle6ID_Co2 { get; set; }
        public string IncomePaymentMethod6_Co2 { get; set; }
        public bool IsVisibleIncomePaymentMethod6_Co2 { get; set; }
        public bool IsDisableIncomePaymentMethod6_Co2 { get; set; }
        public int IncomePaymentMethod6ID_Co2 { get; set; }
        public decimal TotalRentalIncome6_Co2 { get; set; }
        public bool IsVisibleTotalRentalIncome6_Co2 { get; set; }
        public bool IsDisableTotalRentalIncome6_Co2 { get; set; }
        #endregion
        #endregion

        #region Car Rental

        #region Income1
        public string DetailsOfCarforRent1_Co2 { get; set; }
        public bool IsVisibleDetailsOfCarforRent1_Co2 { get; set; }
        public bool IsDisableDetailsOfCarforRent1_Co2 { get; set; }
        public string TypeOfCar1_Co2 { get; set; }
        public bool IsVisibleTypeOfCar1_Co2 { get; set; }
        public bool IsDisableTypeOfCar1_Co2 { get; set; }
        public string CarPlateNumber1_Co2 { get; set; }
        public bool IsVisibleCarPlateNumber1_Co2 { get; set; }
        public bool IsDisableCarPlateNumber1_Co2 { get; set; }
        public string CarOwnershipName1_Co2 { get; set; }
        public bool IsVisibleCarOwnershipName1_Co2 { get; set; }
        public bool IsDisableCarOwnershipName1_Co2 { get; set; }
        public string CarLesseeNameAddressContact1_Co2 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact1_Co2 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact1_Co2 { get; set; }
        public string RentalContractTenure1_Co2 { get; set; }
        public bool IsVisibleRentalContractTenure1_Co2 { get; set; }
        public bool IsDisableRentalContractTenure1_Co2 { get; set; }
        public string CarMonthlyRentalFee1_Co2 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee1_Co2 { get; set; }
        public bool IsCarDisableMonthlyRentalFee1_Co2 { get; set; }
        public string CarRepaymentCycle1_Co2 { get; set; }
        public bool IsCarVisibleRepaymentCycle1_Co2 { get; set; }
        public bool IsCarDisableRepaymentCycle1_Co2 { get; set; }
        public int CarRepaymentCycle1ID_Co2 { get; set; }
        public string CarIncomePaymentMethod1_Co2 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod1_Co2 { get; set; }
        public bool IsCarDisableIncomePaymentMethod1_Co2 { get; set; }
        public int CarIncomePaymentMethod1ID_Co2 { get; set; }
        public decimal TotalCarRentalIncome1_Co2 { get; set; }
        public bool IsVisibleTotalCarRentalIncome1_Co2 { get; set; }
        public bool IsDisableTotalCarRentalIncome1_Co2 { get; set; }
        #endregion

        #region Income2
        public string DetailsOfCarforRent2_Co2 { get; set; }
        public bool IsVisibleDetailsOfCarforRent2_Co2 { get; set; }
        public bool IsDisableDetailsOfCarforRent2_Co2 { get; set; }
        public string TypeOfCar2_Co2 { get; set; }
        public bool IsVisibleTypeOfCar2_Co2 { get; set; }
        public bool IsDisableTypeOfCar2_Co2 { get; set; }
        public string CarPlateNumber2_Co2 { get; set; }
        public bool IsVisibleCarPlateNumber2_Co2 { get; set; }
        public bool IsDisableCarPlateNumber2_Co2 { get; set; }
        public string CarOwnershipName2_Co2 { get; set; }
        public bool IsVisibleCarOwnershipName2_Co2 { get; set; }
        public bool IsDisableCarOwnershipName2_Co2 { get; set; }
        public string CarLesseeNameAddressContact2_Co2 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact2_Co2 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact2_Co2 { get; set; }
        public string RentalContractTenure2_Co2 { get; set; }
        public bool IsVisibleRentalContractTenure2_Co2 { get; set; }
        public bool IsDisableRentalContractTenure2_Co2 { get; set; }
        public string CarMonthlyRentalFee2_Co2 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee2_Co2 { get; set; }
        public bool IsCarDisableMonthlyRentalFee2_Co2 { get; set; }
        public string CarRepaymentCycle2_Co2 { get; set; }
        public bool IsCarVisibleRepaymentCycle2_Co2 { get; set; }
        public bool IsCarDisableRepaymentCycle2_Co2 { get; set; }
        public int CarRepaymentCycle2ID_Co2 { get; set; }
        public string CarIncomePaymentMethod2_Co2 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod2_Co2 { get; set; }
        public bool IsCarDisableIncomePaymentMethod2_Co2 { get; set; }
        public int CarIncomePaymentMethod2ID_Co2 { get; set; }
        public decimal TotalCarRentalIncome2_Co2 { get; set; }
        public bool IsVisibleTotalCarRentalIncome2_Co2 { get; set; }
        public bool IsDisableTotalCarRentalIncome2_Co2 { get; set; }
        #endregion

        #region Income3
        public string DetailsOfCarforRent3_Co2 { get; set; }
        public bool IsVisibleDetailsOfCarforRent3_Co2 { get; set; }
        public bool IsDisableDetailsOfCarforRent3_Co2 { get; set; }
        public string TypeOfCar3_Co2 { get; set; }
        public bool IsVisibleTypeOfCar3_Co2 { get; set; }
        public bool IsDisableTypeOfCar3_Co2 { get; set; }
        public string CarPlateNumber3_Co2 { get; set; }
        public bool IsVisibleCarPlateNumber3_Co2 { get; set; }
        public bool IsDisableCarPlateNumber3_Co2 { get; set; }
        public string CarOwnershipName3_Co2 { get; set; }
        public bool IsVisibleCarOwnershipName3_Co2 { get; set; }
        public bool IsDisableCarOwnershipName3_Co2 { get; set; }
        public string CarLesseeNameAddressContact3_Co2 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact3_Co2 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact3_Co2 { get; set; }
        public string RentalContractTenure3_Co2 { get; set; }
        public bool IsVisibleRentalContractTenure3_Co2 { get; set; }
        public bool IsDisableRentalContractTenure3_Co2 { get; set; }
        public string CarMonthlyRentalFee3_Co2 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee3_Co2 { get; set; }
        public bool IsCarDisableMonthlyRentalFee3_Co2 { get; set; }
        public string CarRepaymentCycle3_Co2 { get; set; }
        public bool IsCarVisibleRepaymentCycle3_Co2 { get; set; }
        public bool IsCarDisableRepaymentCycle3_Co2 { get; set; }
        public int CarRepaymentCycle3ID_Co2 { get; set; }
        public string CarIncomePaymentMethod3_Co2 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod3_Co2 { get; set; }
        public bool IsCarDisableIncomePaymentMethod3_Co2 { get; set; }
        public int CarIncomePaymentMethod3ID_Co2 { get; set; }
        public decimal TotalCarRentalIncome3_Co2 { get; set; }
        public bool IsVisibleTotalCarRentalIncome3_Co2 { get; set; }
        public bool IsDisableTotalCarRentalIncome3_Co2 { get; set; }
        #endregion

        #region Income4
        public string DetailsOfCarforRent4_Co2 { get; set; }
        public bool IsVisibleDetailsOfCarforRent4_Co2 { get; set; }
        public bool IsDisableDetailsOfCarforRent4_Co2 { get; set; }
        public string TypeOfCar4_Co2 { get; set; }
        public bool IsVisibleTypeOfCar4_Co2 { get; set; }
        public bool IsDisableTypeOfCar4_Co2 { get; set; }
        public string CarPlateNumber4_Co2 { get; set; }
        public bool IsVisibleCarPlateNumber4_Co2 { get; set; }
        public bool IsDisableCarPlateNumber4_Co2 { get; set; }
        public string CarOwnershipName4_Co2 { get; set; }
        public bool IsVisibleCarOwnershipName4_Co2 { get; set; }
        public bool IsDisableCarOwnershipName4_Co2 { get; set; }
        public string CarLesseeNameAddressContact4_Co2 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact4_Co2 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact4_Co2 { get; set; }
        public string RentalContractTenure4_Co2 { get; set; }
        public bool IsVisibleRentalContractTenure4_Co2 { get; set; }
        public bool IsDisableRentalContractTenure4_Co2 { get; set; }
        public string CarMonthlyRentalFee4_Co2 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee4_Co2 { get; set; }
        public bool IsCarDisableMonthlyRentalFee4_Co2 { get; set; }
        public string CarRepaymentCycle4_Co2 { get; set; }
        public bool IsCarVisibleRepaymentCycle4_Co2 { get; set; }
        public bool IsCarDisableRepaymentCycle4_Co2 { get; set; }
        public int CarRepaymentCycle4ID_Co2 { get; set; }
        public string CarIncomePaymentMethod4_Co2 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod4_Co2 { get; set; }
        public bool IsCarDisableIncomePaymentMethod4_Co2 { get; set; }
        public int CarIncomePaymentMethod4ID_Co2 { get; set; }
        public decimal TotalCarRentalIncome4_Co2 { get; set; }
        public bool IsVisibleTotalCarRentalIncome4_Co2 { get; set; }
        public bool IsDisableTotalCarRentalIncome4_Co2 { get; set; }
        #endregion

        #endregion

        #endregion

        #region SelfEmployed

        #region Income1
        public string CompanyName1_Co2 { get; set; }
        public bool IsVisibleCompanyName1_Co2 { get; set; }
        public bool IsDisableCompanyName1_Co2 { get; set; }
        public string BusinessLicenceNumber1_Co2 { get; set; }
        public bool IsVisibleBusinessLicenceNumber1_Co2 { get; set; }
        public bool IsDisableBusinessLicenceNumber1_Co2 { get; set; }
        public string TaxCode1_Co2 { get; set; }
        public bool IsVisibleTaxCode1_Co2 { get; set; }
        public bool IsDisableTaxCode1_Co2 { get; set; }
        public string CompanyAddress1_Co2 { get; set; }
        public bool IsVisibleCompanyAddress1_Co2 { get; set; }
        public bool IsDisableCompanyAddress1_Co2 { get; set; }
        public string SelfWard1_Co2 { get; set; }
        public bool IsVisibleSelfWard1_Co2 { get; set; }
        public bool IsDisableSelfWard1_Co2 { get; set; }
        public string DisTrict1_Co2 { get; set; }
        public bool IsVisibleDisTrict1_Co2 { get; set; }
        public bool IsDisableDisTrict1_Co2 { get; set; }
        public int DisTrict1ID_Co2 { get; set; }
        public string SelfCity1_Co2 { get; set; }
        public bool IsVisibleSelfCity1_Co2 { get; set; }
        public bool IsDisableSelfCity1_Co2 { get; set; }
        public string SelfCity1ID_Co2 { get; set; }
        public string Ofcetel1_Co2 { get; set; }
        public bool IsVisibleOfcetel1_Co2 { get; set; }
        public bool IsDisableOfcetel1_Co2 { get; set; }
        public string MainCompanyIndustry11_Co2 { get; set; }
        public bool IsVisibleMainCompanyIndustry11_Co2 { get; set; }
        public bool IsDisableMainCompanyIndustry11_Co2 { get; set; }
        public int MainCompanyIndustry11ID_Co2 { get; set; }
        public string MainCompanyIndustry21_Co2 { get; set; }
        public bool IsVisibleMainCompanyIndustry21_Co2 { get; set; }
        public bool IsDisableMainCompanyIndustry21_Co2 { get; set; }
        public int MainCompanyIndustry21ID_Co2 { get; set; }
        public string OtherCompanyIndustryBizNature1_Co2 { get; set; }
        public bool IsVisibleOtherCompanyIndustryBizNature1_Co2 { get; set; }
        public bool IsDisableOtherCompanyIndustryBizNature1_Co2 { get; set; }
        public string SeasonalIndustry1_Co2 { get; set; }
        public bool IsVisibleSeasonalIndustry1_Co2 { get; set; }
        public bool IsDisableSeasonalIndustry1_Co2 { get; set; }
        public Nullable<DateTime> EstablishedYear1_Co2 { get; set; }
        public bool IsVisibleEstablishedYear1_Co2 { get; set; }
        public bool IsDisableEstablishedYear1_Co2 { get; set; }
        public int TotalYearsInOperation1_Co2 { get; set; }
        public bool IsVisibleTotalYearsInOperation1_Co2 { get; set; }
        public bool IsDisableTotalYearsInOperation1_Co2 { get; set; }
        public int ShareholdingInCompany1_Co2 { get; set; }
        public bool IsVisibleShareholdingInCompany1_Co2 { get; set; }
        public bool IsDisableShareholdingInCompany1_Co2 { get; set; }
        public string ProfLossinLatestYear1_Co2 { get; set; }
        public bool IsVisibleProfLossinLatestYear1_Co2 { get; set; }
        public bool IsDisableProfLossinLatestYear1_Co2 { get; set; }
        public int ProfLossinLatestYear1ID_Co2 { get; set; }
        public string TypeOfSelfEmploymentIncome1_Co2 { get; set; }
        public bool IsVisibleTypeOfSelfEmploymentIncome1_Co2 { get; set; }
        public bool IsDisableTypeOfSelfEmploymentIncome1_Co2 { get; set; }
        public int TypeOfSelfEmploymentIncome1ID_Co2 { get; set; }
        public int TotalTurnoverinFS1_Co2 { get; set; }
        public bool IsVisibleTotalTurnoverinFS1_Co2 { get; set; }
        public bool IsDisableTotalTurnoverinFS1_Co2 { get; set; }
        public decimal MonthlyTurnoverinyear1_Co2 { get; set; }
        public bool IsVisibleMonthlyTurnoverinyear1_Co2 { get; set; }
        public bool IsDisableMonthlyTurnoverinyear1_Co2 { get; set; }
        /// <summary>
        /// /////
        /// </summary>
        /// 
        public decimal TotalUpdatedTurnover1_Co2 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover1_Co2 { get; set; }
        public bool IsDisableTotalUpdatedTurnover1_Co2 { get; set; }
        public decimal AverageMonthlyUpdatedTurnover1_Co2 { get; set; }
        public bool IsVisibleAverageMonthlyUpdatedTurnover1_Co2 { get; set; }
        public bool IsDisableAverageMonthlyUpdatedTurnover1_Co2 { get; set; }
        public decimal ComparedWithTurnOver1_Co2 { get; set; }
        public bool IsVisibleComparedWithTurnOver1_Co2 { get; set; }
        public bool IsDisableComparedWithTurnOver1_Co2 { get; set; }
        public decimal RevisedAverageMonthlyTurnover1_Co2 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnover1_Co2 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnover1_Co2 { get; set; }
        public int SplitupIndustry11_Co2 { get; set; }
        public bool IsVisibleSplitupIndustry11_Co2 { get; set; }
        public bool IsDisableSplitupIndustry11_Co2 { get; set; }
        public int SplitupIndustry21_Co2 { get; set; }
        public bool IsVisibleSplitupIndustry21_Co2 { get; set; }
        public bool IsDisableSplitupIndustry21_Co2 { get; set; }
        public int SplitupIndustry31_Co2 { get; set; }
        public bool IsVisibleSplitupIndustry31_Co2 { get; set; }
        public bool IsDisableSplitupIndustry31_Co2 { get; set; }
        public int IndustrialMargin11_Co2 { get; set; }
        public bool IsVisibleIndustrialMargin11_Co2 { get; set; }
        public bool IsDisableIndustrialMargin11_Co2 { get; set; }
        public int IndustrialMargin21_Co2 { get; set; }
        public bool IsVisibleIndustrialMargin21_Co2 { get; set; }
        public bool IsDisableIndustrialMargin21_Co2 { get; set; }
        public int IndustrialMargin31_Co2 { get; set; }
        public bool IsVisibleIndustrialMargin31_Co2 { get; set; }
        public bool IsDisableIndustrialMargin31_Co2 { get; set; }
        public string Remark1_Co2 { get; set; }
        public bool IsVisibleRemark1_Co2 { get; set; }
        public bool IsDisableRemark1_Co2 { get; set; }
        public decimal MonthlySeflEmployedIncome1_Co2 { get; set; }
        public bool IsVisibleMonthlySeflEmployedIncome1_Co2 { get; set; }
        public bool IsDisableMonthlySeflEmployedIncome1_Co2 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncome1_Co2 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncome1_Co2 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncome1_Co2 { get; set; }
        public int TotalTurnoverinFSBank1_Co2 { get; set; }
        public bool IsVisibleTotalTurnoverinFSBank1_Co2 { get; set; }
        public bool IsDisableTotalTurnoverinFSBank1_Co2 { get; set; }
        public decimal MonthlyTurnoverInyearBank1_Co2 { get; set; }
        public bool IsVisibleMonthlyTurnoverInyearBank1_Co2 { get; set; }
        public bool IsDisableMonthlyTurnoverInyearBank1_Co2 { get; set; }
        public int OtherMonthlyTurnover1_Co2 { get; set; }
        public bool IsVisibleOtherMonthlyTurnover1_Co2 { get; set; }
        public bool IsDisableOtherMonthlyTurnover1_Co2 { get; set; }
        public decimal AverageEligibleCreditBalance1_Co2 { get; set; }
        public bool IsVisibleAverageEligibleCreditBalance1_Co2 { get; set; }
        public bool IsDisableAverageEligibleCreditBalance1_Co2 { get; set; }
        public decimal TotalEligibleMonthlyIncome1_Co2 { get; set; }
        public bool IsVisibleTotalEligibleMonthlyIncome1_Co2 { get; set; }
        public bool IsDisableTotalEligibleMonthlyIncome1_Co2 { get; set; }
        public decimal RevisedAverageMonthlyTurnoverBank1_Co2 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnoverBank1_Co2 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnoverBank1_Co2 { get; set; }
        public int SplitupIndustry1Bank1_Co2 { get; set; }
        public bool IsVisibleSplitupIndustry1Bank1_Co2 { get; set; }
        public bool IsDisableSplitupIndustry1Bank1_Co2 { get; set; }
        public int SplitupIndustry2Bank1_Co2 { get; set; }
        public bool IsVisibleSplitupIndustry2Bank1_Co2 { get; set; }
        public bool IsDisableSplitupIndustry2Bank1_Co2 { get; set; }
        public int SplitupIndustry3Bank1_Co2 { get; set; }
        public bool IsVisibleSplitupIndustry3Bank1_Co2 { get; set; }
        public bool IsDisableSplitupIndustry3Bank1_Co2 { get; set; }
        public int IndustrialMargin1Bank1_Co2 { get; set; }
        public bool IsVisibleIndustrialMargin1Bank1_Co2 { get; set; }
        public bool IsDisableIndustrialMargin1Bank1_Co2 { get; set; }
        public int IndustrialMargin2Bank1_Co2 { get; set; }
        public bool IsVisibleIndustrialMargin2Bank1_Co2 { get; set; }
        public bool IsDisableIndustrialMargin2Bank1_Co2 { get; set; }
        public int IndustrialMargin3Bank1_Co2 { get; set; }
        public bool IsVisibleIndustrialMargin3Bank1_Co2 { get; set; }
        public bool IsDisableIndustrialMargin3Bank1_Co2 { get; set; }
        public string RemarkBank1_Co2 { get; set; }
        public bool IsVisibleRemarkBank1_Co2 { get; set; }
        public bool IsDisableRemarkBank1_Co2 { get; set; }
        public decimal MonthlySelfEmployedIncome1_Co2 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncome1_Co2 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncome1_Co2 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeBank1_Co2 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeBank1_Co2 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeBank1_Co2 { get; set; }
        public int TotalTurnoverInFS1_Co2 { get; set; }
        public bool IsVisibleTotalTurnoverInFS1_Co2 { get; set; }
        public bool IsDisableTotalTurnoverInFS1_Co2 { get; set; }
        public int ProftafertaxinLatestYear1_Co2 { get; set; }
        public bool IsVisibleProftafertaxinLatestYear1_Co2 { get; set; }
        public bool IsDisableProftafertaxinLatestYear1_Co2 { get; set; }
        public int Depreciation1_Co2 { get; set; }
        public bool IsVisibleDepreciation1_Co2 { get; set; }
        public bool IsDisableDepreciation1_Co2 { get; set; }
        public decimal MonthlyTurnoverInYear1_Co2 { get; set; }
        public bool IsVisibleMonthlyTurnoverInYear1_Co2 { get; set; }
        public bool IsDisableMonthlyTurnoverInYear1_Co2 { get; set; }
        public decimal MonthlySelfEmployedIncomeCPP1_Co2 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncomeCPP1_Co2 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncomeCPP1_Co2 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeCPP1_Co2 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeCPP1_Co2 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeCPP1_Co2 { get; set; }

        #endregion

        #region Income2
        public string CompanyName2_Co2 { get; set; }
        public bool IsVisibleCompanyName2_Co2 { get; set; }
        public bool IsDisableCompanyName2_Co2 { get; set; }
        public string BusinessLicenceNumber2_Co2 { get; set; }
        public bool IsVisibleBusinessLicenceNumber2_Co2 { get; set; }
        public bool IsDisableBusinessLicenceNumber2_Co2 { get; set; }
        public string TaxCode2_Co2 { get; set; }
        public bool IsVisibleTaxCode2_Co2 { get; set; }
        public bool IsDisableTaxCode2_Co2 { get; set; }
        public string CompanyAddress2_Co2 { get; set; }
        public bool IsVisibleCompanyAddress2_Co2 { get; set; }
        public bool IsDisableCompanyAddress2_Co2 { get; set; }
        public string SelfWard2_Co2 { get; set; }
        public bool IsVisibleSelfWard2_Co2 { get; set; }
        public bool IsDisableSelfWard2_Co2 { get; set; }
        public string DisTrict2_Co2 { get; set; }
        public bool IsVisibleDisTrict2_Co2 { get; set; }
        public bool IsDisableDisTrict2_Co2 { get; set; }
        public int DisTrict2ID_Co2 { get; set; }
        public string SelfCity2_Co2 { get; set; }
        public bool IsVisibleSelfCity2_Co2 { get; set; }
        public bool IsDisableSelfCity2_Co2 { get; set; }
        public string SelfCity2ID_Co2 { get; set; }
        public string Ofcetel2_Co2 { get; set; }
        public bool IsVisibleOfcetel2_Co2 { get; set; }
        public bool IsDisableOfcetel2_Co2 { get; set; }
        public string MainCompanyIndustry12_Co2 { get; set; }
        public bool IsVisibleMainCompanyIndustry12_Co2 { get; set; }
        public bool IsDisableMainCompanyIndustry12_Co2 { get; set; }
        public int MainCompanyIndustry12ID_Co2 { get; set; }
        public string MainCompanyIndustry22_Co2 { get; set; }
        public bool IsVisibleMainCompanyIndustry22_Co2 { get; set; }
        public bool IsDisableMainCompanyIndustry22_Co2 { get; set; }
        public int MainCompanyIndustry22ID_Co2 { get; set; }
        public string OtherCompanyIndustryBizNature2_Co2 { get; set; }
        public bool IsVisibleOtherCompanyIndustryBizNature2_Co2 { get; set; }
        public bool IsDisableOtherCompanyIndustryBizNature2_Co2 { get; set; }
        public string SeasonalIndustry2_Co2 { get; set; }
        public bool IsVisibleSeasonalIndustry2_Co2 { get; set; }
        public bool IsDisableSeasonalIndustry2_Co2 { get; set; }
        public Nullable<DateTime> EstablishedYear2_Co2 { get; set; }
        public bool IsVisibleEstablishedYear2_Co2 { get; set; }
        public bool IsDisableEstablishedYear2_Co2 { get; set; }
        public int TotalYearsInOperation2_Co2 { get; set; }
        public bool IsVisibleTotalYearsInOperation2_Co2 { get; set; }
        public bool IsDisableTotalYearsInOperation2_Co2 { get; set; }
        public int ShareholdingInCompany2_Co2 { get; set; }
        public bool IsVisibleShareholdingInCompany2_Co2 { get; set; }
        public bool IsDisableShareholdingInCompany2_Co2 { get; set; }
        public string ProfLossinLatestYear2_Co2 { get; set; }
        public bool IsVisibleProfLossinLatestYear2_Co2 { get; set; }
        public bool IsDisableProfLossinLatestYear2_Co2 { get; set; }
        public int ProfLossinLatestYear2ID_Co2 { get; set; }
        public string TypeOfSelfEmploymentIncome2_Co2 { get; set; }
        public bool IsVisibleTypeOfSelfEmploymentIncome2_Co2 { get; set; }
        public bool IsDisableTypeOfSelfEmploymentIncome2_Co2 { get; set; }
        public int TypeOfSelfEmploymentIncome2ID_Co2 { get; set; }
        public int TotalTurnoverinFS2_Co2 { get; set; }
        public bool IsVisibleTotalTurnoverinFS2_Co2 { get; set; }
        public bool IsDisableTotalTurnoverinFS2_Co2 { get; set; }
        public decimal MonthlyTurnoverinyear2_Co2 { get; set; }
        public bool IsVisibleMonthlyTurnoverinyear2_Co2 { get; set; }
        public bool IsDisableMonthlyTurnoverinyear2_Co2 { get; set; }
        /// <summary>
        /// ////
        /// </summary>
        /// 
        public decimal TotalUpdatedTurnover2_Co2 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover2_Co2 { get; set; }
        public bool IsDisableTotalUpdatedTurnover2_Co2 { get; set; }
        public decimal AverageMonthlyUpdatedTurnover2_Co2 { get; set; }
        public bool IsVisibleAverageMonthlyUpdatedTurnover2_Co2 { get; set; }
        public bool IsDisableAverageMonthlyUpdatedTurnover2_Co2 { get; set; }
        public decimal ComparedWithTurnOverBank2_Co2 { get; set; }
        public bool IsVisibleComparedWithTurnOverbank2_Co2 { get; set; }
        public bool IsDisableComparedWithTurnOverBank2_Co2 { get; set; }
        public decimal RevisedAverageMonthlyTurnover2_Co2 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnover2_Co2 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnover2_Co2 { get; set; }
        public int SplitupIndustry12_Co2 { get; set; }
        public bool IsVisibleSplitupIndustry12_Co2 { get; set; }
        public bool IsDisableSplitupIndustry12_Co2 { get; set; }
        public int SplitupIndustry22_Co2 { get; set; }
        public bool IsVisibleSplitupIndustry22_Co2 { get; set; }
        public bool IsDisableSplitupIndustry22_Co2 { get; set; }
        public int SplitupIndustry32_Co2 { get; set; }
        public bool IsVisibleSplitupIndustry32_Co2 { get; set; }
        public bool IsDisableSplitupIndustry32_Co2 { get; set; }
        public int IndustrialMargin12_Co2 { get; set; }
        public bool IsVisibleIndustrialMargin12_Co2 { get; set; }
        public bool IsDisableIndustrialMargin12_Co2 { get; set; }
        public int IndustrialMargin22_Co2 { get; set; }
        public bool IsVisibleIndustrialMargin22_Co2 { get; set; }
        public bool IsDisableIndustrialMargin22_Co2 { get; set; }
        public int IndustrialMargin32_Co2 { get; set; }
        public bool IsVisibleIndustrialMargin32_Co2 { get; set; }
        public bool IsDisableIndustrialMargin32_Co2 { get; set; }
        public string Remark2_Co2 { get; set; }
        public bool IsVisibleRemark2_Co2 { get; set; }
        public bool IsDisableRemark2_Co2 { get; set; }
        public decimal MonthlySeflEmployedIncome2_Co2 { get; set; }
        public bool IsVisibleMonthlySeflEmployedIncome2_Co2 { get; set; }
        public bool IsDisableMonthlySeflEmployedIncome2_Co2 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncome2_Co2 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncome2_Co2 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncome2_Co2 { get; set; }
        public int TotalTurnoverinFSBank2_Co2 { get; set; }
        public bool IsVisibleTotalTurnoverinFSBank2_Co2 { get; set; }
        public bool IsDisableTotalTurnoverinFSBank2_Co2 { get; set; }
        public decimal MonthlyTurnoverInyearBank2_Co2 { get; set; }
        public bool IsVisibleMonthlyTurnoverInyearBank2_Co2 { get; set; }
        public bool IsDisableMonthlyTurnoverInyearBank2_Co2 { get; set; }
        public int OtherMonthlyTurnover2_Co2 { get; set; }
        public bool IsVisibleOtherMonthlyTurnover2_Co2 { get; set; }
        public bool IsDisableOtherMonthlyTurnover2_Co2 { get; set; }
        public decimal AverageEligibleCreditBalance2_Co2 { get; set; }
        public bool IsVisibleAverageEligibleCreditBalance2_Co2 { get; set; }
        public bool IsDisableAverageEligibleCreditBalance2_Co2 { get; set; }
        public decimal TotalEligibleMonthlyIncome2_Co2 { get; set; }
        public bool IsVisibleTotalEligibleMonthlyIncome2_Co2 { get; set; }
        public bool IsDisableTotalEligibleMonthlyIncome2_Co2 { get; set; }
        public decimal RevisedAverageMonthlyTurnoverBank2_Co2 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnoverBank2_Co2 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnoverBank2_Co2 { get; set; }
        public int SplitupIndustry1Bank2_Co2 { get; set; }
        public bool IsVisibleSplitupIndustry1Bank2_Co2 { get; set; }
        public bool IsDisableSplitupIndustry1Bank2_Co2 { get; set; }
        public int SplitupIndustry2Bank2_Co2 { get; set; }
        public bool IsVisibleSplitupIndustry2Bank2_Co2 { get; set; }
        public bool IsDisableSplitupIndustry2Bank2_Co2 { get; set; }
        public int SplitupIndustry3Bank2_Co2 { get; set; }
        public bool IsVisibleSplitupIndustry3Bank2_Co2 { get; set; }
        public bool IsDisableSplitupIndustry3Bank2_Co2 { get; set; }
        public int IndustrialMargin1Bank2_Co2 { get; set; }
        public bool IsVisibleIndustrialMargin1Bank2_Co2 { get; set; }
        public bool IsDisableIndustrialMargin1Bank2_Co2 { get; set; }
        public int IndustrialMargin2Bank2_Co2 { get; set; }
        public bool IsVisibleIndustrialMargin2Bank2_Co2 { get; set; }
        public bool IsDisableIndustrialMargin2Bank2_Co2 { get; set; }
        public int IndustrialMargin3Bank2_Co2 { get; set; }
        public bool IsVisibleIndustrialMargin3Bank2_Co2 { get; set; }
        public bool IsDisableIndustrialMargin3Bank2_Co2 { get; set; }
        public string RemarkBank2_Co2 { get; set; }
        public bool IsVisibleRemarkBank2_Co2 { get; set; }
        public bool IsDisableRemarkBank2_Co2 { get; set; }
        public decimal MonthlySelfEmployedIncome2_Co2 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncome2_Co2 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncome2_Co2 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeBank2_Co2 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeBank2_Co2 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeBank2_Co2 { get; set; }
        public int TotalTurnoverInFS2_Co2 { get; set; }
        public bool IsVisibleTotalTurnoverInFS2_Co2 { get; set; }
        public bool IsDisableTotalTurnoverInFS2_Co2 { get; set; }
        public int ProftafertaxinLatestYear2_Co2 { get; set; }
        public bool IsVisibleProftafertaxinLatestYear2_Co2 { get; set; }
        public bool IsDisableProftafertaxinLatestYear2_Co2 { get; set; }
        public int Depreciation2_Co2 { get; set; }
        public bool IsVisibleDepreciation2_Co2 { get; set; }
        public bool IsDisableDepreciation2_Co2 { get; set; }
        public decimal MonthlyTurnoverInYear2_Co2 { get; set; }
        public bool IsVisibleMonthlyTurnoverInYear2_Co2 { get; set; }
        public bool IsDisableMonthlyTurnoverInYear2_Co2 { get; set; }
        public decimal MonthlySelfEmployedIncomeCPP2_Co2 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncomeCPP2_Co2 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncomeCPP2_Co2 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeCPP2_Co2 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeCPP2_Co2 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeCPP2_Co2 { get; set; }
        #endregion

        #endregion

        #region Other

        #region Income1
        public int DiscountRate1_Co2 { get; set; }
        public bool IsVisibleDiscountRate1_Co2 { get; set; }
        public bool IsDisableDiscountRate1_Co2 { get; set; }
        public decimal TotalUpdatedTurnover1_other_Co2 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover1_other_Co2 { get; set; }
        public bool IsDisableTotalUpdatedTurnover1_other_Co2 { get; set; }

        #endregion

        #region Income2
        public int DiscountRate2_Co2 { get; set; }
        public bool IsVisibleDiscountRate2_Co2 { get; set; }
        public bool IsDisableDiscountRate2_Co2 { get; set; }
        public decimal TotalUpdatedTurnover2_other_Co2 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover2_other_Co2 { get; set; }
        public bool IsDisableTotalUpdatedTurnover2_other_Co2 { get; set; }
        #endregion

        #region Income3
        public int DiscountRate3_Co2 { get; set; }
        public bool IsVisibleDiscountRate3_Co2 { get; set; }
        public bool IsDisableDiscountRate3_Co2 { get; set; }
        public decimal TotalUpdatedTurnover3_other_Co2 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover3_other_Co2 { get; set; }
        public bool IsDisableTotalUpdatedTurnover3_other_Co2 { get; set; }
        #endregion

        #region Income4
        public int DiscountRate4_Co2 { get; set; }
        public bool IsVisibleDiscountRate4_Co2 { get; set; }
        public bool IsDisableDiscountRate4_Co2 { get; set; }
        public decimal TotalUpdatedTurnover4_other_Co2 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover4_other_Co2 { get; set; }
        public bool IsDisableTotalUpdatedTurnover4_other_Co2 { get; set; }
        #endregion



        #endregion

        public float TotalIncome_Co2 { get; set; }
        public bool IsVisibleTotalIncome_Co2 { get; set; }
        public bool IsDisableTotalIncome_Co2 { get; set; }
        #endregion

        #region Co3

        #region SalariedClient
        #region Income1
        public string CompanyCode_Co3 { get; set; }
        public bool IsVisibleCompanyCode_Co3 { get; set; }
        public bool IsDisableCompanyCode_Co3 { get; set; }

        public string CompanyName_Co3 { get; set; }
        public bool IsVisibleCompanyName_Co3 { get; set; }
        public bool IsDisableCompanyName_Co3 { get; set; }

        public string CompanyAddress_Co3 { get; set; }
        public bool IsVisibleCompanyAddress_Co3 { get; set; }
        public bool IsDisableCompanyAddress_Co3 { get; set; }

        public string Ward_Company_Co3 { get; set; }
        public bool IsVisibleWard_Company_Co3 { get; set; }
        public bool IsDisableWard_Company_Co3 { get; set; }

        public string District_Company_Co3 { get; set; }
        public bool IsVisibleDistrict_Company_Co3 { get; set; }
        public bool IsDisableDistrict_Company_Co3 { get; set; }

        public string City_Company_Co3 { get; set; }
        public bool IsVisibleCity_Company_Co3 { get; set; }
        public bool IsDisableCity_Company_Co3 { get; set; }

        public int CityID_Company_Co3 { get; set; }
        public bool IsVisibleCityID_Company_Co3 { get; set; }
        public bool IsDisableCityID_Company_Co3 { get; set; }

        public string OfceTel_Co3 { get; set; }
        public bool IsVisibleOfceTel_Co3 { get; set; }
        public bool IsDisableOfceTel_Co3 { get; set; }

        public string CompanyNatureOfBusiness_Co3 { get; set; }
        public bool IsVisibleCompanyNatureOfBusiness_Co3 { get; set; }
        public bool IsDisableCompanyNatureOfBusiness_Co3 { get; set; }
        public int CompanyNatureOfBusinessID_Co3 { get; set; }

        public string CompanyIndustry_Co3 { get; set; }
        public bool IsVisibleCompanyIndustry_Co3 { get; set; }
        public bool IsDisableCompanyIndustry_Co3 { get; set; }
        public int CompanyIndustryID_Co3 { get; set; }

        public string Occupation_Co3 { get; set; }
        public bool IsVisibleOccupation_Co3 { get; set; }
        public bool IsDisableOccupation_Co3 { get; set; }
        public int OccupationID_Co3 { get; set; }

        public string CurrentPosition_Co3 { get; set; }
        public bool IsVisibleCurrentPosition_Co3 { get; set; }
        public bool IsDisableCurrentPosition_Co3 { get; set; }
        public int CurrentPositionID_Co3 { get; set; }

        public string EmploymentType_Co3 { get; set; }
        public bool IsVisibleEmploymentType_Co3 { get; set; }
        public bool IsDisableEmploymentType_Co3 { get; set; }
        public int EmploymentTypeID_Co3 { get; set; }

        public string WorkingAddress_Co3 { get; set; }
        public bool IsVisibleWorkingAddress_Co3 { get; set; }
        public bool IsDisableWorkingAddress_Co3 { get; set; }

        public string Ward_Working_Co3 { get; set; }
        public bool IsVisibleWard_Working_Co3 { get; set; }
        public bool IsDisableWard_Working_Co3 { get; set; }

        public string District_Working_Co3 { get; set; }
        public bool IsVisibleDistrict_Working_Co3 { get; set; }
        public bool IsDisableDistrict_Working_Co3 { get; set; }
        public int DistrictID_Working_Co3 { get; set; }

        public string City_Working_Co3 { get; set; }
        public bool IsVisibleCity_Working_Co3 { get; set; }
        public bool IsDisableCity_Working_Co3 { get; set; }

        public string PercentSharesInCompany_Co3 { get; set; }
        public bool IsVisiblePercentSharesInCompany_Co3 { get; set; }
        public bool IsDisablePercentSharesInCompany_Co3 { get; set; }

        public string TypeOfLabourContract_Co3 { get; set; }
        public bool IsVisibleTypeOfLabourContract_Co3 { get; set; }
        public bool IsDisableTypeOfLabourContract_Co3 { get; set; }
        public int TypeOfLabourContractID_Co3 { get; set; }

        public string ContractLength_Co3 { get; set; }
        public bool IsVisibleContractLength_Co3 { get; set; }
        public bool IsDisableContractLength_Co3 { get; set; }
        public int ContractLengthID_Co3 { get; set; }

        public Nullable<System.DateTime> StartDateAtCurrentCompany_Co3 { get; set; }
        public bool IsVisibleStartDateAtCurrentCompany_Co3 { get; set; }
        public bool IsDisableStartDateAtCurrentCompany_Co3 { get; set; }

        public int TotalMonthsInCurrentCompany_Co3 { get; set; }
        public bool IsVisibleTotalMonthsInCurrentCompany_Co3 { get; set; }
        public bool IsDisableTotalMonthsInCurrentCompany_Co3 { get; set; }

        public int TotalMonthsInWorkingExperience_Co3 { get; set; }
        public bool IsVisibleTotalMonthsInWorkingExperience_Co3 { get; set; }
        public bool IsDisableTotalMonthsInWorkingExperience_Co3 { get; set; }

        public string Incometype_Co3 { get; set; }
        public bool IsVisibleIncometype_Co3 { get; set; }
        public bool IsDisableIncometype_Co3 { get; set; }
        public int IncometypeID_Co3 { get; set; }

        public float MonthlyIncome_Co3 { get; set; }
        public bool IsVisibleMonthlyIncome_Co3 { get; set; }
        public bool IsDisableMonthlyIncome_Co3 { get; set; }

        public string PeriodOfSubmittedBS_Co3 { get; set; }
        public bool IsVisiblePeriodOfSubmittedBS_Co3 { get; set; }
        public bool IsDisablePeriodOfSubmittedBS_Co3 { get; set; }
        public int PeriodOfSubmittedBSID_Co3 { get; set; }

        public bool FreelanceIncome_Co3 { get; set; }
        public bool IsVisibleFreelanceIncome_Co3 { get; set; }
        public bool IsDisableFreelanceIncome_Co3 { get; set; }

        public float GrossBaseSalary_Co3 { get; set; }
        public bool IsVisibleGrossBaseSalary_Co3 { get; set; }
        public bool IsDisableGrossBaseSalary_Co3 { get; set; }

        public float BasicAllowance_Co3 { get; set; }
        public bool IsVisibleBasicAllowance_Co3 { get; set; }
        public bool IsDisableBasicAllowance_Co3 { get; set; }

        public float EligibleFixedIncomeOnLC_Co3 { get; set; }
        public bool IsVisibleEligibleFixedIncomeOnLC_Co3 { get; set; }
        public bool IsDisableEligibleFixedIncomeOnLC_Co3 { get; set; }

        public float FixedIncomeViaBS_Co3 { get; set; }
        public bool IsVisibleFixedIncomeViaBS_Co3 { get; set; }
        public bool IsDisableFixedIncomeViaBS_Co3 { get; set; }

        public float TotalMonthlyIncomeViaBS_Co3 { get; set; }
        public bool IsVisibleTotalMonthlyIncomeViaBS_Co3 { get; set; }
        public bool IsDisableTotalMonthlyIncomeViaBS_Co3 { get; set; }

        public float PerformanceBonus_Co3 { get; set; }
        public bool IsVisiblePerformanceBonus_Co3 { get; set; }
        public bool IsDisablePerformanceBonus_Co3 { get; set; }

        public float FinalIncome_Co3 { get; set; }
        public bool IsVisibleFinalIncome_Co3 { get; set; }
        public bool IsDisableFinalIncome_Co3 { get; set; }
        #endregion
        #region Income2       
        #endregion
        public float TotalSalariedIncome_Co3 { get; set; }
        public bool IsVisibleTotalSalariedIncome_Co3 { get; set; }
        public bool IsDisableTotalSalariedIncome_Co3 { get; set; }
        #endregion

        #region Rental

        #region House Rental

        #region Income1
        //public int CustomerIncomeID_Main_Income_1 { get; set; }
        //public int ALCustomerIncomeID_Main_Income_1 { get; set; }
        //public int ALCustomerSalariedIncomeID_Main_Income_1 { get; set; }
        public string DetailsOfPropertyForRent1_Co3 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent1_Co3 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent1_Co3 { get; set; }
        public string RentalPropertyAddress1_Co3 { get; set; }
        public bool IsVisibleRentalPropertyAddress1_Co3 { get; set; }
        public bool IsDisableRentalPropertyAddress1_Co3 { get; set; }
        public string RentalPropertyOwnershipName1_Co3 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName1_Co3 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName1_Co3 { get; set; }
        public string LesseeNameAddressContact1_Co3 { get; set; }
        public bool IsVisibleLesseeNameAddressContact1_Co3 { get; set; }
        public bool IsDisableLesseeNameAddressContact1_Co3 { get; set; }
        public string Ward1_Co3 { get; set; }
        public bool IsVisibleWard1_Co3 { get; set; }
        public bool IsDisableWard1_Co3 { get; set; }
        public string District1_Co3 { get; set; }
        public bool IsVisibleDistrict1_Co3 { get; set; }
        public bool IsDisableDistrict1_Co3 { get; set; }
        public int District1ID_Co3 { get; set; }
        public string City1_Co3 { get; set; }
        public bool IsVisibleCity1_Co3 { get; set; }
        public bool IsDisableCity1_Co3 { get; set; }
        public int City1ID_Co3 { get; set; }
        public string RentalContaclTenure1_Co3 { get; set; }
        public bool IsVisibleRentalContaclTenure1_Co3 { get; set; }
        public bool IsDisableRentalContaclTenure1_Co3 { get; set; }
        public string MonthlyRentalFee1_Co3 { get; set; }
        public bool IsVisibleMonthlyRentalFee1_Co3 { get; set; }
        public bool IsDisableMonthlyRentalFee1_Co3 { get; set; }
        public string RentalPurpose1_Co3 { get; set; }
        public bool IsVisibleRentalPurpose1_Co3 { get; set; }
        public bool IsDisableRentalPurpose1_Co3 { get; set; }
        public string RepaymentCycle1_Co3 { get; set; }
        public bool IsVisibleRepaymentCycle1_Co3 { get; set; }
        public bool IsDisableRepaymentCycle1_Co3 { get; set; }
        public int RepaymentCycle1ID_Co3 { get; set; }
        public string IncomePaymentMethod1_Co3 { get; set; }
        public bool IsVisibleIncomePaymentMethod1_Co3 { get; set; }
        public bool IsDisableIncomePaymentMethod1_Co3 { get; set; }
        public int IncomePaymentMethod1ID_Co3 { get; set; }
        public decimal TotalRentalIncome1_Co3 { get; set; }
        public bool IsVisibleTotalRentalIncome1_Co3 { get; set; }
        public bool IsDisableTotalRentalIncome1_Co3 { get; set; }

        #endregion

        #region Income2
        public string DetailsOfPropertyForRent2_Co3 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent2_Co3 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent2_Co3 { get; set; }
        public string RentalPropertyAddress2_Co3 { get; set; }
        public bool IsVisibleRentalPropertyAddress2_Co3 { get; set; }
        public bool IsDisableRentalPropertyAddress2_Co3 { get; set; }
        public string RentalPropertyOwnershipName2_Co3 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName2_Co3 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName2_Co3 { get; set; }
        public string LesseeNameAddressContact2_Co3 { get; set; }
        public bool IsVisibleLesseeNameAddressContact2_Co3 { get; set; }
        public bool IsDisableLesseeNameAddressContact2_Co3 { get; set; }
        public string Ward2_Co3 { get; set; }
        public bool IsVisibleWard2_Co3 { get; set; }
        public bool IsDisableWard2_Co3 { get; set; }
        public string District2_Co3 { get; set; }
        public bool IsVisibleDistrict2_Co3 { get; set; }
        public bool IsDisableDistrict2_Co3 { get; set; }
        public int District2ID_Co3 { get; set; }
        public string City2_Co3 { get; set; }
        public bool IsVisibleCity2_Co3 { get; set; }
        public bool IsDisableCity2_Co3 { get; set; }
        public int City2ID_Co3 { get; set; }
        public string RentalContaclTenure2_Co3 { get; set; }
        public bool IsVisibleRentalContaclTenure2_Co3 { get; set; }
        public bool IsDisableRentalContaclTenure2_Co3 { get; set; }
        public string MonthlyRentalFee2_Co3 { get; set; }
        public bool IsVisibleMonthlyRentalFee2_Co3 { get; set; }
        public bool IsDisableMonthlyRentalFee2_Co3 { get; set; }
        public string RentalPurpose2_Co3 { get; set; }
        public bool IsVisibleRentalPurpose2_Co3 { get; set; }
        public bool IsDisableRentalPurpose2_Co3 { get; set; }
        public string RepaymentCycle2_Co3 { get; set; }
        public bool IsVisibleRepaymentCycle2_Co3 { get; set; }
        public bool IsDisableRepaymentCycle2_Co3 { get; set; }
        public int RepaymentCycle2ID_Co3 { get; set; }
        public string IncomePaymentMethod2_Co3 { get; set; }
        public bool IsVisibleIncomePaymentMethod2_Co3 { get; set; }
        public bool IsDisableIncomePaymentMethod2_Co3 { get; set; }
        public int IncomePaymentMethod2ID_Co3 { get; set; }
        public decimal TotalRentalIncome2_Co3 { get; set; }
        public bool IsVisibleTotalRentalIncome2_Co3 { get; set; }
        public bool IsDisableTotalRentalIncome2_Co3 { get; set; }
        #endregion

        #region Income3
        public string DetailsOfPropertyForRent3_Co3 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent3_Co3 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent3_Co3 { get; set; }
        public string RentalPropertyAddress3_Co3 { get; set; }
        public bool IsVisibleRentalPropertyAddress3_Co3 { get; set; }
        public bool IsDisableRentalPropertyAddress3_Co3 { get; set; }
        public string RentalPropertyOwnershipName3_Co3 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName3_Co3 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName3_Co3 { get; set; }
        public string LesseeNameAddressContact3_Co3 { get; set; }
        public bool IsVisibleLesseeNameAddressContact3_Co3 { get; set; }
        public bool IsDisableLesseeNameAddressContact3_Co3 { get; set; }
        public string Ward3_Co3 { get; set; }
        public bool IsVisibleWard3_Co3 { get; set; }
        public bool IsDisableWard3_Co3 { get; set; }
        public string District3_Co3 { get; set; }
        public bool IsVisibleDistrict3_Co3 { get; set; }
        public bool IsDisableDistrict3_Co3 { get; set; }
        public int District3ID_Co3 { get; set; }
        public string City3_Co3 { get; set; }
        public bool IsVisibleCity3_Co3 { get; set; }
        public bool IsDisableCity3_Co3 { get; set; }
        public int City3ID_Co3 { get; set; }
        public string RentalContaclTenure3_Co3 { get; set; }
        public bool IsVisibleRentalContaclTenure3_Co3 { get; set; }
        public bool IsDisableRentalContaclTenure3_Co3 { get; set; }
        public string MonthlyRentalFee3_Co3 { get; set; }
        public bool IsVisibleMonthlyRentalFee3_Co3 { get; set; }
        public bool IsDisableMonthlyRentalFee3_Co3 { get; set; }
        public string RentalPurpose3_Co3 { get; set; }
        public bool IsVisibleRentalPurpose3_Co3 { get; set; }
        public bool IsDisableRentalPurpose3_Co3 { get; set; }
        public string RepaymentCycle3_Co3 { get; set; }
        public bool IsVisibleRepaymentCycle3_Co3 { get; set; }
        public bool IsDisableRepaymentCycle3_Co3 { get; set; }
        public int RepaymentCycle3ID_Co3 { get; set; }
        public string IncomePaymentMethod3_Co3 { get; set; }
        public bool IsVisibleIncomePaymentMethod3_Co3 { get; set; }
        public bool IsDisableIncomePaymentMethod3_Co3 { get; set; }
        public int IncomePaymentMethod3ID_Co3 { get; set; }
        public decimal TotalRentalIncome3_Co3 { get; set; }
        public bool IsVisibleTotalRentalIncome3_Co3 { get; set; }
        public bool IsDisableTotalRentalIncome3_Co3 { get; set; }
        #endregion

        #region Income4
        public string DetailsOfPropertyForRent4_Co3 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent4_Co3 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent4_Co3 { get; set; }
        public string RentalPropertyAddress4_Co3 { get; set; }
        public bool IsVisibleRentalPropertyAddress4_Co3 { get; set; }
        public bool IsDisableRentalPropertyAddress4_Co3 { get; set; }
        public string RentalPropertyOwnershipName4_Co3 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName4_Co3 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName4_Co3 { get; set; }
        public string LesseeNameAddressContact4_Co3 { get; set; }
        public bool IsVisibleLesseeNameAddressContact4_Co3 { get; set; }
        public bool IsDisableLesseeNameAddressContact4_Co3 { get; set; }
        public string Ward4_Co3 { get; set; }
        public bool IsVisibleWard4_Co3 { get; set; }
        public bool IsDisableWard4_Co3 { get; set; }
        public string District4_Co3 { get; set; }
        public bool IsVisibleDistrict4_Co3 { get; set; }
        public bool IsDisableDistrict4_Co3 { get; set; }
        public int District4ID_Co3 { get; set; }
        public string City4_Co3 { get; set; }
        public bool IsVisibleCity4_Co3 { get; set; }
        public bool IsDisableCity4_Co3 { get; set; }
        public int City4ID_Co3 { get; set; }
        public string RentalContaclTenure4_Co3 { get; set; }
        public bool IsVisibleRentalContaclTenure4_Co3 { get; set; }
        public bool IsDisableRentalContaclTenure4_Co3 { get; set; }
        public string MonthlyRentalFee4_Co3 { get; set; }
        public bool IsVisibleMonthlyRentalFee4_Co3 { get; set; }
        public bool IsDisableMonthlyRentalFee4_Co3 { get; set; }
        public string RentalPurpose4_Co3 { get; set; }
        public bool IsVisibleRentalPurpose4_Co3 { get; set; }
        public bool IsDisableRentalPurpose4_Co3 { get; set; }
        public string RepaymentCycle4_Co3 { get; set; }
        public bool IsVisibleRepaymentCycle4_Co3 { get; set; }
        public bool IsDisableRepaymentCycle4_Co3 { get; set; }
        public int RepaymentCycle4ID_Co3 { get; set; }
        public string IncomePaymentMethod4_Co3 { get; set; }
        public bool IsVisibleIncomePaymentMethod4_Co3 { get; set; }
        public bool IsDisableIncomePaymentMethod4_Co3 { get; set; }
        public int IncomePaymentMethod4ID_Co3 { get; set; }
        public decimal TotalRentalIncome4_Co3 { get; set; }
        public bool IsVisibleTotalRentalIncome4_Co3 { get; set; }
        public bool IsDisableTotalRentalIncome4_Co3 { get; set; }
        #endregion

        #region Income5
        public string DetailsOfPropertyForRent5_Co3 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent5_Co3 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent5_Co3 { get; set; }
        public string RentalPropertyAddress5_Co3 { get; set; }
        public bool IsVisibleRentalPropertyAddress5_Co3 { get; set; }
        public bool IsDisableRentalPropertyAddress5_Co3 { get; set; }
        public string RentalPropertyOwnershipName5_Co3 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName5_Co3 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName5_Co3 { get; set; }
        public string LesseeNameAddressContact5_Co3 { get; set; }
        public bool IsVisibleLesseeNameAddressContact5_Co3 { get; set; }
        public bool IsDisableLesseeNameAddressContact5_Co3 { get; set; }
        public string Ward5_Co3 { get; set; }
        public bool IsVisibleWard5_Co3 { get; set; }
        public bool IsDisableWard5_Co3 { get; set; }
        public string District5_Co3 { get; set; }
        public bool IsVisibleDistrict5_Co3 { get; set; }
        public bool IsDisableDistrict5_Co3 { get; set; }
        public int District5ID_Co3 { get; set; }
        public string City5_Co3 { get; set; }
        public bool IsVisibleCity5_Co3 { get; set; }
        public bool IsDisableCity5_Co3 { get; set; }
        public int City5ID_Co3 { get; set; }
        public string RentalContaclTenure5_Co3 { get; set; }
        public bool IsVisibleRentalContaclTenure5_Co3 { get; set; }
        public bool IsDisableRentalContaclTenure5_Co3 { get; set; }
        public string MonthlyRentalFee5_Co3 { get; set; }
        public bool IsVisibleMonthlyRentalFee5_Co3 { get; set; }
        public bool IsDisableMonthlyRentalFee5_Co3 { get; set; }
        public string RentalPurpose5_Co3 { get; set; }
        public bool IsVisibleRentalPurpose5_Co3 { get; set; }
        public bool IsDisableRentalPurpose5_Co3 { get; set; }
        public string RepaymentCycle5_Co3 { get; set; }
        public bool IsVisibleRepaymentCycle5_Co3 { get; set; }
        public bool IsDisableRepaymentCycle5_Co3 { get; set; }
        public int RepaymentCycle5ID_Co3 { get; set; }
        public string IncomePaymentMethod5_Co3 { get; set; }
        public bool IsVisibleIncomePaymentMethod5_Co3 { get; set; }
        public bool IsDisableIncomePaymentMethod5_Co3 { get; set; }
        public int IncomePaymentMethod5ID_Co3 { get; set; }
        public decimal TotalRentalIncome5_Co3 { get; set; }
        public bool IsVisibleTotalRentalIncome5_Co3 { get; set; }
        public bool IsDisableTotalRentalIncome5_Co3 { get; set; }
        #endregion

        #region Income6
        public string DetailsOfPropertyForRent6_Co3 { get; set; }
        public bool IsVisibleDetailsOfPropertyForRent6_Co3 { get; set; }
        public bool IsDisableDetailsOfPropertyForRent6_Co3 { get; set; }
        public string RentalPropertyAddress6_Co3 { get; set; }
        public bool IsVisibleRentalPropertyAddress6_Co3 { get; set; }
        public bool IsDisableRentalPropertyAddress6_Co3 { get; set; }
        public string RentalPropertyOwnershipName6_Co3 { get; set; }
        public bool IsVisibleRentalPropertyOwnershipName6_Co3 { get; set; }
        public bool IsDisableRentalPropertyOwnershipName6_Co3 { get; set; }
        public string LesseeNameAddressContact6_Co3 { get; set; }
        public bool IsVisibleLesseeNameAddressContact6_Co3 { get; set; }
        public bool IsDisableLesseeNameAddressContact6_Co3 { get; set; }
        public string Ward6_Co3 { get; set; }
        public bool IsVisibleWard6_Co3 { get; set; }
        public bool IsDisableWard6_Co3 { get; set; }
        public string District6_Co3 { get; set; }
        public bool IsVisibleDistrict6_Co3 { get; set; }
        public bool IsDisableDistrict6_Co3 { get; set; }
        public int District6ID_Co3 { get; set; }
        public string City6_Co3 { get; set; }
        public bool IsVisibleCity6_Co3 { get; set; }
        public bool IsDisableCity6_Co3 { get; set; }
        public int City6ID_Co3 { get; set; }
        public string RentalContaclTenure6_Co3 { get; set; }
        public bool IsVisibleRentalContaclTenure6_Co3 { get; set; }
        public bool IsDisableRentalContaclTenure6_Co3 { get; set; }
        public string MonthlyRentalFee6_Co3 { get; set; }
        public bool IsVisibleMonthlyRentalFee6_Co3 { get; set; }
        public bool IsDisableMonthlyRentalFee6_Co3 { get; set; }
        public string RentalPurpose6_Co3 { get; set; }
        public bool IsVisibleRentalPurpose6_Co3 { get; set; }
        public bool IsDisableRentalPurpose6_Co3 { get; set; }
        public string RepaymentCycle6_Co3 { get; set; }
        public bool IsVisibleRepaymentCycle6_Co3 { get; set; }
        public bool IsDisableRepaymentCycle6_Co3 { get; set; }
        public int RepaymentCycle6ID_Co3 { get; set; }
        public string IncomePaymentMethod6_Co3 { get; set; }
        public bool IsVisibleIncomePaymentMethod6_Co3 { get; set; }
        public bool IsDisableIncomePaymentMethod6_Co3 { get; set; }
        public int IncomePaymentMethod6ID_Co3 { get; set; }
        public decimal TotalRentalIncome6_Co3 { get; set; }
        public bool IsVisibleTotalRentalIncome6_Co3 { get; set; }
        public bool IsDisableTotalRentalIncome6_Co3 { get; set; }
        #endregion
        #endregion

        #region Car Rental

        #region Income1
        public string DetailsOfCarforRent1_Co3 { get; set; }
        public bool IsVisibleDetailsOfCarforRent1_Co3 { get; set; }
        public bool IsDisableDetailsOfCarforRent1_Co3 { get; set; }
        public string TypeOfCar1_Co3 { get; set; }
        public bool IsVisibleTypeOfCar1_Co3 { get; set; }
        public bool IsDisableTypeOfCar1_Co3 { get; set; }
        public string CarPlateNumber1_Co3 { get; set; }
        public bool IsVisibleCarPlateNumber1_Co3 { get; set; }
        public bool IsDisableCarPlateNumber1_Co3 { get; set; }
        public string CarOwnershipName1_Co3 { get; set; }
        public bool IsVisibleCarOwnershipName1_Co3 { get; set; }
        public bool IsDisableCarOwnershipName1_Co3 { get; set; }
        public string CarLesseeNameAddressContact1_Co3 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact1_Co3 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact1_Co3 { get; set; }
        public string RentalContractTenure1_Co3 { get; set; }
        public bool IsVisibleRentalContractTenure1_Co3 { get; set; }
        public bool IsDisableRentalContractTenure1_Co3 { get; set; }
        public string CarMonthlyRentalFee1_Co3 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee1_Co3 { get; set; }
        public bool IsCarDisableMonthlyRentalFee1_Co3 { get; set; }
        public string CarRepaymentCycle1_Co3 { get; set; }
        public bool IsCarVisibleRepaymentCycle1_Co3 { get; set; }
        public bool IsCarDisableRepaymentCycle1_Co3 { get; set; }
        public int CarRepaymentCycle1ID_Co3 { get; set; }
        public string CarIncomePaymentMethod1_Co3 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod1_Co3 { get; set; }
        public bool IsCarDisableIncomePaymentMethod1_Co3 { get; set; }
        public int CarIncomePaymentMethod1ID_Co3 { get; set; }
        public decimal TotalCarRentalIncome1_Co3 { get; set; }
        public bool IsVisibleTotalCarRentalIncome1_Co3 { get; set; }
        public bool IsDisableTotalCarRentalIncome1_Co3 { get; set; }
        #endregion

        #region Income2
        public string DetailsOfCarforRent2_Co3 { get; set; }
        public bool IsVisibleDetailsOfCarforRent2_Co3 { get; set; }
        public bool IsDisableDetailsOfCarforRent2_Co3 { get; set; }
        public string TypeOfCar2_Co3 { get; set; }
        public bool IsVisibleTypeOfCar2_Co3 { get; set; }
        public bool IsDisableTypeOfCar2_Co3 { get; set; }
        public string CarPlateNumber2_Co3 { get; set; }
        public bool IsVisibleCarPlateNumber2_Co3 { get; set; }
        public bool IsDisableCarPlateNumber2_Co3 { get; set; }
        public string CarOwnershipName2_Co3 { get; set; }
        public bool IsVisibleCarOwnershipName2_Co3 { get; set; }
        public bool IsDisableCarOwnershipName2_Co3 { get; set; }
        public string CarLesseeNameAddressContact2_Co3 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact2_Co3 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact2_Co3 { get; set; }
        public string RentalContractTenure2_Co3 { get; set; }
        public bool IsVisibleRentalContractTenure2_Co3 { get; set; }
        public bool IsDisableRentalContractTenure2_Co3 { get; set; }
        public string CarMonthlyRentalFee2_Co3 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee2_Co3 { get; set; }
        public bool IsCarDisableMonthlyRentalFee2_Co3 { get; set; }
        public string CarRepaymentCycle2_Co3 { get; set; }
        public bool IsCarVisibleRepaymentCycle2_Co3 { get; set; }
        public bool IsCarDisableRepaymentCycle2_Co3 { get; set; }
        public int CarRepaymentCycle2ID_Co3 { get; set; }
        public string CarIncomePaymentMethod2_Co3 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod2_Co3 { get; set; }
        public bool IsCarDisableIncomePaymentMethod2_Co3 { get; set; }
        public int CarIncomePaymentMethod2ID_Co3 { get; set; }
        public decimal TotalCarRentalIncome2_Co3 { get; set; }
        public bool IsVisibleTotalCarRentalIncome2_Co3 { get; set; }
        public bool IsDisableTotalCarRentalIncome2_Co3 { get; set; }
        #endregion

        #region Income3
        public string DetailsOfCarforRent3_Co3 { get; set; }
        public bool IsVisibleDetailsOfCarforRent3_Co3 { get; set; }
        public bool IsDisableDetailsOfCarforRent3_Co3 { get; set; }
        public string TypeOfCar3_Co3 { get; set; }
        public bool IsVisibleTypeOfCar3_Co3 { get; set; }
        public bool IsDisableTypeOfCar3_Co3 { get; set; }
        public string CarPlateNumber3_Co3 { get; set; }
        public bool IsVisibleCarPlateNumber3_Co3 { get; set; }
        public bool IsDisableCarPlateNumber3_Co3 { get; set; }
        public string CarOwnershipName3_Co3 { get; set; }
        public bool IsVisibleCarOwnershipName3_Co3 { get; set; }
        public bool IsDisableCarOwnershipName3_Co3 { get; set; }
        public string CarLesseeNameAddressContact3_Co3 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact3_Co3 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact3_Co3 { get; set; }
        public string RentalContractTenure3_Co3 { get; set; }
        public bool IsVisibleRentalContractTenure3_Co3 { get; set; }
        public bool IsDisableRentalContractTenure3_Co3 { get; set; }
        public string CarMonthlyRentalFee3_Co3 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee3_Co3 { get; set; }
        public bool IsCarDisableMonthlyRentalFee3_Co3 { get; set; }
        public string CarRepaymentCycle3_Co3 { get; set; }
        public bool IsCarVisibleRepaymentCycle3_Co3 { get; set; }
        public bool IsCarDisableRepaymentCycle3_Co3 { get; set; }
        public int CarRepaymentCycle3ID_Co3 { get; set; }
        public string CarIncomePaymentMethod3_Co3 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod3_Co3 { get; set; }
        public bool IsCarDisableIncomePaymentMethod3_Co3 { get; set; }
        public int CarIncomePaymentMethod3ID_Co3 { get; set; }
        public decimal TotalCarRentalIncome3_Co3 { get; set; }
        public bool IsVisibleTotalCarRentalIncome3_Co3 { get; set; }
        public bool IsDisableTotalCarRentalIncome3_Co3 { get; set; }
        #endregion

        #region Income4
        public string DetailsOfCarforRent4_Co3 { get; set; }
        public bool IsVisibleDetailsOfCarforRent4_Co3 { get; set; }
        public bool IsDisableDetailsOfCarforRent4_Co3 { get; set; }
        public string TypeOfCar4_Co3 { get; set; }
        public bool IsVisibleTypeOfCar4_Co3 { get; set; }
        public bool IsDisableTypeOfCar4_Co3 { get; set; }
        public string CarPlateNumber4_Co3 { get; set; }
        public bool IsVisibleCarPlateNumber4_Co3 { get; set; }
        public bool IsDisableCarPlateNumber4_Co3 { get; set; }
        public string CarOwnershipName4_Co3 { get; set; }
        public bool IsVisibleCarOwnershipName4_Co3 { get; set; }
        public bool IsDisableCarOwnershipName4_Co3 { get; set; }
        public string CarLesseeNameAddressContact4_Co3 { get; set; }
        public bool IsCarVisibleLesseeNameAddressContact4_Co3 { get; set; }
        public bool IsCarDisableLesseeNameAddressContact4_Co3 { get; set; }
        public string RentalContractTenure4_Co3 { get; set; }
        public bool IsVisibleRentalContractTenure4_Co3 { get; set; }
        public bool IsDisableRentalContractTenure4_Co3 { get; set; }
        public string CarMonthlyRentalFee4_Co3 { get; set; }
        public bool IsCarVisibleMonthlyRentalFee4_Co3 { get; set; }
        public bool IsCarDisableMonthlyRentalFee4_Co3 { get; set; }
        public string CarRepaymentCycle4_Co3 { get; set; }
        public bool IsCarVisibleRepaymentCycle4_Co3 { get; set; }
        public bool IsCarDisableRepaymentCycle4_Co3 { get; set; }
        public int CarRepaymentCycle4ID_Co3 { get; set; }
        public string CarIncomePaymentMethod4_Co3 { get; set; }
        public bool IsCarVisibleIncomePaymentMethod4_Co3 { get; set; }
        public bool IsCarDisableIncomePaymentMethod4_Co3 { get; set; }
        public int CarIncomePaymentMethod4ID_Co3 { get; set; }
        public decimal TotalCarRentalIncome4_Co3 { get; set; }
        public bool IsVisibleTotalCarRentalIncome4_Co3 { get; set; }
        public bool IsDisableTotalCarRentalIncome4_Co3 { get; set; }
        #endregion

        #endregion

        #endregion

        #region SelfEmployed

        #region Income1
        public string CompanyName1_Co3 { get; set; }
        public bool IsVisibleCompanyName1_Co3 { get; set; }
        public bool IsDisableCompanyName1_Co3 { get; set; }
        public string BusinessLicenceNumber1_Co3 { get; set; }
        public bool IsVisibleBusinessLicenceNumber1_Co3 { get; set; }
        public bool IsDisableBusinessLicenceNumber1_Co3 { get; set; }
        public string TaxCode1_Co3 { get; set; }
        public bool IsVisibleTaxCode1_Co3 { get; set; }
        public bool IsDisableTaxCode1_Co3 { get; set; }
        public string CompanyAddress1_Co3 { get; set; }
        public bool IsVisibleCompanyAddress1_Co3 { get; set; }
        public bool IsDisableCompanyAddress1_Co3 { get; set; }
        public string SelfWard1_Co3 { get; set; }
        public bool IsVisibleSelfWard1_Co3 { get; set; }
        public bool IsDisableSelfWard1_Co3 { get; set; }
        public string DisTrict1_Co3 { get; set; }
        public bool IsVisibleDisTrict1_Co3 { get; set; }
        public bool IsDisableDisTrict1_Co3 { get; set; }
        public int DisTrict1ID_Co3 { get; set; }
        public string SelfCity1_Co3 { get; set; }
        public bool IsVisibleSelfCity1_Co3 { get; set; }
        public bool IsDisableSelfCity1_Co3 { get; set; }
        public string SelfCity1ID_Co3 { get; set; }
        public string Ofcetel1_Co3 { get; set; }
        public bool IsVisibleOfcetel1_Co3 { get; set; }
        public bool IsDisableOfcetel1_Co3 { get; set; }
        public string MainCompanyIndustry11_Co3 { get; set; }
        public bool IsVisibleMainCompanyIndustry11_Co3 { get; set; }
        public bool IsDisableMainCompanyIndustry11_Co3 { get; set; }
        public int MainCompanyIndustry11ID_Co3 { get; set; }
        public string MainCompanyIndustry21_Co3 { get; set; }
        public bool IsVisibleMainCompanyIndustry21_Co3 { get; set; }
        public bool IsDisableMainCompanyIndustry21_Co3 { get; set; }
        public int MainCompanyIndustry21ID_Co3 { get; set; }
        public string OtherCompanyIndustryBizNature1_Co3 { get; set; }
        public bool IsVisibleOtherCompanyIndustryBizNature1_Co3 { get; set; }
        public bool IsDisableOtherCompanyIndustryBizNature1_Co3 { get; set; }
        public string SeasonalIndustry1_Co3 { get; set; }
        public bool IsVisibleSeasonalIndustry1_Co3 { get; set; }
        public bool IsDisableSeasonalIndustry1_Co3 { get; set; }
        public Nullable<DateTime> EstablishedYear1_Co3 { get; set; }
        public bool IsVisibleEstablishedYear1_Co3 { get; set; }
        public bool IsDisableEstablishedYear1_Co3 { get; set; }
        public int TotalYearsInOperation1_Co3 { get; set; }
        public bool IsVisibleTotalYearsInOperation1_Co3 { get; set; }
        public bool IsDisableTotalYearsInOperation1_Co3 { get; set; }
        public int ShareholdingInCompany1_Co3 { get; set; }
        public bool IsVisibleShareholdingInCompany1_Co3 { get; set; }
        public bool IsDisableShareholdingInCompany1_Co3 { get; set; }
        public string ProfLossinLatestYear1_Co3 { get; set; }
        public bool IsVisibleProfLossinLatestYear1_Co3 { get; set; }
        public bool IsDisableProfLossinLatestYear1_Co3 { get; set; }
        public int ProfLossinLatestYear1ID_Co3 { get; set; }
        public string TypeOfSelfEmploymentIncome1_Co3 { get; set; }
        public bool IsVisibleTypeOfSelfEmploymentIncome1_Co3 { get; set; }
        public bool IsDisableTypeOfSelfEmploymentIncome1_Co3 { get; set; }
        public int TypeOfSelfEmploymentIncome1ID_Co3 { get; set; }
        public int TotalTurnoverinFS1_Co3 { get; set; }
        public bool IsVisibleTotalTurnoverinFS1_Co3 { get; set; }
        public bool IsDisableTotalTurnoverinFS1_Co3 { get; set; }
        public decimal MonthlyTurnoverinyear1_Co3 { get; set; }
        public bool IsVisibleMonthlyTurnoverinyear1_Co3 { get; set; }
        public bool IsDisableMonthlyTurnoverinyear1_Co3 { get; set; }
        /// <summary>
        /// /////
        /// </summary>
        /// 
        public decimal TotalUpdatedTurnover1_Co3 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover1_Co3 { get; set; }
        public bool IsDisableTotalUpdatedTurnover1_Co3 { get; set; }
        public decimal AverageMonthlyUpdatedTurnover1_Co3 { get; set; }
        public bool IsVisibleAverageMonthlyUpdatedTurnover1_Co3 { get; set; }
        public bool IsDisableAverageMonthlyUpdatedTurnover1_Co3 { get; set; }
        public decimal ComparedWithTurnOver1_Co3 { get; set; }
        public bool IsVisibleComparedWithTurnOver1_Co3 { get; set; }
        public bool IsDisableComparedWithTurnOver1_Co3 { get; set; }
        public decimal RevisedAverageMonthlyTurnover1_Co3 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnover1_Co3 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnover1_Co3 { get; set; }
        public int SplitupIndustry11_Co3 { get; set; }
        public bool IsVisibleSplitupIndustry11_Co3 { get; set; }
        public bool IsDisableSplitupIndustry11_Co3 { get; set; }
        public int SplitupIndustry21_Co3 { get; set; }
        public bool IsVisibleSplitupIndustry21_Co3 { get; set; }
        public bool IsDisableSplitupIndustry21_Co3 { get; set; }
        public int SplitupIndustry31_Co3 { get; set; }
        public bool IsVisibleSplitupIndustry31_Co3 { get; set; }
        public bool IsDisableSplitupIndustry31_Co3 { get; set; }
        public int IndustrialMargin11_Co3 { get; set; }
        public bool IsVisibleIndustrialMargin11_Co3 { get; set; }
        public bool IsDisableIndustrialMargin11_Co3 { get; set; }
        public int IndustrialMargin21_Co3 { get; set; }
        public bool IsVisibleIndustrialMargin21_Co3 { get; set; }
        public bool IsDisableIndustrialMargin21_Co3 { get; set; }
        public int IndustrialMargin31_Co3 { get; set; }
        public bool IsVisibleIndustrialMargin31_Co3 { get; set; }
        public bool IsDisableIndustrialMargin31_Co3 { get; set; }
        public string Remark1_Co3 { get; set; }
        public bool IsVisibleRemark1_Co3 { get; set; }
        public bool IsDisableRemark1_Co3 { get; set; }
        public decimal MonthlySeflEmployedIncome1_Co3 { get; set; }
        public bool IsVisibleMonthlySeflEmployedIncome1_Co3 { get; set; }
        public bool IsDisableMonthlySeflEmployedIncome1_Co3 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncome1_Co3 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncome1_Co3 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncome1_Co3 { get; set; }
        public int TotalTurnoverinFSBank1_Co3 { get; set; }
        public bool IsVisibleTotalTurnoverinFSBank1_Co3 { get; set; }
        public bool IsDisableTotalTurnoverinFSBank1_Co3 { get; set; }
        public decimal MonthlyTurnoverInyearBank1_Co3 { get; set; }
        public bool IsVisibleMonthlyTurnoverInyearBank1_Co3 { get; set; }
        public bool IsDisableMonthlyTurnoverInyearBank1_Co3 { get; set; }
        public int OtherMonthlyTurnover1_Co3 { get; set; }
        public bool IsVisibleOtherMonthlyTurnover1_Co3 { get; set; }
        public bool IsDisableOtherMonthlyTurnover1_Co3 { get; set; }
        public decimal AverageEligibleCreditBalance1_Co3 { get; set; }
        public bool IsVisibleAverageEligibleCreditBalance1_Co3 { get; set; }
        public bool IsDisableAverageEligibleCreditBalance1_Co3 { get; set; }
        public decimal TotalEligibleMonthlyIncome1_Co3 { get; set; }
        public bool IsVisibleTotalEligibleMonthlyIncome1_Co3 { get; set; }
        public bool IsDisableTotalEligibleMonthlyIncome1_Co3 { get; set; }
        public decimal RevisedAverageMonthlyTurnoverBank1_Co3 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnoverBank1_Co3 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnoverBank1_Co3 { get; set; }
        public int SplitupIndustry1Bank1_Co3 { get; set; }
        public bool IsVisibleSplitupIndustry1Bank1_Co3 { get; set; }
        public bool IsDisableSplitupIndustry1Bank1_Co3 { get; set; }
        public int SplitupIndustry2Bank1_Co3 { get; set; }
        public bool IsVisibleSplitupIndustry2Bank1_Co3 { get; set; }
        public bool IsDisableSplitupIndustry2Bank1_Co3 { get; set; }
        public int SplitupIndustry3Bank1_Co3 { get; set; }
        public bool IsVisibleSplitupIndustry3Bank1_Co3 { get; set; }
        public bool IsDisableSplitupIndustry3Bank1_Co3 { get; set; }
        public int IndustrialMargin1Bank1_Co3 { get; set; }
        public bool IsVisibleIndustrialMargin1Bank1_Co3 { get; set; }
        public bool IsDisableIndustrialMargin1Bank1_Co3 { get; set; }
        public int IndustrialMargin2Bank1_Co3 { get; set; }
        public bool IsVisibleIndustrialMargin2Bank1_Co3 { get; set; }
        public bool IsDisableIndustrialMargin2Bank1_Co3 { get; set; }
        public int IndustrialMargin3Bank1_Co3 { get; set; }
        public bool IsVisibleIndustrialMargin3Bank1_Co3 { get; set; }
        public bool IsDisableIndustrialMargin3Bank1_Co3 { get; set; }
        public string RemarkBank1_Co3 { get; set; }
        public bool IsVisibleRemarkBank1_Co3 { get; set; }
        public bool IsDisableRemarkBank1_Co3 { get; set; }
        public decimal MonthlySelfEmployedIncome1_Co3 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncome1_Co3 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncome1_Co3 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeBank1_Co3 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeBank1_Co3 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeBank1_Co3 { get; set; }
        public int TotalTurnoverInFS1_Co3 { get; set; }
        public bool IsVisibleTotalTurnoverInFS1_Co3 { get; set; }
        public bool IsDisableTotalTurnoverInFS1_Co3 { get; set; }
        public int ProftafertaxinLatestYear1_Co3 { get; set; }
        public bool IsVisibleProftafertaxinLatestYear1_Co3 { get; set; }
        public bool IsDisableProftafertaxinLatestYear1_Co3 { get; set; }
        public int Depreciation1_Co3 { get; set; }
        public bool IsVisibleDepreciation1_Co3 { get; set; }
        public bool IsDisableDepreciation1_Co3 { get; set; }
        public decimal MonthlyTurnoverInYear1_Co3 { get; set; }
        public bool IsVisibleMonthlyTurnoverInYear1_Co3 { get; set; }
        public bool IsDisableMonthlyTurnoverInYear1_Co3 { get; set; }
        public decimal MonthlySelfEmployedIncomeCPP1_Co3 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncomeCPP1_Co3 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncomeCPP1_Co3 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeCPP1_Co3 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeCPP1_Co3 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeCPP1_Co3 { get; set; }

        #endregion

        #region Income2
        public string CompanyName2_Co3 { get; set; }
        public bool IsVisibleCompanyName2_Co3 { get; set; }
        public bool IsDisableCompanyName2_Co3 { get; set; }
        public string BusinessLicenceNumber2_Co3 { get; set; }
        public bool IsVisibleBusinessLicenceNumber2_Co3 { get; set; }
        public bool IsDisableBusinessLicenceNumber2_Co3 { get; set; }
        public string TaxCode2_Co3 { get; set; }
        public bool IsVisibleTaxCode2_Co3 { get; set; }
        public bool IsDisableTaxCode2_Co3 { get; set; }
        public string CompanyAddress2_Co3 { get; set; }
        public bool IsVisibleCompanyAddress2_Co3 { get; set; }
        public bool IsDisableCompanyAddress2_Co3 { get; set; }
        public string SelfWard2_Co3 { get; set; }
        public bool IsVisibleSelfWard2_Co3 { get; set; }
        public bool IsDisableSelfWard2_Co3 { get; set; }
        public string DisTrict2_Co3 { get; set; }
        public bool IsVisibleDisTrict2_Co3 { get; set; }
        public bool IsDisableDisTrict2_Co3 { get; set; }
        public int DisTrict2ID_Co3 { get; set; }
        public string SelfCity2_Co3 { get; set; }
        public bool IsVisibleSelfCity2_Co3 { get; set; }
        public bool IsDisableSelfCity2_Co3 { get; set; }
        public string SelfCity2ID_Co3 { get; set; }
        public string Ofcetel2_Co3 { get; set; }
        public bool IsVisibleOfcetel2_Co3 { get; set; }
        public bool IsDisableOfcetel2_Co3 { get; set; }
        public string MainCompanyIndustry12_Co3 { get; set; }
        public bool IsVisibleMainCompanyIndustry12_Co3 { get; set; }
        public bool IsDisableMainCompanyIndustry12_Co3 { get; set; }
        public int MainCompanyIndustry12ID_Co3 { get; set; }
        public string MainCompanyIndustry22_Co3 { get; set; }
        public bool IsVisibleMainCompanyIndustry22_Co3 { get; set; }
        public bool IsDisableMainCompanyIndustry22_Co3 { get; set; }
        public int MainCompanyIndustry22ID_Co3 { get; set; }
        public string OtherCompanyIndustryBizNature2_Co3 { get; set; }
        public bool IsVisibleOtherCompanyIndustryBizNature2_Co3 { get; set; }
        public bool IsDisableOtherCompanyIndustryBizNature2_Co3 { get; set; }
        public string SeasonalIndustry2_Co3 { get; set; }
        public bool IsVisibleSeasonalIndustry2_Co3 { get; set; }
        public bool IsDisableSeasonalIndustry2_Co3 { get; set; }
        public Nullable<DateTime> EstablishedYear2_Co3 { get; set; }
        public bool IsVisibleEstablishedYear2_Co3 { get; set; }
        public bool IsDisableEstablishedYear2_Co3 { get; set; }
        public int TotalYearsInOperation2_Co3 { get; set; }
        public bool IsVisibleTotalYearsInOperation2_Co3 { get; set; }
        public bool IsDisableTotalYearsInOperation2_Co3 { get; set; }
        public int ShareholdingInCompany2_Co3 { get; set; }
        public bool IsVisibleShareholdingInCompany2_Co3 { get; set; }
        public bool IsDisableShareholdingInCompany2_Co3 { get; set; }
        public string ProfLossinLatestYear2_Co3 { get; set; }
        public bool IsVisibleProfLossinLatestYear2_Co3 { get; set; }
        public bool IsDisableProfLossinLatestYear2_Co3 { get; set; }
        public int ProfLossinLatestYear2ID_Co3 { get; set; }
        public string TypeOfSelfEmploymentIncome2_Co3 { get; set; }
        public bool IsVisibleTypeOfSelfEmploymentIncome2_Co3 { get; set; }
        public bool IsDisableTypeOfSelfEmploymentIncome2_Co3 { get; set; }
        public int TypeOfSelfEmploymentIncome2ID_Co3 { get; set; }
        public int TotalTurnoverinFS2_Co3 { get; set; }
        public bool IsVisibleTotalTurnoverinFS2_Co3 { get; set; }
        public bool IsDisableTotalTurnoverinFS2_Co3 { get; set; }
        public decimal MonthlyTurnoverinyear2_Co3 { get; set; }
        public bool IsVisibleMonthlyTurnoverinyear2_Co3 { get; set; }
        public bool IsDisableMonthlyTurnoverinyear2_Co3 { get; set; }
        /// <summary>
        /// ////
        /// </summary>
        /// 
        public decimal TotalUpdatedTurnover2_Co3 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover2_Co3 { get; set; }
        public bool IsDisableTotalUpdatedTurnover2_Co3 { get; set; }
        public decimal AverageMonthlyUpdatedTurnover2_Co3 { get; set; }
        public bool IsVisibleAverageMonthlyUpdatedTurnover2_Co3 { get; set; }
        public bool IsDisableAverageMonthlyUpdatedTurnover2_Co3 { get; set; }
        public decimal ComparedWithTurnOverBank2_Co3 { get; set; }
        public bool IsVisibleComparedWithTurnOverbank2_Co3 { get; set; }
        public bool IsDisableComparedWithTurnOverBank2_Co3 { get; set; }
        public decimal RevisedAverageMonthlyTurnover2_Co3 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnover2_Co3 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnover2_Co3 { get; set; }
        public int SplitupIndustry12_Co3 { get; set; }
        public bool IsVisibleSplitupIndustry12_Co3 { get; set; }
        public bool IsDisableSplitupIndustry12_Co3 { get; set; }
        public int SplitupIndustry22_Co3 { get; set; }
        public bool IsVisibleSplitupIndustry22_Co3 { get; set; }
        public bool IsDisableSplitupIndustry22_Co3 { get; set; }
        public int SplitupIndustry32_Co3 { get; set; }
        public bool IsVisibleSplitupIndustry32_Co3 { get; set; }
        public bool IsDisableSplitupIndustry32_Co3 { get; set; }
        public int IndustrialMargin12_Co3 { get; set; }
        public bool IsVisibleIndustrialMargin12_Co3 { get; set; }
        public bool IsDisableIndustrialMargin12_Co3 { get; set; }
        public int IndustrialMargin22_Co3 { get; set; }
        public bool IsVisibleIndustrialMargin22_Co3 { get; set; }
        public bool IsDisableIndustrialMargin22_Co3 { get; set; }
        public int IndustrialMargin32_Co3 { get; set; }
        public bool IsVisibleIndustrialMargin32_Co3 { get; set; }
        public bool IsDisableIndustrialMargin32_Co3 { get; set; }
        public string Remark2_Co3 { get; set; }
        public bool IsVisibleRemark2_Co3 { get; set; }
        public bool IsDisableRemark2_Co3 { get; set; }
        public decimal MonthlySeflEmployedIncome2_Co3 { get; set; }
        public bool IsVisibleMonthlySeflEmployedIncome2_Co3 { get; set; }
        public bool IsDisableMonthlySeflEmployedIncome2_Co3 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncome2_Co3 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncome2_Co3 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncome2_Co3 { get; set; }
        public int TotalTurnoverinFSBank2_Co3 { get; set; }
        public bool IsVisibleTotalTurnoverinFSBank2_Co3 { get; set; }
        public bool IsDisableTotalTurnoverinFSBank2_Co3 { get; set; }
        public decimal MonthlyTurnoverInyearBank2_Co3 { get; set; }
        public bool IsVisibleMonthlyTurnoverInyearBank2_Co3 { get; set; }
        public bool IsDisableMonthlyTurnoverInyearBank2_Co3 { get; set; }
        public int OtherMonthlyTurnover2_Co3 { get; set; }
        public bool IsVisibleOtherMonthlyTurnover2_Co3 { get; set; }
        public bool IsDisableOtherMonthlyTurnover2_Co3 { get; set; }
        public decimal AverageEligibleCreditBalance2_Co3 { get; set; }
        public bool IsVisibleAverageEligibleCreditBalance2_Co3 { get; set; }
        public bool IsDisableAverageEligibleCreditBalance2_Co3 { get; set; }
        public decimal TotalEligibleMonthlyIncome2_Co3 { get; set; }
        public bool IsVisibleTotalEligibleMonthlyIncome2_Co3 { get; set; }
        public bool IsDisableTotalEligibleMonthlyIncome2_Co3 { get; set; }
        public decimal RevisedAverageMonthlyTurnoverBank2_Co3 { get; set; }
        public bool IsVisibleRevisedAverageMonthlyTurnoverBank2_Co3 { get; set; }
        public bool IsDisableRevisedAverageMonthlyTurnoverBank2_Co3 { get; set; }
        public int SplitupIndustry1Bank2_Co3 { get; set; }
        public bool IsVisibleSplitupIndustry1Bank2_Co3 { get; set; }
        public bool IsDisableSplitupIndustry1Bank2_Co3 { get; set; }
        public int SplitupIndustry2Bank2_Co3 { get; set; }
        public bool IsVisibleSplitupIndustry2Bank2_Co3 { get; set; }
        public bool IsDisableSplitupIndustry2Bank2_Co3 { get; set; }
        public int SplitupIndustry3Bank2_Co3 { get; set; }
        public bool IsVisibleSplitupIndustry3Bank2_Co3 { get; set; }
        public bool IsDisableSplitupIndustry3Bank2_Co3 { get; set; }
        public int IndustrialMargin1Bank2_Co3 { get; set; }
        public bool IsVisibleIndustrialMargin1Bank2_Co3 { get; set; }
        public bool IsDisableIndustrialMargin1Bank2_Co3 { get; set; }
        public int IndustrialMargin2Bank2_Co3 { get; set; }
        public bool IsVisibleIndustrialMargin2Bank2_Co3 { get; set; }
        public bool IsDisableIndustrialMargin2Bank2_Co3 { get; set; }
        public int IndustrialMargin3Bank2_Co3 { get; set; }
        public bool IsVisibleIndustrialMargin3Bank2_Co3 { get; set; }
        public bool IsDisableIndustrialMargin3Bank2_Co3 { get; set; }
        public string RemarkBank2_Co3 { get; set; }
        public bool IsVisibleRemarkBank2_Co3 { get; set; }
        public bool IsDisableRemarkBank2_Co3 { get; set; }
        public decimal MonthlySelfEmployedIncome2_Co3 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncome2_Co3 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncome2_Co3 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeBank2_Co3 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeBank2_Co3 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeBank2_Co3 { get; set; }
        public int TotalTurnoverInFS2_Co3 { get; set; }
        public bool IsVisibleTotalTurnoverInFS2_Co3 { get; set; }
        public bool IsDisableTotalTurnoverInFS2_Co3 { get; set; }
        public int ProftafertaxinLatestYear2_Co3 { get; set; }
        public bool IsVisibleProftafertaxinLatestYear2_Co3 { get; set; }
        public bool IsDisableProftafertaxinLatestYear2_Co3 { get; set; }
        public int Depreciation2_Co3 { get; set; }
        public bool IsVisibleDepreciation2_Co3 { get; set; }
        public bool IsDisableDepreciation2_Co3 { get; set; }
        public decimal MonthlyTurnoverInYear2_Co3 { get; set; }
        public bool IsVisibleMonthlyTurnoverInYear2_Co3 { get; set; }
        public bool IsDisableMonthlyTurnoverInYear2_Co3 { get; set; }
        public decimal MonthlySelfEmployedIncomeCPP2_Co3 { get; set; }
        public bool IsVisibleMonthlySelfEmployedIncomeCPP2_Co3 { get; set; }
        public bool IsDisableMonthlySelfEmployedIncomeCPP2_Co3 { get; set; }
        public decimal CustomerMonthlySelfEmployedIncomeCPP2_Co3 { get; set; }
        public bool IsVisibleCustomerMonthlySelfEmployedIncomeCPP2_Co3 { get; set; }
        public bool IsDisableCustomerMonthlySelfEmployedIncomeCPP2_Co3 { get; set; }
        #endregion

        #endregion

        #region Other

        #region Income1
        public int DiscountRate1_Co3 { get; set; }
        public bool IsVisibleDiscountRate1_Co3 { get; set; }
        public bool IsDisableDiscountRate1_Co3 { get; set; }
        public decimal TotalUpdatedTurnover1_other_Co3 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover1_other_Co3 { get; set; }
        public bool IsDisableTotalUpdatedTurnover1_other_Co3 { get; set; }

        #endregion

        #region Income2
        public int DiscountRate2_Co3 { get; set; }
        public bool IsVisibleDiscountRate2_Co3 { get; set; }
        public bool IsDisableDiscountRate2_Co3 { get; set; }
        public decimal TotalUpdatedTurnover2_other_Co3 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover2_other_Co3 { get; set; }
        public bool IsDisableTotalUpdatedTurnover2_other_Co3 { get; set; }
        #endregion

        #region Income3
        public int DiscountRate3_Co3 { get; set; }
        public bool IsVisibleDiscountRate3_Co3 { get; set; }
        public bool IsDisableDiscountRate3_Co3 { get; set; }
        public decimal TotalUpdatedTurnover3_other_Co3 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover3_other_Co3 { get; set; }
        public bool IsDisableTotalUpdatedTurnover3_other_Co3 { get; set; }
        #endregion

        #region Income4
        public int DiscountRate4_Co3 { get; set; }
        public bool IsVisibleDiscountRate4_Co3 { get; set; }
        public bool IsDisableDiscountRate4_Co3 { get; set; }
        public decimal TotalUpdatedTurnover4_other_Co3 { get; set; }
        public bool IsVisibleTotalUpdatedTurnover4_other_Co3 { get; set; }
        public bool IsDisableTotalUpdatedTurnover4_other_Co3 { get; set; }
        #endregion



        #endregion

        public float TotalIncome_Co3 { get; set; }
        public bool IsVisibleTotalIncome_Co3 { get; set; }
        public bool IsDisableTotalIncome_Co3 { get; set; }
        #endregion

        #region Summary
        public decimal TotalSalariedIncome { get; set; }
        public bool IsVisibleTotalSalariedIncome { get; set; }
        public bool IsDisableTotalSalariedIncome { get; set; }

        public decimal TotalRentalIncome { get; set; }
        public bool IsVisibleTotalRentalIncome { get; set; }
        public bool IsDisableTotalRentalIncome { get; set; }

        public decimal TotalCarRentalIncome { get; set; }
        public bool IsVisibleTotalCarRentalIncome { get; set; }
        public bool IsDisableTotalCarRentalIncome { get; set; }

        public decimal TotalSelfEmployedIncome { get; set; }
        public bool IsVisibleTotalSelfEmployedIncome { get; set; }
        public bool IsDisableTotalSelfEmployedIncome { get; set; }

        public bool IsActive { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        #endregion
    }
}
