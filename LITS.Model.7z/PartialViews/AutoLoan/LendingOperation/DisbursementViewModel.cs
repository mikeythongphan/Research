﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.LendingOperation
{
    public class DisbursementViewModel
    {
        public int ApplicationInformationID { get; set; }

        public int ALApplicationInformationID { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        public int? ChannelID { get; set; }
        public string Channel { get; set; }
        public bool IsVisibleChannel { get; set; }
        public bool IsDisableChannel { get; set; }

        public Nullable<System.DateTime> ExpectingDisbursedDate { get; set; }
        public bool IsVisibleExpectingDisbursedDate { get; set; }
        public bool IsDisableExpectingDisbursedDate { get; set; }

        public Nullable<System.DateTime> ReceivingDate { get; set; }
        public bool IsVisibleReceivingDate { get; set; }
        public bool IsDisableReceivingDate { get; set; }

        public int? CustomerSegmentID { get; set; }
        public string CustomerSegment { get; set; }
        public bool IsVisibleCustomerSegment { get; set; }
        public bool IsDisableCustomerSegment { get; set; }

        public string ARMCode { get; set; }
        public bool IsVisibleARMCode { get; set; }
        public bool IsDisableARMCode { get; set; }

        public int? ProgramCodeID { get; set; }
        public string ProgramCode { get; set; }
        public bool IsVisibleProgramCode { get; set; }
        public bool IsDisableProgramCode { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
