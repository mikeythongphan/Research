﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.LendingOperation
{
    public class InsuranceViewModel
    {
        public int ApplicationInformationID { get; set; }

        public int ALApplicationInformationID { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public int? InsuranceCompanyNameID { get; set; }
        public string InsuranceCompanyName { get; set; }
        public bool IsVisibleInsuranceCompanyName { get; set; }
        public bool IsDisableInsuranceCompanyName { get; set; }

        public decimal? InsuranceAmount { get; set; }
        public bool IsVisibleInsuranceAmount { get; set; }
        public bool IsDisableInsuranceAmount { get; set; }

        public Nullable<System.DateTime> InsuranceExpiryDate { get; set; }
        public bool IsVisibleInsuranceExpiryDate { get; set; }
        public bool IsDisableInsuranceExpiryDate { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
