﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.LendingOperation
{
    public class InsuranceViewModel
    {
        public bool IsActive { get; set; }
        public string InsuranceCompanyName { get; set; }
        public bool IsVisibleInsuranceCompanyName { get; set; }
        public bool IsDisableInsuranceCompanyName { get; set; }
        public string InsuranceAmount { get; set; }
        public bool IsVisibleInsuranceAmount { get; set; }
        public bool IsDisableInsuranceAmount { get; set; }
        public Nullable<System.DateTime> InsuranceExpiryDate { get; set; }
        public bool IsVisibleInsuranceExpiryDate { get; set; }
        public bool IsDisableInsuranceExpiryDate { get; set; }
    }
}
