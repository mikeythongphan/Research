﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.Main;

namespace LITS.Model.PartialViews.AutoLoan.LendingOperation
{
    public class PersonalDetailViewModel
    {
        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        #region Main
        private PersonalInformationViewModel _objPersonalInformationViewModel_Main = new PersonalInformationViewModel();
        public PersonalInformationViewModel _PersonalInformationViewModel_Main
        {
            get
            {
                return _objPersonalInformationViewModel_Main;
            }
            set { _objPersonalInformationViewModel_Main = value; }
        }

        #endregion

        #region Co1
        private PersonalInformationViewModel _objPersonalInformationViewModel_Co1 = new PersonalInformationViewModel();
        public PersonalInformationViewModel _PersonalInformationViewModel_Co1
        {
            get
            {
                return _objPersonalInformationViewModel_Co1;
            }
            set { _objPersonalInformationViewModel_Co1 = value; }
        }
        #endregion

        #region Co2
        private PersonalInformationViewModel _objPersonalInformationViewModel_Co2 = new PersonalInformationViewModel();
        public PersonalInformationViewModel _PersonalInformationViewModel_Co2
        {
            get
            {
                return _objPersonalInformationViewModel_Co2;
            }
            set { _objPersonalInformationViewModel_Co2 = value; }
        }
        #endregion

        #region Co3
        private PersonalInformationViewModel _objPersonalInformationViewModel_Co3 = new PersonalInformationViewModel();
        public PersonalInformationViewModel _PersonalInformationViewModel_Co3
        {
            get
            {
                return _objPersonalInformationViewModel_Co3;
            }
            set { _objPersonalInformationViewModel_Co3 = value; }
        }
        #endregion

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }

    public class PersonalInformationViewModel
    {
        public int? InititalID { get; set; }
        public string Initital { get; set; }
        public bool IsVisibleInitital { get; set; }
        public bool IsDisableInitital { get; set; }

        public int? GenderID { get; set; }
        public string Gender { get; set; }
        public bool IsVisibleGender { get; set; }
        public bool IsDisableGender { get; set; }

        public string FullName { get; set; }
        public bool IsVisibleFullName { get; set; }
        public bool IsDisableFullName { get; set; }

        public Nullable<System.DateTime> DOB { get; set; }
        public bool IsVisibleDOB { get; set; }
        public bool IsDisableDOB { get; set; }

        public int NationlityID { get; set; }
        public string Nationlity { get; set; }
        public bool IsVisibleNationlity { get; set; }
        public bool IsDisableNationlity { get; set; }        

        public string CurrentHomeAddress { get; set; }
        public bool IsVisibleCurrentHomeAddress { get; set; }
        public bool IsDisableCurrentHomeAddress { get; set; }

        public string Ward { get; set; }
        public bool IsVisibleWard { get; set; }
        public bool IsDisableWard { get; set; }

        public int? DistrictID { get; set; }
        public string District { get; set; }
        public bool IsVisibleDistrict { get; set; }
        public bool IsDisableDistrict { get; set; }

        public int? CityID { get; set; }
        public string City { get; set; }
        public bool IsVisibleCity { get; set; }
        public bool IsDisableCity { get; set; }

        public string MobileNo { get; set; }
        public bool IsVisibleMobileNo { get; set; }
        public bool IsDisableMobileNo { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }

        private List<CustomerIdentificationViewModel> _objCustomerIdentificationViewModel = new List<CustomerIdentificationViewModel>();
        public List<CustomerIdentificationViewModel> _CustomerIdentificationViewModel
        {
            get
            {
                return _objCustomerIdentificationViewModel;
            }
            set { _objCustomerIdentificationViewModel = value; }
        }
    }
}
