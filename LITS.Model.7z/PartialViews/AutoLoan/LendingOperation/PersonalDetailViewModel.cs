﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.LendingOperation
{
    public class PersonalDetailViewModel
    {
        #region Main
        public bool IsActive_Main { get; set; }
        public string Initital_Main { get; set; }
        public bool IsVisibleInitital_Main { get; set; }
        public bool IsDisableInitital_Main { get; set; }
        public string Gender_Main { get; set; }
        public bool IsVisibleGender_Main { get; set; }
        public bool IsDisableGender_Main { get; set; }
        public string FullName_Main { get; set; }
        public bool IsVisibleFullName_Main { get; set; }
        public bool IsDisableFullName_Main { get; set; }
        public Nullable<System.DateTime> DOB_Main { get; set; }
        public bool IsVisibleDOB_Main { get; set; }
        public bool IsDisableDOB_Main { get; set; }
        public string Nationlity_Main { get; set; }
        public bool IsVisibleNationlity_Main { get; set; }
        public bool IsDisableNationlity_Main { get; set; }
        public string IDNumber_Main { get; set; }
        public bool IsVisibleIDNumber_Main { get; set; }
        public bool IsDisableIDNumber_Main { get; set; }
        public string CurrentHomeAddress_Main { get; set; }
        public bool IsVisibleCurrentHomeAddress_Main { get; set; }
        public bool IsDisableCurrentHomeAddress_Main { get; set; }
        public string Ward_Main { get; set; }
        public bool IsVisibleWard_Main { get; set; }
        public bool IsDisableWard_Main { get; set; }
        public string District_Main { get; set; }
        public bool IsVisibleDistrict_Main { get; set; }
        public bool IsDisableDistrict_Main { get; set; }
        public string City_Main { get; set; }
        public bool IsVisibleCity_Main { get; set; }
        public bool IsDisableCity_Main { get; set; }
        public string MobileNo_Main { get; set; }
        public bool IsVisibleMobileNo_Main { get; set; }
        public bool IsDisableMobileNo_Main { get; set; }
        #endregion

        #region Co1
        public bool IsActive_Co1 { get; set; }
        public string Initital_Co1 { get; set; }
        public bool IsVisibleInitital_Co1 { get; set; }
        public bool IsDisableInitital_Co1 { get; set; }
        public string Gender_Co1 { get; set; }
        public bool IsVisibleGender_Co1 { get; set; }
        public bool IsDisableGender_Co1 { get; set; }
        public string FullName_Co1 { get; set; }
        public bool IsVisibleFullName_Co1 { get; set; }
        public bool IsDisableFullName_Co1 { get; set; }
        public Nullable<System.DateTime> DOB_Co1 { get; set; }
        public bool IsVisibleDOB_Co1 { get; set; }
        public bool IsDisableDOB_Co1 { get; set; }
        public string Nationlity_Co1 { get; set; }
        public bool IsVisibleNationlity_Co1 { get; set; }
        public bool IsDisableNationlity_Co1 { get; set; }
        public string IDNumber_Co1 { get; set; }
        public bool IsVisibleIDNumber_Co1 { get; set; }
        public bool IsDisableIDNumber_Co1 { get; set; }
        public string CurrentHomeAddress_Co1 { get; set; }
        public bool IsVisibleCurrentHomeAddress_Co1 { get; set; }
        public bool IsDisableCurrentHomeAddress_Co1 { get; set; }
        public string Ward_Co1 { get; set; }
        public bool IsVisibleWard_Co1 { get; set; }
        public bool IsDisableWard_Co1 { get; set; }
        public string District_Co1 { get; set; }
        public bool IsVisibleDistrict_Co1 { get; set; }
        public bool IsDisableDistrict_Co1 { get; set; }
        public string City_Co1 { get; set; }
        public bool IsVisibleCity_Co1 { get; set; }
        public bool IsDisableCity_Co1 { get; set; }
        public string MobileNo_Co1 { get; set; }
        public bool IsVisibleMobileNo_Co1 { get; set; }
        public bool IsDisableMobileNo_Co1 { get; set; }
        #endregion

        #region Co2
        public bool IsActive_Co2 { get; set; }
        public string Initital_Co2 { get; set; }
        public bool IsVisibleInitital_Co2 { get; set; }
        public bool IsDisableInitital_Co2 { get; set; }
        public string Gender_Co2 { get; set; }
        public bool IsVisibleGender_Co2 { get; set; }
        public bool IsDisableGender_Co2 { get; set; }
        public string FullName_Co2 { get; set; }
        public bool IsVisibleFullName_Co2 { get; set; }
        public bool IsDisableFullName_Co2 { get; set; }
        public Nullable<System.DateTime> DOB_Co2 { get; set; }
        public bool IsVisibleDOB_Co2 { get; set; }
        public bool IsDisableDOB_Co2 { get; set; }
        public string Nationlity_Co2 { get; set; }
        public bool IsVisibleNationlity_Co2 { get; set; }
        public bool IsDisableNationlity_Co2 { get; set; }
        public string IDNumber_Co2 { get; set; }
        public bool IsVisibleIDNumber_Co2 { get; set; }
        public bool IsDisableIDNumber_Co2 { get; set; }
        public string CurrentHomeAddress_Co2 { get; set; }
        public bool IsVisibleCurrentHomeAddress_Co2 { get; set; }
        public bool IsDisableCurrentHomeAddress_Co2 { get; set; }
        public string Ward_Co2 { get; set; }
        public bool IsVisibleWard_Co2 { get; set; }
        public bool IsDisableWard_Co2 { get; set; }
        public string District_Co2 { get; set; }
        public bool IsVisibleDistrict_Co2 { get; set; }
        public bool IsDisableDistrict_Co2 { get; set; }
        public string City_Co2 { get; set; }
        public bool IsVisibleCity_Co2 { get; set; }
        public bool IsDisableCity_Co2 { get; set; }
        public string MobileNo_Co2 { get; set; }
        public bool IsVisibleMobileNo_Co2 { get; set; }
        public bool IsDisableMobileNo_Co2 { get; set; }
        #endregion

        #region Main
        public bool IsActive_Co3 { get; set; }
        public string Initital_Co3 { get; set; }
        public bool IsVisibleInitital_Co3 { get; set; }
        public bool IsDisableInitital_Co3 { get; set; }
        public string Gender_Co3 { get; set; }
        public bool IsVisibleGender_Co3 { get; set; }
        public bool IsDisableGender_Co3 { get; set; }
        public string FullName_Co3 { get; set; }
        public bool IsVisibleFullName_Co3 { get; set; }
        public bool IsDisableFullName_Co3 { get; set; }
        public Nullable<System.DateTime> DOB_Co3 { get; set; }
        public bool IsVisibleDOB_Co3 { get; set; }
        public bool IsDisableDOB_Co3 { get; set; }
        public string Nationlity_Co3 { get; set; }
        public bool IsVisibleNationlity_Co3 { get; set; }
        public bool IsDisableNationlity_Co3 { get; set; }
        public string IDNumber_Co3 { get; set; }
        public bool IsVisibleIDNumber_Co3 { get; set; }
        public bool IsDisableIDNumber_Co3 { get; set; }
        public string CurrentHomeAddress_Co3 { get; set; }
        public bool IsVisibleCurrentHomeAddress_Co3 { get; set; }
        public bool IsDisableCurrentHomeAddress_Co3 { get; set; }
        public string Ward_Co3 { get; set; }
        public bool IsVisibleWard_Co3 { get; set; }
        public bool IsDisableWard_Co3 { get; set; }
        public string District_Co3 { get; set; }
        public bool IsVisibleDistrict_Co3 { get; set; }
        public bool IsDisableDistrict_Co3 { get; set; }
        public string City_Co3 { get; set; }
        public bool IsVisibleCity_Co3 { get; set; }
        public bool IsDisableCity_Co3 { get; set; }
        public string MobileNo_Co3 { get; set; }
        public bool IsVisibleMobileNo_Co3 { get; set; }
        public bool IsDisableMobileNo_Co3 { get; set; }
        #endregion

        public bool IsActive { get; set; }
    }
}
