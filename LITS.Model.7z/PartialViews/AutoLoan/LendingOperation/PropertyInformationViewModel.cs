﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.LendingOperation
{
    public class PropertyInformationViewModel
    {
        public bool IsActive { get; set; }

        public string PlateFormNumber { get; set; }
        public bool IsVisiblePlateFormNumber { get; set; }
        public bool IsDisablePlateFormNumber { get; set; }

        public string EngineNumber { get; set; }
        public bool IsVisibleEngineNumber { get; set; }
        public bool IsDisableEngineNumber { get; set; }

        public string ChassisNumber { get; set; }
        public bool IsVisibleChassisNumber { get; set; }
        public bool IsDisableChassisNumber { get; set; }

    }
}
