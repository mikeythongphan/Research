﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.OperationSupport
{
    public class CarDealerInformationViewModel
    {
        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }

        public string CarDealerName { get; set; }
        public bool IsVisibleCarDealerName { get; set; }
        public bool IsDisableCarDealerName { get; set; }
        public int? CarDealerNameID { get; set; }

        public string Address { get; set; }
        public bool IsVisibleAddress { get; set; }
        public bool IsDisableAddress { get; set; }

        public string Wards { get; set; }
        public bool IsVisibleWards { get; set; }
        public bool IsDisableWards { get; set; }

        public string District { get; set; }
        public bool IsVisibleDistrict { get; set; }
        public bool IsDisableDistrict { get; set; }
        public int? DistrictID { get; set; }

        public string City { get; set; }
        public bool IsVisibleCity { get; set; }
        public bool IsDisableCity { get; set; }
        public int? CityID { get; set; }

        public string CooperationContractActive { get; set; }
        public bool IsVisibleCooperationContractActive { get; set; }
        public bool IsDisableCooperationContractActive { get; set; }
        public int? CooperationContractActiveID { get; set; }

        public decimal? CarDealerPromissoryDisbursementCap { get; set; }
        public bool IsVisibleCarDealerPromissoryDisbursementCap { get; set; }
        public bool IsDisableCarDealerPromissoryDisbursementCap { get; set; }

        public decimal? CarDealerPromissoryDisbursementAvailableLimit { get; set; }
        public bool IsVisibleCarDealerPromissoryDisbursementAvailableLimit { get; set; }
        public bool IsDisableCarDealerPromissoryDisbursementAvailableLimit { get; set; }

        public decimal? CarDealerTotalDisbursement { get; set; }
        public bool IsVisibleCarDealerTotalDisbursement { get; set; }
        public bool IsDisableCarDealerTotalDisbursement { get; set; }

        public decimal? CarDealerILCap { get; set; }
        public bool IsVisibleCarDealerILCap { get; set; }
        public bool IsDisableCarDealerILCap { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
