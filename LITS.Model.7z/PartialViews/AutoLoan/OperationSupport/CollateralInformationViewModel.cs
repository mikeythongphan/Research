﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.OperationSupport
{
    public class CollateralInformationViewModel
    {
        public string CarMarkerBrand { get; set; }
        public bool IsVisibleCarMarkerBrand { get; set; }
        public bool IsDisableCarMarkerBrand { get; set; }
        public int CarMarkerBrandID { get; set; }

        public string PropertyStatus { get; set; }
        public bool IsVisiblePropertyStatus { get; set; }
        public bool IsDisablePropertyStatus { get; set; }
        public int PropertyStatusID { get; set; }

        public string Model { get; set; }
        public bool IsVisibleModel { get; set; }
        public bool IsDisableModel { get; set; }
        public int ModelID { get; set; }

        public string CarType { get; set; }
        public bool IsVisibleCarType { get; set; }
        public bool IsDisableCarType { get; set; }
        public int CarTypeID { get; set; }

        public string CarSource { get; set; }
        public bool IsVisibleCarSource { get; set; }
        public bool IsDisableCarSource { get; set; }
        public int CarSourceID { get; set; }

        public Nullable<System.DateTime> YearOfManufacture { get; set; }
        public bool IsVisibleYearOfManufacture { get; set; }
        public bool IsDisableYearOfManufacture { get; set; }

        public string Color { get; set; }
        public bool IsVisibleColor { get; set; }
        public bool IsDisableColor { get; set; }

        public string NumberOfSeats { get; set; }
        public bool IsVisibleNumberOfSeats { get; set; }
        public bool IsDisableNumberOfSeats { get; set; }

        public string ChassisNumber { get; set; }
        public bool IsVisibleChassisNumber { get; set; }
        public bool IsDisableChassisNumber { get; set; }

        public int PurchasingPriceOrFairMarketValue { get; set; }
        public bool IsVisiblePurchasingPriceOrFairMarketValue { get; set; }
        public bool IsDisablePurchasingPriceOrFairMarketValue { get; set; }

        public string PurchasingSPContractNumber { get; set; }
        public bool IsVisiblePurchasingSPContractNumber { get; set; }
        public bool IsDisablePurchasingSPContractNumber { get; set; }

        public string CollateralValue { get; set; }
        public bool IsVisibleCollateralValue { get; set; }
        public bool IsDisableCollateralValue { get; set; }
        public bool IsActive { get; set; }

    }
}
