﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.OperationSupport
{
    public class CustomerCreditBureauViewModel
    {
        #region Main
        public int BureauDataLoanCurrent { get; set; }
        public bool IsVisibleBureauDataLoanCurrent { get; set; }
        public bool IsDisableBureauDataLoanCurrent { get; set; }

        public int BureauDataLoanHistory { get; set; }
        public bool IsVisibleBureauDataLoanHistory { get; set; }
        public bool IsDisableBureauDataLoanHistory { get; set; }

        public int BureauDataCardCurrent { get; set; }
        public bool IsVisibleBureauDataCardCurrent { get; set; }
        public bool IsDisableBureauDataCardCurrent { get; set; }

        public int BureauDataCardHistory{ get; set; }
        public bool IsVisibleBureauDataCardHistory { get; set; }
        public bool IsDisableBureauDataCardHistory { get; set; }

        public string CreditBureauType { get; set; }
        public bool IsVisibleCreditBureauType { get; set; }
        public bool IsDisableCreditBureauType { get; set; }
        public int CreditBureauTypeID { get; set; }

        public decimal CurrentUnsecuredOutstandingOnUs { get; set; }
        public bool IsVisibleCurrentUnsecuredOutstandingOnUs { get; set; }
        public bool IsDisableCurrentUnsecuredOutstandingOnUs { get; set; }

        public decimal CurrentUnsecuredOutstandingOfUs { get; set; }
        public bool IsVisibleCurrentUnsecuredOutstandingOfUs { get; set; }
        public bool IsDisableCurrentUnsecuredOutstandingOfUs { get; set; }

        public decimal CurrentTotalEMIOnUs { get; set; }
        public bool IsVisibleCurrentTotalEMIOnUs { get; set; }
        public bool IsDisableCurrentTotalEMIOnUs { get; set; }

        public decimal CurrentTotalEMIOfUs { get; set; }
        public bool IsVisibleCurrentTotalEMIOfUs { get; set; }
        public bool IsDisableCurrentTotalEMIOfUs { get; set; }

        public decimal CurrentUnsecureLimitOnUs { get; set; }
        public bool IsVisibleCurrentUnsecureLimitOnUs { get; set; }
        public bool IsDisableCurrentUnsecureLimitOnUs { get; set; }

        public decimal TotalOutStandingBalanceCreditCard { get; set; }
        public bool IsVisibleTotalOutStandingBalanceCreditCard { get; set; }
        public bool IsDisableTotalOutStandingBalanceCreditCard { get; set; }

        public decimal TotalLimitCreditCard { get; set; }
        public bool IsVisibleTotalLimitCreditCard { get; set; }
        public bool IsDisableTotalLimitCreditCard { get; set; }

        public decimal CurrentCardUtilization { get; set; }
        public bool IsVisibleCurrentCardUtilization { get; set; }
        public bool IsDisableCurrentCardUtilization { get; set; }

        public decimal TotalBorrowerCurrentMonthlyIndividualObligationRepayment { get; set; }
        public bool IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment { get; set; }
        public bool IsDisableTotalBorrowerCurrentMonthlyIndividualObligationRepayment { get; set; }

        #endregion
        #region Co1
        public int BureauDataLoanCurrent_Co1 { get; set; }
        public bool IsVisibleBureauDataLoanCurrent_Co1 { get; set; }
        public bool IsDisableBureauDataLoanCurrent_Co1 { get; set; }

        public int BureauDataLoanHistory_Co1 { get; set; }
        public bool IsVisibleBureauDataLoanHistory_Co1 { get; set; }
        public bool IsDisableBureauDataLoanHistory_Co1 { get; set; }

        public int BureauDataCardCurrent_Co1 { get; set; }
        public bool IsVisibleBureauDataCardCurrent_Co1 { get; set; }
        public bool IsDisableBureauDataCardCurrent_Co1 { get; set; }

        public int BureauDataCardHistory_Co1 { get; set; }
        public bool IsVisibleBureauDataCardHistory_Co1 { get; set; }
        public bool IsDisableBureauDataCardHistory_Co1 { get; set; }

        public string CreditBureauType_Co1 { get; set; }
        public bool IsVisibleCreditBureauType_Co1 { get; set; }
        public bool IsDisableCreditBureauType_Co1 { get; set; }
        public int CreditBureauTypeID_Co1 { get; set; }

        public decimal CurrentUnsecuredOutstandingOnUs_Co1 { get; set; }
        public bool IsVisibleCurrentUnsecuredOutstandingOnUs_Co1 { get; set; }
        public bool IsDisableCurrentUnsecuredOutstandingOnUs_Co1 { get; set; }

        public decimal CurrentUnsecuredOutstandingOfUs_Co1 { get; set; }
        public bool IsVisibleCurrentUnsecuredOutstandingOfUs_Co1 { get; set; }
        public bool IsDisableCurrentUnsecuredOutstandingOfUs_Co1 { get; set; }

        public decimal CurrentTotalEMIOnUs_Co1 { get; set; }
        public bool IsVisibleCurrentTotalEMIOnUs_Co1 { get; set; }
        public bool IsDisableCurrentTotalEMIOnUs_Co1 { get; set; }

        public decimal CurrentTotalEMIOfUs_Co1 { get; set; }
        public bool IsVisibleCurrentTotalEMIOfUs_Co1 { get; set; }
        public bool IsDisableCurrentTotalEMIOfUs_Co1 { get; set; }

        public decimal CurrentUnsecureLimitOnUs_Co1 { get; set; }
        public bool IsVisibleCurrentUnsecureLimitOnUs_Co1 { get; set; }
        public bool IsDisableCurrentUnsecureLimitOnUs_Co1 { get; set; }

        public decimal TotalOutStandingBalanceCreditCard_Co1 { get; set; }
        public bool IsVisibleTotalOutStandingBalanceCreditCard_Co1 { get; set; }
        public bool IsDisableTotalOutStandingBalanceCreditCard_Co1 { get; set; }

        public decimal TotalLimitCreditCard_Co1 { get; set; }
        public bool IsVisibleTotalLimitCreditCard_Co1 { get; set; }
        public bool IsDisableTotalLimitCreditCard_Co1 { get; set; }

        public decimal CurrentCardUtilization_Co1 { get; set; }
        public bool IsVisibleCurrentCardUtilization_Co1 { get; set; }
        public bool IsDisableCurrentCardUtilization_Co1 { get; set; }

        public decimal TotalBorrowerCurrentMonthlyIndividualObligationRepayment_Co1 { get; set; }
        public bool IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment_Co1 { get; set; }
        public bool IsDisableTotalBorrowerCurrentMonthlyIndividualObligationRepayment_Co1 { get; set; }

        public bool IsActive_Co1 { get; set; }

        #endregion
        #region Co2
        public int BureauDataLoanCurrent_Co2 { get; set; }
        public bool IsVisibleBureauDataLoanCurrent_Co2 { get; set; }
        public bool IsDisableBureauDataLoanCurrent_Co2 { get; set; }

        public int BureauDataLoanHistory_Co2 { get; set; }
        public bool IsVisibleBureauDataLoanHistory_Co2 { get; set; }
        public bool IsDisableBureauDataLoanHistory_Co2 { get; set; }

        public int BureauDataCardCurrent_Co2 { get; set; }
        public bool IsVisibleBureauDataCardCurrent_Co2 { get; set; }
        public bool IsDisableBureauDataCardCurrent_Co2 { get; set; }

        public int BureauDataCardHistory_Co2 { get; set; }
        public bool IsVisibleBureauDataCardHistory_Co2 { get; set; }
        public bool IsDisableBureauDataCardHistory_Co2 { get; set; }

        public string CreditBureauType_Co2 { get; set; }
        public bool IsVisibleCreditBureauType_Co2 { get; set; }
        public bool IsDisableCreditBureauType_Co2 { get; set; }
        public int CreditBureauTypeID_Co2 { get; set; }

        public decimal CurrentUnsecuredOutstandingOnUs_Co2 { get; set; }
        public bool IsVisibleCurrentUnsecuredOutstandingOnUs_Co2 { get; set; }
        public bool IsDisableCurrentUnsecuredOutstandingOnUs_Co2 { get; set; }

        public decimal CurrentUnsecuredOutstandingOfUs_Co2 { get; set; }
        public bool IsVisibleCurrentUnsecuredOutstandingOfUs_Co2 { get; set; }
        public bool IsDisableCurrentUnsecuredOutstandingOfUs_Co2 { get; set; }

        public decimal CurrentTotalEMIOnUs_Co2 { get; set; }
        public bool IsVisibleCurrentTotalEMIOnUs_Co2 { get; set; }
        public bool IsDisableCurrentTotalEMIOnUs_Co2 { get; set; }

        public decimal CurrentTotalEMIOfUs_Co2 { get; set; }
        public bool IsVisibleCurrentTotalEMIOfUs_Co2 { get; set; }
        public bool IsDisableCurrentTotalEMIOfUs_Co2 { get; set; }

        public decimal CurrentUnsecureLimitOnUs_Co2 { get; set; }
        public bool IsVisibleCurrentUnsecureLimitOnUs_Co2 { get; set; }
        public bool IsDisableCurrentUnsecureLimitOnUs_Co2 { get; set; }

        public decimal TotalOutStandingBalanceCreditCard_Co2 { get; set; }
        public bool IsVisibleTotalOutStandingBalanceCreditCard_Co2 { get; set; }
        public bool IsDisableTotalOutStandingBalanceCreditCard_Co2 { get; set; }

        public decimal TotalLimitCreditCard_Co2 { get; set; }
        public bool IsVisibleTotalLimitCreditCard_Co2 { get; set; }
        public bool IsDisableTotalLimitCreditCard_Co2 { get; set; }

        public decimal CurrentCardUtilization_Co2 { get; set; }
        public bool IsVisibleCurrentCardUtilization_Co2 { get; set; }
        public bool IsDisableCurrentCardUtilization_Co2 { get; set; }

        public decimal TotalBorrowerCurrentMonthlyIndividualObligationRepayment_Co2 { get; set; }
        public bool IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment_Co2 { get; set; }
        public bool IsDisableTotalBorrowerCurrentMonthlyIndividualObligationRepayment_Co2 { get; set; }

        public bool IsActive_Co2 { get; set; }

        #endregion
        #region Co3
        public int BureauDataLoanCurrent_Co3 { get; set; }
        public bool IsVisibleBureauDataLoanCurrent_Co3 { get; set; }
        public bool IsDisableBureauDataLoanCurrent_Co3 { get; set; }

        public int BureauDataLoanHistory_Co3 { get; set; }
        public bool IsVisibleBureauDataLoanHistory_Co3 { get; set; }
        public bool IsDisableBureauDataLoanHistory_Co3 { get; set; }

        public int BureauDataCardCurrent_Co3 { get; set; }
        public bool IsVisibleBureauDataCardCurrent_Co3 { get; set; }
        public bool IsDisableBureauDataCardCurrent_Co3 { get; set; }

        public int BureauDataCardHistory_Co3 { get; set; }
        public bool IsVisibleBureauDataCardHistory_Co3 { get; set; }
        public bool IsDisableBureauDataCardHistory_Co3 { get; set; }

        public string CreditBureauType_Co3 { get; set; }
        public bool IsVisibleCreditBureauType_Co3 { get; set; }
        public bool IsDisableCreditBureauType_Co3 { get; set; }
        public int CreditBureauTypeID_Co3 { get; set; }

        public decimal CurrentUnsecuredOutstandingOnUs_Co3 { get; set; }
        public bool IsVisibleCurrentUnsecuredOutstandingOnUs_Co3 { get; set; }
        public bool IsDisableCurrentUnsecuredOutstandingOnUs_Co3 { get; set; }

        public decimal CurrentUnsecuredOutstandingOfUs_Co3 { get; set; }
        public bool IsVisibleCurrentUnsecuredOutstandingOfUs_Co3 { get; set; }
        public bool IsDisableCurrentUnsecuredOutstandingOfUs_Co3 { get; set; }

        public decimal CurrentTotalEMIOnUs_Co3 { get; set; }
        public bool IsVisibleCurrentTotalEMIOnUs_Co3 { get; set; }
        public bool IsDisableCurrentTotalEMIOnUs_Co3 { get; set; }

        public decimal CurrentTotalEMIOfUs_Co3 { get; set; }
        public bool IsVisibleCurrentTotalEMIOfUs_Co3 { get; set; }
        public bool IsDisableCurrentTotalEMIOfUs_Co3 { get; set; }

        public decimal CurrentUnsecureLimitOnUs_Co3 { get; set; }
        public bool IsVisibleCurrentUnsecureLimitOnUs_Co3 { get; set; }
        public bool IsDisableCurrentUnsecureLimitOnUs_Co3 { get; set; }

        public decimal TotalOutStandingBalanceCreditCard_Co3 { get; set; }
        public bool IsVisibleTotalOutStandingBalanceCreditCard_Co3 { get; set; }
        public bool IsDisableTotalOutStandingBalanceCreditCard_Co3 { get; set; }

        public decimal TotalLimitCreditCard_Co3 { get; set; }
        public bool IsVisibleTotalLimitCreditCard_Co3 { get; set; }
        public bool IsDisableTotalLimitCreditCard_Co3 { get; set; }

        public decimal CurrentCardUtilization_Co3 { get; set; }
        public bool IsVisibleCurrentCardUtilization_Co3 { get; set; }
        public bool IsDisableCurrentCardUtilization_Co3 { get; set; }

        public decimal TotalBorrowerCurrentMonthlyIndividualObligationRepayment_Co3 { get; set; }
        public bool IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment_Co3 { get; set; }
        public bool IsDisableTotalBorrowerCurrentMonthlyIndividualObligationRepayment_Co3 { get; set; }

        public bool IsActive_Co3 { get; set; }

        #endregion
        public bool IsActive { get; set; }

    }
}
