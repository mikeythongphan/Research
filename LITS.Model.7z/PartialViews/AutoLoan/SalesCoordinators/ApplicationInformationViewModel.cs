﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.Main;

namespace LITS.Model.PartialViews.AutoLoan.SalesCoordinators
{
    public class ApplicationInformationViewModel 
    {
        public int ApplicationInformationID { get; set; }

        public int ALApplicationInformationID { get; set; }

        public string AnchorProduct { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        [Required]
        public string Channel { get; set; }
        public bool IsVisibleChannel { get; set; }
        public bool IsDisableChannel { get; set; }
        public int? ChannelID { get; set; }

        [Required]
        public string PeoplewiseIDofSaleStaf { get; set; }
        public bool IsVisiblePeoplewiseIDofSaleStaf { get; set; }
        public bool IsDisablePeoplewiseIDofSaleStaf { get; set; }

        [Required]
        public string ProgramType { get; set; }
        public int? ProgramTypeID { get; set; }
        public bool IsVisibleProgramType { get; set; }
        public bool IsDisableProgramType { get; set; }

        [Required]
        public string CustomerSegment { get; set; }
        public int? CustomerSegmentID { get; set; }
        public bool IsVisibleCustomerSegment { get; set; }
        public bool IsDisableCustomerSegment { get; set; }

        [Required]
        public string TradingArea { get; set; }
        public int? TradingAreaID { get; set; }
        public bool IsVisibleTradingArea { get; set; }
        public bool IsDisableTradingArea { get; set; }

        [Required]
        public string EOpsTxnReference { get; set; }
        public bool IsVisibleEOpsTxnReference { get; set; }
        public bool IsDisableEOpsTxnReference { get; set; }

        [Required]
        public string StafNonStaf { get; set; }
        public bool IsStafNonStaf { get; set; }
        public bool IsVisibleStafNonStaf { get; set; }
        public bool IsDisableStafNonStaf { get; set; }

        [Required]
        public Nullable<System.DateTime> ReceivingDate { get; set; }
        public bool IsVisibleReceivingDate { get; set; }
        public bool IsDisableReceivingDate { get; set; }

        [Required]
        public string ARMCode { get; set; }
        public bool IsVisibleARMCode { get; set; }
        public bool IsDisableARMCode { get; set; }

        [Required]
        public string ProductType { get; set; }
        public int? ProductTypeID { get; set; }
        public bool IsVisibleProductType { get; set; }
        public bool IsDisableProductType { get; set; }

        [Required]
        public string SaleTMPWID { get; set; }
        public bool IsVisibleSaleTMPWID { get; set; }
        public bool IsDisableSaleTMPWID { get; set; }

        [Required]
        public bool IsBlackList { get; set; }
        public bool IsVisibleBlackList { get; set; }
        public bool IsDisableBlackList { get; set; }

        [Required]
        public Nullable<System.DateTime> ExpectingDisbursedDate { get; set; }
        public bool IsVisibleExpectingDisbursedDate { get; set; }
        public bool IsDisableExpectingDisbursedDate { get; set; }

        public string Rework { get; set; }
        public bool IsRework { get; set; }
        public bool IsVisibleRework { get; set; }
        public bool IsDisableRework { get; set; }

        [Required]
        public string ICT { get; set; }
        public bool IsVisibleICT { get; set; }
        public bool IsDisableICT { get; set; }

        [Required]
        public string Existing { get; set; }
        public bool IsExisting { get; set; }
        public bool IsVisibleExisting { get; set; }
        public bool IsDisableExisting { get; set; }

        [Required]
        public string CDD { get; set; }
        public int? CDDID { get; set; }
        public bool IsVisibleCDD { get; set; }
        public bool IsDisableCDD { get; set; }

        [Required]
        public string BranchCode { get; set; }
        public int? BranchCodeID { get; set; }
        public bool IsVisibleBranchCode { get; set; }
        public bool IsDisableBranchCode { get; set; }

        [Required]
        public string BranchLocation { get; set; }
        public int? BranchLocationID { get; set; }
        public bool IsVisibleBranchLocation { get; set; }
        public bool IsDisableBranchLocation { get; set; }

        [Required]
        public string CustomerType { get; set; }
        public int? CustomerTypeID { get; set; }
        public bool IsVisibleCustomerType { get; set; }
        public bool IsDisableCustomerType { get; set; }

        [Required]
        public Nullable<System.DateTime> HardCopyApplicationDate { get; set; }
        public bool IsVisibleHardCopyApplicationDate { get; set; }
        public bool IsDisableHardCopyApplicationDate { get; set; }

        public string ReasonForRework { get; set; }
        public int? ReasonForReworkID { get; set; }
        public bool IsVisibleReasonForRework { get; set; }
        public bool IsDisableReasonForRework { get; set; }

        [Required]
        public string SalesCode { get; set; }
        public int? SalesCodeID { get; set; }
        public bool IsVisibleSalesCode { get; set; }
        public bool IsDisableSalesCode { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }

        public List<ApplicationDuplicationViewModel> _ApplicationDuplicationViewModel { get; set; }
        public bool IsVisibleApplicationDuplication { get; set; }
        public bool IsDisableApplicationDuplication { get; set; }
    }
}
