﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.SalesCoordinators
{
    public class CollateralInformationViewModel
    {
        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }

        public string CarMarkerBrand { get; set; }
        public bool IsVisibleCarMarkerBrand { get; set; }
        public bool IsEnabledCarMarkerBrand { get; set; }
        public int CarMarkerBrandID { get; set; }

        public string PropertyStatus { get; set; }
        public bool IsVisiblePropertyStatus { get; set; }
        public bool IsEnabledPropertyStatus { get; set; }
        public int PropertyStatusID { get; set; }

        public string Model { get; set; }
        public bool IsVisibleModel { get; set; }
        public bool IsEnabledModel { get; set; }
        public int ModelID { get; set; }

        public string CarType { get; set; }
        public bool IsVisibleCarType { get; set; }
        public bool IsEnabledCarType { get; set; }
        public int CarTypeID { get; set; }

        public string CarSource { get; set; }
        public bool IsVisibleCarSource { get; set; }
        public bool IsEnabledCarSource { get; set; }
        public int CarSourceID { get; set; }

        public Nullable<System.DateTime> YearOfManufacture { get; set; }
        public bool IsVisibleYearOfManufacture { get; set; }
        public bool IsEnabledYearOfManufacture { get; set; }

        public string Color { get; set; }
        public bool IsVisibleColor { get; set; }
        public bool IsEnabledColor { get; set; }

        public string NumberOfSeats { get; set; }
        public bool IsVisibleNumberOfSeats { get; set; }
        public bool IsEnabledNumberOfSeats { get; set; }

        public string ChassisNumber { get; set; }
        public bool IsVisibleChassisNumber { get; set; }
        public bool IsEnabledChassisNumber { get; set; }

        public int PurchasingPriceOrFairMarketValue { get; set; }
        public bool IsVisiblePurchasingPriceOrFairMarketValue { get; set; }
        public bool IsEnabledPurchasingPriceOrFairMarketValue { get; set; }

        public string PurchasingSPContractNumber { get; set; }
        public bool IsVisiblePurchasingSPContractNumber { get; set; }
        public bool IsEnabledPurchasingSPContractNumber { get; set; }

        public string CollateralValue { get; set; }
        public bool IsVisibleCollateralValue { get; set; }
        public bool IsEnabledCollateralValue { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsEnabledApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsEnabledApplicationStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
