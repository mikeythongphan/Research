﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.AutoLoan.SalesCoordinators
{
    public class CustomerDemostrationViewModel
    {
        public int ApplicationInformationID { get; set; }

        public int ALApplicationInformationID { get; set; }

        public decimal? TotalFDvalue { get; set; }
        public bool IsVisibleTotalFDvalue { get; set; }
        public bool IsEnabledTotalFDvalue { get; set; }

        public int TotalPropertyOwned { get; set; }
        public bool IsVisibleTotalPropertyOwned { get; set; }
        public bool IsEnabledTotalPropertyOwned { get; set; }

        public int TotalCarOwned { get; set; }
        public bool IsVisibleTotalCarOwned { get; set; }
        public bool IsEnabledTotalCarOwned { get; set; }

        public string OtherAsset { get; set; }
        public bool IsVisibleOtherAsset { get; set; }
        public bool IsEnabledOtherAsset { get; set; }

        public decimal? MonthlyExpenditure { get; set; }
        public bool IsVisibleMonthlyExpenditure { get; set; }
        public bool IsEnabledMonthlyExpenditure { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
