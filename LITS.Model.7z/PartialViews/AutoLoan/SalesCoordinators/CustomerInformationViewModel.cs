﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Domain.Main;

namespace LITS.Model.PartialViews.AutoLoan.SalesCoordinators
{
    public class CustomerInformationViewModel
    {
        private CustomerDetailViewModel _objCustomerDetailViewModel_Main = new CustomerDetailViewModel();
        public CustomerDetailViewModel _CustomerDetailViewModel_Main
        {
            get
            {
                return _objCustomerDetailViewModel_Main;
            }
            set { _objCustomerDetailViewModel_Main = value; }
        }

        private CustomerDetailViewModel _objCustomerDetailViewModel_Co1 = new CustomerDetailViewModel();
        public CustomerDetailViewModel _CustomerDetailViewModel_Co1
        {
            get
            {
                return _objCustomerDetailViewModel_Co1;
            }
            set { _objCustomerDetailViewModel_Co1 = value; }
        }

        private CustomerDetailViewModel _objCustomerDetailViewModel_Co2 = new CustomerDetailViewModel();
        public CustomerDetailViewModel _CustomerDetailViewModel_Co2
        {
            get
            {
                return _objCustomerDetailViewModel_Co2;
            }
            set { _objCustomerDetailViewModel_Co2 = value; }
        }

        private CustomerDetailViewModel _objCustomerDetailViewModel_Co3 = new CustomerDetailViewModel();
        public CustomerDetailViewModel _CustomerDetailViewModel_Co3
        {
            get
            {
                return _objCustomerDetailViewModel_Co3;
            }
            set { _objCustomerDetailViewModel_Co3 = value; }
        }
    }

    public class CustomerDetailViewModel
    {
        #region PK-FK
        public int ID { get; set; }

        public int ApplicationTypeID { get; set; }
        public string ApplicationType { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsEnabledApplicationType { get; set; }

        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }
        public int CustomerInformationID { get; set; }
        public int ALCustomerInformationID { get; set; }
        #endregion

        [Required]
        public string CustomerSCRelationship { get; set; }
        public int? CustomerSCRelationshipID { get; set; }
        public bool IsVisibleCustomerSCRelationship { get; set; }
        public bool IsEnabledCustomerSCRelationship { get; set; }

        [Required]
        public Nullable<System.DateTime> DOB { get; set; }
        public bool IsVisibleDOB { get; set; }
        public bool IsEnabledDOB { get; set; }

        [Required]
        public string PermanentAddress { get; set; }
        public bool IsVisiblePermanentAddress { get; set; }
        public bool IsEnabledPermanentAddress { get; set; }

        [Required]
        public string PermanentAddressCity { get; set; }
        public bool IsVisiblePermanentAddressCity { get; set; }
        public bool IsEnabledPermanentAddressCity { get; set; }

        [Required]
        public string District { get; set; }
        public int? DistrictID { get; set; }
        public bool IsVisibleDistrict { get; set; }
        public bool IsEnabledDistrict { get; set; }

        [Required]
        public string TypeOfResidenceOwnership { get; set; }
        public int? TypeOfResidenceOwnershipID { get; set; }
        public bool IsVisibleTypeOfResidenceOwnership { get; set; }
        public bool IsEnabledTypeOfResidenceOwnership { get; set; }

        [Required]
        public string EmailAddress1 { get; set; }
        public bool IsVisibleEmailAddress1 { get; set; }
        public bool IsEnabledEmailAddress1 { get; set; }

        [Required]
        public string MaritalStatus { get; set; }
        public int? MaritalStatusID { get; set; }
        public bool IsVisibleMaritalStatus { get; set; }
        public bool IsEnabledMaritalStatus { get; set; }

        [Required]
        public string Intitial { get; set; }
        public int? IntitialID { get; set; }
        public bool IsVisibleIntitial { get; set; }
        public bool IsEnabledIntitial { get; set; }

        [Required]
        public string Nationality { get; set; }
        public int? NationalityID { get; set; }
        public bool IsVisibleNationality { get; set; }
        public bool IsEnabledNationality { get; set; }

        [Required]
        public string PermanentAddressWard { get; set; }
        public bool IsVisiblePermanentAddressWard { get; set; }
        public bool IsEnabledPermanentAddressWard { get; set; }

        [Required]
        public string CurrentResidentalAddress { get; set; }
        public bool IsVisibleCurrentResidentalAddress { get; set; }
        public bool IsEnabledCurrentResidentalAddress { get; set; }

        [Required]
        public string City { get; set; }
        public int? CityID { get; set; }
        public bool IsVisibleCity { get; set; }
        public bool IsEnabledCity { get; set; }

        [Required]
        public string MobileNo { get; set; }
        public bool IsVisibleMobileNo { get; set; }
        public bool IsEnabledMobileNo { get; set; }

        public string EmailAddress2 { get; set; }
        public bool IsVisibleEmailAddress2 { get; set; }
        public bool IsEnabledEmailAddress2 { get; set; }

        public string EducationLever { get; set; }
        public int? EducationLeverID { get; set; }
        public bool IsVisibleEducationLever { get; set; }
        public bool IsEnabledEducationLever { get; set; }

        [Required]
        public string FullName { get; set; }
        public bool IsVisibleFullName { get; set; }
        public bool IsEnabledFullName { get; set; }

        public string NumberOfDependants { get; set; }
        public int? NumberOfDependantsID { get; set; }
        public bool IsVisibleNumberOfDependants { get; set; }
        public bool IsEnabledNumberOfDependants { get; set; }

        [Required]
        public string PermanentAddressDistrict { get; set; }
        public bool IsVisiblePermanentAddressDistrict { get; set; }
        public bool IsEnabledPermanentAddressDistrict { get; set; }

        [Required]
        public string Ward { get; set; }
        public bool IsVisibleWard { get; set; }
        public bool IsEnabledWard { get; set; }

        [Required]
        public string TimeAtCurrentAddress { get; set; }
        public bool IsVisibleTimeAtCurrentAddress { get; set; }
        public bool IsEnabledTimeAtCurrentAddress { get; set; }

        public string HomePhoneNo { get; set; }
        public bool IsVisibleHomePhoneNo { get; set; }
        public bool IsEnabledHomePhoneNo { get; set; }

        [Required]
        public string BillingAddress { get; set; }
        public int? BillingAddressID { get; set; }
        public bool IsVisibleBillingAddress { get; set; }
        public bool IsEnabledBillingAddress { get; set; }

        [Required]
        public string EmploymentBusinessTerm { get; set; }
        public int? EmploymentBusinessTermID { get; set; }
        public bool IsVisibleEmploymentBusinessTerm { get; set; }
        public bool IsEnabledEmploymentBusinessTerm { get; set; }

        public string Status { get; set; }
        public int? StatusID { get; set; }
        public bool IsVisibleStatus { get; set; }
        public bool IsEnabledStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }

        private List<CustomerIdentificationViewModel> _objCustomerIdentificationViewModel = new List<CustomerIdentificationViewModel>();
        public List<CustomerIdentificationViewModel> _CustomerIdentificationViewModel
        {
            get
            {
                return _objCustomerIdentificationViewModel;
            }
            set { _objCustomerIdentificationViewModel = value; }
        }
    }
}
