﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.Views.Management;

namespace LITS.Model.PartialViews.Main.CreateNewLoan
{
    public class CreateNewLoanStep2ViewModel
    {
        public int? ProductTypeID { get; set; }
        public string ProductType { get; set; }
        public bool IsVisibleProductTypeID { get; set; }
        public bool IsDisableProductTypeID { get; set; }

        public int? ApplicationTypeID { get; set; }
        public string ApplicationType { get; set; }
        public bool IsVisibleApplicationTypeID { get; set; }
        public bool IsDisableApplicationTypeID { get; set; }

        #region Main-Borrower
        public int? CustomerNameMainID { get; set; }
        public string CustomerNameMain { get; set; }
        public bool IsVisibleCustomerNameMain { get; set; }
        public bool IsDisableCustomerNameMain { get; set; }

        public Nullable<DateTime> DateOfBirthMain { get; set; }
        public bool IsVisibleDateOfBirthMain { get; set; }
        public bool IsDisableDateOfBirthMain { get; set; }

        public bool IsActivehMain { get; set; }

        private List<CreateNewLoanStep2IdentificationViewModel> _objCreateNewLoanStep2IdentificationMain = new List<CreateNewLoanStep2IdentificationViewModel>();
        public List<CreateNewLoanStep2IdentificationViewModel> lstCreateNewLoanStep2IdentificationMain
        {
            get
            {
                return _objCreateNewLoanStep2IdentificationMain;
            }
            set { _objCreateNewLoanStep2IdentificationMain = value; }
        }

        private List<CreateNewLoanStep2CompanyViewModel> _objCreateNewLoanStep2CompanyViewModel = new List<CreateNewLoanStep2CompanyViewModel>();
        public List<CreateNewLoanStep2CompanyViewModel> lstCreateNewLoanStep2CompanyMain
        {
            get
            {
                return _objCreateNewLoanStep2CompanyViewModel;
            }
            set { _objCreateNewLoanStep2CompanyViewModel = value; }
        }
        #endregion

        #region Co-Borrower 1 
        public int? CustomerNameCo1ID { get; set; }
        public string CustomerNameCo1 { get; set; }
        public bool IsVisibleCustomerNameCo1 { get; set; }
        public bool IsDisableCustomerNameCo1 { get; set; }

        public Nullable<DateTime> DateOfBirthCo1 { get; set; }
        public bool IsVisibleDateOfBirthCo1 { get; set; }
        public bool IsDisableDateOfBirthCo1 { get; set; }

        public bool IsActiveCo1 { get; set; }

        private List<CreateNewLoanStep2IdentificationViewModel> _objCreateNewLoanStep2IdentificationCo1 = new List<CreateNewLoanStep2IdentificationViewModel>();
        public List<CreateNewLoanStep2IdentificationViewModel> lstCreateNewLoanStep2IdentificationCo1
        {
            get
            {
                return _objCreateNewLoanStep2IdentificationCo1;
            }
            set { _objCreateNewLoanStep2IdentificationCo1 = value; }
        }

        private List<CreateNewLoanStep2CompanyViewModel> _objCreateNewLoanStep2CompanyCo1 = new List<CreateNewLoanStep2CompanyViewModel>();
        public List<CreateNewLoanStep2CompanyViewModel> lstCreateNewLoanStep2CompanyCo1
        {
            get
            {
                return _objCreateNewLoanStep2CompanyCo1;
            }
            set { _objCreateNewLoanStep2CompanyCo1 = value; }
        }
        #endregion

        #region Co-Borrower 2 
        public string CustomerNameCo2 { get; set; }
        public bool IsVisibleCustomerNameCo2 { get; set; }
        public bool IsDisableCustomerNameCo2 { get; set; }

        public Nullable<DateTime> DateOfBirthCo2 { get; set; }
        public bool IsVisibleDateOfBirthCo2 { get; set; }
        public bool IsDisableDateOfBirthCo2 { get; set; }

        public bool IsActiveCo2 { get; set; }

        private List<CreateNewLoanStep2IdentificationViewModel> _objCreateNewLoanStep2IdentificationCo2 = new List<CreateNewLoanStep2IdentificationViewModel>();
        public List<CreateNewLoanStep2IdentificationViewModel> lstCreateNewLoanStep2IdentificationCo2
        {
            get
            {
                return _objCreateNewLoanStep2IdentificationCo2;
            }
            set { _objCreateNewLoanStep2IdentificationCo2 = value; }
        }

        private List<CreateNewLoanStep2CompanyViewModel> _objCreateNewLoanStep2CompanyCo2 = new List<CreateNewLoanStep2CompanyViewModel>();
        public List<CreateNewLoanStep2CompanyViewModel> lstCreateNewLoanStep2CompanyCo2
        {
            get
            {
                return _objCreateNewLoanStep2CompanyCo2;
            }
            set { _objCreateNewLoanStep2CompanyCo2 = value; }
        }
        #endregion

        #region Co-Borrower 3 
        public int? CustomerNameCo3ID { get; set; }
        public string CustomerNameCo3 { get; set; }
        public bool IsVisibleCustomerNameCo3 { get; set; }
        public bool IsDisableCustomerNameCo3 { get; set; }

        public Nullable<DateTime> DateOfBirthCo3 { get; set; }
        public bool IsVisibleDateOfBirthCo3 { get; set; }
        public bool IsDisableDateOfBirthCo3 { get; set; }

        public bool IsActiveCo3 { get; set; }

        private List<CreateNewLoanStep2IdentificationViewModel> _objCreateNewLoanStep2IdentificationCo3 = new List<CreateNewLoanStep2IdentificationViewModel>();
        public List<CreateNewLoanStep2IdentificationViewModel> lstCreateNewLoanStep2IdentificationCo3
        {
            get
            {
                return _objCreateNewLoanStep2IdentificationCo3;
            }
            set { _objCreateNewLoanStep2IdentificationCo3 = value; }
        }

        private List<CreateNewLoanStep2CompanyViewModel> _objCreateNewLoanStep2CompanyCo3 = new List<CreateNewLoanStep2CompanyViewModel>();
        public List<CreateNewLoanStep2CompanyViewModel> lstCreateNewLoanStep2CompanyCo3
        {
            get
            {
                return _objCreateNewLoanStep2CompanyCo3;
            }
            set { _objCreateNewLoanStep2CompanyCo3 = value; }
        }
        #endregion

        #region Company
        public int? CompanyNameID { get; set; }
        public string CompanyName  { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsDisableCompanyName { get; set; }

        public string CompanyCodeRLS { get; set; }
        public bool IsVisibleCompanyCodeRLS { get; set; }
        public bool IsDisableCompanyCodeRLS { get; set; }

        public string CompanyCode { get; set; }
        public bool IsVisibleCompanyCode { get; set; }
        public bool IsDisableCompanyCode { get; set; }

        public string CompanyCAT { get; set; }
        public bool IsVisibleCompanyCAT { get; set; }
        public bool IsDisableCompanyCAT { get; set; }

        public string CompanyAddress { get; set; }
        public bool IsVisibleCompanyAddress { get; set; }
        public bool IsDisableCompanyAddress { get; set; }

        public string CompanyWard { get; set; }
        public bool IsVisibleCompanyWard { get; set; }
        public bool IsDisableCompanyWard { get; set; }

        public int? CompanyDistrictID { get; set; }
        public string CompanyDistrict { get; set; }
        public bool IsVisibleCompanyDistrict { get; set; }
        public bool IsDisableCompanyDistrict { get; set; }

        public int? CompanyCityID { get; set; }
        public string CompanyCity { get; set; }
        public bool IsVisibleCompanyCity { get; set; }
        public bool IsDisableCompanyCity { get; set; }

        public string CompanyPhone { get; set; }
        public bool IsVisibleCompanyPhone { get; set; }
        public bool IsDisableCompanyPhone { get; set; }

        public int? CompanyTypeID { get; set; }
        public string CompanyType { get; set; }
        public bool IsVisibleCompanyType { get; set; }
        public bool IsDisableCompanyType { get; set; }

        public string TaxNumber { get; set; }
        public bool IsVisibleTaxNumber { get; set; }
        public bool IsDisableTaxNumber { get; set; }

        public string BusinessRegistrationNumber { get; set; }
        public bool IsVisibleBusinessRegistrationNumber { get; set; }
        public bool IsDisableBusinessRegistrationNumber { get; set; }

        public string CompanyRemark { get; set; }
        public bool IsVisibleCompanyRemark { get; set; }
        public bool IsDisableCompanyRemark { get; set; }

        public bool IsActiveCompany { get; set; }
        #endregion

        #region LegalRepresentative
        public int? IntitialID { get; set; }
        public string Intitial { get; set; }
        public bool IsVisibleIntitial { get; set; }
        public bool IsDisableIntitial { get; set; }

        public int? LegalRepresentativeID { get; set; }
        public string LegalRepresentativeName { get; set; }
        public bool IsVisibleLegalRepresentative { get; set; }
        public bool IsDisableLegalRepresentative { get; set; }

        public int? LegalRepresentativeNationalityID { get; set; }
        public string LegalRepresentativeNationalityName { get; set; }
        public bool IsVisibleLegalLegalRepresentativeNationality { get; set; }
        public bool IsDisableLegalLegalRepresentativeNationality { get; set; }

        public Nullable<DateTime> LegalRepresentativeDateOfBirth { get; set; }
        public bool IsVisibleLegalRepresentativeDateOfBirth { get; set; }
        public bool IsDisableLegalRepresentativeDateOfBirth { get; set; }

        public bool IsActiveLegalRepresentative { get; set; }

        private List<CreateNewLoanStep2IdentificationViewModel> _objCreateNewLoanStep2IdentificationLegalRepresentative = new List<CreateNewLoanStep2IdentificationViewModel>();
        public List<CreateNewLoanStep2IdentificationViewModel> lstCreateNewLoanStep2IdentificationLegalRepresentative
        {
            get
            {
                return _objCreateNewLoanStep2IdentificationLegalRepresentative;
            }
            set { _objCreateNewLoanStep2IdentificationLegalRepresentative = value; }
        }
        #endregion

        private List<IdentificationTypeViewModel> _objIdentificationTypeViewModel = new List<IdentificationTypeViewModel>();
        public List<IdentificationTypeViewModel> _M_IdentificationTypeViewModel
        {
            get
            {
                return _objIdentificationTypeViewModel;
            }
            set { _objIdentificationTypeViewModel = value; }
        }

        private List<CompanyTypeViewModel> _objCompanyTypeViewModel = new List<CompanyTypeViewModel>();
        public List<CompanyTypeViewModel> _M_CompanyTypeViewModel
        {
            get
            {
                return _objCompanyTypeViewModel;
            }
            set { _objCompanyTypeViewModel = value; }
        }
    }

    public class CreateNewLoanStep2IdentificationViewModel
    {
        public string IdentificationType { get; set; }
        public int? IdentificationTypeID { get; set; }
        public bool IsVisibleIdentificationType { get; set; }
        public bool IsDisableIdentificationType { get; set; }

        public string IdentificationNo { get; set; }
        public int? IdentificationNoID { get; set; }
        public bool IsVisibleIdentificationNo { get; set; }
        public bool IsDisableIdentificationNo { get; set; }

        public bool IsActive { get; set; }
    }

    public class CreateNewLoanStep2CompanyViewModel
    {        
        public string CompanyName { get; set; }
        public int? CompanyNameID { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsDisableCompanyName { get; set; }

        public string CompanyCode { get; set; }        
        public bool IsVisibleCompanyCode { get; set; }
        public bool IsDisableCompanyCode { get; set; }

        public string CompanyCAT { get; set; }        
        public bool IsVisibleCompanyCAT { get; set; }
        public bool IsDisableCompanyCAT { get; set; }

        public string CompanyType { get; set; }
        public int? CompanyTypeID { get; set; }
        public bool IsVisibleCompanyType { get; set; }
        public bool IsDisableCompanyType { get; set; }

        public bool IsActive { get; set; }
    }
}
