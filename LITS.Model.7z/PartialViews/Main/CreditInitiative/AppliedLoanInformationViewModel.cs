﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.Main.CreditInitiative
{
    public class AppliedLoanInformationViewModel
    {
        public int ApplicationInformationID { get; set; }
        public int ALApplicationInformationID { get; set; }

        public decimal? AmountRequested { get; set; }
        public bool IsVisibleAmountRequested { get; set; }
        public bool IsEnabledAmountRequested { get; set; }

        public int Tenors { get; set; }
        public int? TenorsID { get; set; }
        public bool IsVisibleTenors { get; set; }
        public bool IsEnabledTenors { get; set; }

        public decimal? LTV { get; set; }
        public bool IsVisibleLTV { get; set; }
        public bool IsEnabledLTV { get; set; }

        public string ProgramType { get; set; }
        public bool IsVisibleProgramType { get; set; }
        public bool IsEnabledProgramType { get; set; }
        public int? ProgramTypeID { get; set; }

        public string FloatingInterestRate { get; set; }
        public bool IsVisibleFloatingInterestRate { get; set; }
        public bool IsEnabledFloatingInterestRate { get; set; }
        public int? FloatingInterestRateID { get; set; }

        public string LoanPurpose { get; set; }
        public bool IsVisibleLoanPurpose { get; set; }
        public bool IsEnabledLoanPurpose { get; set; }
        public int? LoanPurposeID { get; set; }

        public string PaymentType { get; set; }
        public bool IsVisiblePaymentType { get; set; }
        public bool IsEnabledPaymentType { get; set; }
        public int? PaymentTypeID { get; set; }

        public string CampaignCode { get; set; }
        public bool IsVisibleCampaignCode { get; set; }
        public bool IsEnabledCampaignCode { get; set; }
        public int? CampaignCodeID { get; set; }

        public string CreditDeviation { get; set; }
        public bool IsVisibleCreditDeviation { get; set; }
        public bool IsEnabledCreditDeviation { get; set; }
        public int? CreditDeviationID { get; set; }

        public string ReasonForDeviation { get; set; }
        public bool IsVisibleReasonForDeviation { get; set; }
        public bool IsEnabledReasonForDeviation { get; set; }
        public int? ReasonForDeviationID { get; set; }

        public string ApplicationType { get; set; }
        public int? ApplicationTypeID { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsEnabledApplicationType { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsEnabledApplicationStatus { get; set; }

        public string CreateBy { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public bool IsActive { get; set; }
    }
}
