﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using System.ComponentModel.DataAnnotations;

namespace LITS.Model.PartialViews.Main.FRMWorkInProgress
{
    public class FRMWorkInProgressDetailViewModel
    {
        public int ApplicationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        public int ApplicationTypeID { get; set; }
        public string ApplicationType { get; set; }
        public bool IsVisibleApplicationType { get; set; }
        public bool IsDisableApplicationType { get; set; }

        public Nullable<DateTime> ReceivedDate { get; set; }
        public bool IsVisibleReceivedDate { get; set; }
        public bool IsDisableReceivedDate { get; set; }

        public string ApplicationStatus { get; set; }
        public int? ApplicationStatusID { get; set; }
        public bool IsVisibleApplicationStatus { get; set; }
        public bool IsDisableApplicationStatus { get; set; }

        public int? TeleStatusID { get; set; }
        public string TeleStatus { get; set; }
        public bool IsVisibleTeleStatus { get; set; }
        public bool IsDisableTeleStatus { get; set; }

        private List<FRMWorkInProgressDetailChildViewModel> _objFRMWorkInProgressDetailChildViewModel = new List<FRMWorkInProgressDetailChildViewModel>();
        public List<FRMWorkInProgressDetailChildViewModel> _FRMWorkInProgressDetailChildViewModel
        {
            get
            {
                return _objFRMWorkInProgressDetailChildViewModel;
            }
            set { _objFRMWorkInProgressDetailChildViewModel = value; }
        }
        public bool IsVisibleFRMWorkInProgressDetailChilds { get; set; }
        public bool IsDisableFRMWorkInProgressDetailChild { get; set; }
    }

    public class FRMWorkInProgressDetailChildViewModel
    {
        public int ApplicationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public bool IsVisibleCustomerName { get; set; }
        public bool IsDisableCustomerName { get; set; }

        public string IDNumber { get; set; }
        public bool IsVisibleIDNumber { get; set; }
        public bool IsDisableIDNumber { get; set; }

        public int? CustomerSegmentID { get; set; }
        public string CustomerSegment { get; set; }
        public bool IsVisibleCustomerSegment { get; set; }
        public bool IsDisableCustomerSegment { get; set; }

        public int? ChannelID { get; set; }
        public string ChannelName { get; set; }
        public bool IsVisibleChannelID { get; set; }
        public bool IsDisableChannelID { get; set; }

        public int? LocationID { get; set; }
        public string LocationName { get; set; }
        public bool IsVisibleLocation { get; set; }
        public bool IsDisableLocation { get; set; }

        public decimal? AmountRequest { get; set; }
        public bool IsVisibleAmountRequest { get; set; }
        public bool IsDisableAmountRequest { get; set; }

        public decimal? AmountApproved { get; set; }
        public bool IsVisibleAmountApproved { get; set; }
        public bool IsDisableAmountApproved { get; set; }
    }
}
