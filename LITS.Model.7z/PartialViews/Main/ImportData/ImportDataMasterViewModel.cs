﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using System.ComponentModel.DataAnnotations;

namespace LITS.Model.PartialViews.Main.ImportData
{
    public class ImportDataMasterViewModel
    {
        public Nullable<System.DateTime> FromDate { get; set; }
        public bool IsVisibleFromDate { get; set; }
        public bool IsDisableFromDate { get; set; }

        public Nullable<System.DateTime> ToDate { get; set; }
        public bool IsVisibleToDate { get; set; }
        public bool IsDisableToDate { get; set; }

        public int? StatusID { get; set; }
        public string Status { get; set; }
        public bool IsVisibleStatus { get; set; }
        public bool IsDisableStatus { get; set; }

        public int? ApplicationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        public int? CustomerID { get; set; }
        public string CustomerName { get; set; }
        public bool IsVisibleCustomerName { get; set; }
        public bool IsDisableCustomerName { get; set; }

        public int? CompanyID { get; set; }
        public string CompanyName { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsDisableCompanyName { get; set; }

        private List<ImportDataMasterCustomerViewModel> _objImportDataMasterCustomerViewModel = new List<ImportDataMasterCustomerViewModel>();
        public List<ImportDataMasterCustomerViewModel> _ImportDataMasterCustomerViewModel
        {
            get
            {
                return _objImportDataMasterCustomerViewModel;
            }
            set { _objImportDataMasterCustomerViewModel = value; }
        }
        public bool IsVisibleImportDataMasterCustomer { get; set; }
        public bool IsDisableImportDataMasterCustomer { get; set; }

        private List<ImportDataMasterCompanyViewModel> _objImportDataMasterCompanyViewModel = new List<ImportDataMasterCompanyViewModel>();
        public List<ImportDataMasterCompanyViewModel> _ImportDataMasterCompanyViewModel
        {
            get
            {
                return _objImportDataMasterCompanyViewModel;
            }
            set { _objImportDataMasterCompanyViewModel = value; }
        }
        public bool IsVisibleImportDataMasterCompany { get; set; }
        public bool IsDisableImportDataMasterCompany { get; set; }
    }

    public class ImportDataMasterCustomerViewModel
    {
        public int? CustomerID { get; set; }
        public string CustomerName { get; set; }
        public bool IsVisibleCustomerID { get; set; }
        public bool IsDisableCustomerID { get; set; }

        public int? CustomerIdentificationID { get; set; }
        public string CustomerIdentification { get; set; }
        public bool IsVisibleCustomerIdentification { get; set; }
        public bool IsDisableCustomerIdentification { get; set; }
    }

    public class ImportDataMasterCompanyViewModel
    {
        public int? CompanyID { get; set; }
        public string CompanyName { get; set; }
        public bool IsVisibleCompanyID { get; set; }
        public bool IsDisableCompanyID { get; set; }

        public string CompanyCode { get; set; }
        public bool IsVisibleCompanyCode { get; set; }
        public bool IsDisableCompanyCode { get; set; }
    }
}
