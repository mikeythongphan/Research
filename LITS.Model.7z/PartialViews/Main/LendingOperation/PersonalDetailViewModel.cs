﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.Main.LendingOperation
{
    public class PersonalDetailViewModel
    {
        public bool IsActive { get; set; }
        public string Initital { get; set; }
        public bool IsVisibleInitital { get; set; }
        public bool IsDisableInitital { get; set; }
        public string Gender { get; set; }
        public bool IsVisibleGender { get; set; }
        public bool IsDisableGender { get; set; }
        public string FullName { get; set; }
        public bool IsVisibleFullName { get; set; }
        public bool IsDisableFullName { get; set; }
        public Nullable<System.DateTime> DOB { get; set; }
        public bool IsVisibleDOB { get; set; }
        public bool IsDisableDOB { get; set; }
        public string Nationlity { get; set; }
        public bool IsVisibleNationlity { get; set; }
        public bool IsDisableNationlity { get; set; }
        public string IDNumber { get; set; }
        public bool IsVisibleIDNumber { get; set; }
        public bool IsDisableIDNumber { get; set; }
        public string CurrentHomeAddress { get; set; }
        public bool IsVisibleCurrentHomeAddress { get; set; }
        public bool IsDisableCurrentHomeAddress { get; set; }
        public string Ward { get; set; }
        public bool IsVisibleWard { get; set; }
        public bool IsDisableWard { get; set; }
        public string District { get; set; }
        public bool IsVisibleDistrict { get; set; }
        public bool IsDisableDistrict { get; set; }
        public string City { get; set; }
        public bool IsVisibleCity { get; set; }
        public bool IsDisableCity { get; set; }
        public string MobileNo { get; set; }
        public bool IsVisibleMobileNo { get; set; }
        public bool IsDisableMobileNo { get; set; }
    }
}
