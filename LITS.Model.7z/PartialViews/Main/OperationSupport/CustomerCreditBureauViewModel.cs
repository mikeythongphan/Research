﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.Main.OperationSupport
{
    public class CustomerCreditBureauViewModel
    {
        #region Main
        public int BureauDataLoanCurrent { get; set; }
        public bool IsVisibleBureauDataLoanCurrent { get; set; }
        public bool IsDisableBureauDataLoanCurrent { get; set; }

        public int BureauDataLoanHistory { get; set; }
        public bool IsVisibleBureauDataLoanHistory { get; set; }
        public bool IsDisableBureauDataLoanHistory { get; set; }

        public int BureauDataCardCurrent { get; set; }
        public bool IsVisibleBureauDataCardCurrent { get; set; }
        public bool IsDisableBureauDataCardCurrent { get; set; }

        public int BureauDataCardHistory{ get; set; }
        public bool IsVisibleBureauDataCardHistory { get; set; }
        public bool IsDisableBureauDataCardHistory { get; set; }

        public string CreditBureauType { get; set; }
        public bool IsVisibleCreditBureauType { get; set; }
        public bool IsDisableCreditBureauType { get; set; }
        public int CreditBureauTypeID { get; set; }

        public decimal CurrentUnsecuredOutstandingOnUs { get; set; }
        public bool IsVisibleCurrentUnsecuredOutstandingOnUs { get; set; }
        public bool IsDisableCurrentUnsecuredOutstandingOnUs { get; set; }

        public decimal CurrentUnsecuredOutstandingOfUs { get; set; }
        public bool IsVisibleCurrentUnsecuredOutstandingOfUs { get; set; }
        public bool IsDisableCurrentUnsecuredOutstandingOfUs { get; set; }

        public decimal CurrentTotalEMIOnUs { get; set; }
        public bool IsVisibleCurrentTotalEMIOnUs { get; set; }
        public bool IsDisableCurrentTotalEMIOnUs { get; set; }

        public decimal CurrentTotalEMIOfUs { get; set; }
        public bool IsVisibleCurrentTotalEMIOfUs { get; set; }
        public bool IsDisableCurrentTotalEMIOfUs { get; set; }

        public decimal CurrentUnsecureLimitOnUs { get; set; }
        public bool IsVisibleCurrentUnsecureLimitOnUs { get; set; }
        public bool IsDisableCurrentUnsecureLimitOnUs { get; set; }

        public decimal TotalOutStandingBalanceCreditCard { get; set; }
        public bool IsVisibleTotalOutStandingBalanceCreditCard { get; set; }
        public bool IsDisableTotalOutStandingBalanceCreditCard { get; set; }

        public decimal TotalLimitCreditCard { get; set; }
        public bool IsVisibleTotalLimitCreditCard { get; set; }
        public bool IsDisableTotalLimitCreditCard { get; set; }

        public decimal CurrentCardUtilization { get; set; }
        public bool IsVisibleCurrentCardUtilization { get; set; }
        public bool IsDisableCurrentCardUtilization { get; set; }

        public decimal TotalBorrowerCurrentMonthlyIndividualObligationRepayment { get; set; }
        public bool IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment { get; set; }
        public bool IsDisableTotalBorrowerCurrentMonthlyIndividualObligationRepayment { get; set; }

        #endregion

        public bool IsActive { get; set; }

    }
}
