﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using System.ComponentModel.DataAnnotations;

namespace LITS.Model.PartialViews.Main.SalesCoordinators
{
    public class ApplicationInformationViewModel
    {
        [Required]
        public string ArmCode { get; set; }

        [DataType(DataType.Date)]
        public Nullable<System.DateTime> ReceivedDate { get; set; }

        [StringLength(7)]
        public string SaleStaffBankID { get; set; }

        public string SaleStaffName { get; set; }

        //public application_information _application_information { get; set; }

        #region Management
        public m_branch_code _m_branch_code { get; set; }
        public m_branch_location _m_branch_location { get; set; }
        #endregion
    }
}
