﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LITS.Model.PartialViews.Main.SearchApplication
{
    public class SearchApplicationTreeViewModel
    {
        public int ID { get; set; }
        public bool IsVisibleID { get; set; }
        public bool IsDisableID { get; set; }

        public int? ParentID { get; set; }
        public bool IsVisibleParentID { get; set; }
        public bool IsDisableParentID { get; set; }

        public string Name { get; set; }
        public bool IsVisibleName { get; set; }
        public bool IsDisableName { get; set; }

        public bool IsActive { get; set; }
    }
}
