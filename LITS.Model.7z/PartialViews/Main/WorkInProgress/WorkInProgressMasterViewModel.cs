﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using System.ComponentModel.DataAnnotations;

namespace LITS.Model.PartialViews.Main.WorkInProgress
{
    public class WorkInProgressMasterViewModel
    {
        public Nullable<System.DateTime> FromDate { get; set; }
        public bool IsVisibleFromDate { get; set; }
        public bool IsDisableFromDate { get; set; }

        public Nullable<System.DateTime> ToDate { get; set; }
        public bool IsVisibleToDate { get; set; }
        public bool IsDisableToDate { get; set; }

        public int? StatusID { get; set; }
        public string Status { get; set; }
        public bool IsVisibleStatus { get; set; }
        public bool IsDisableStatus { get; set; }

        public int? ApplicationID { get; set; }
        public string ApplicationNo { get; set; }
        public bool IsVisibleApplicationNo { get; set; }
        public bool IsDisableApplicationNo { get; set; }

        public string CustomerName { get; set; }
        public bool IsVisibleCustomerName { get; set; }
        public bool IsDisableCustomerName { get; set; }                

        public string CompanyName { get; set; }
        public bool IsVisibleCompanyName { get; set; }
        public bool IsDisableCompanyName { get; set; }

        private List<WorkInProgressMasterCustomerViewModel> _objWorkInProgressMasterCustomerViewModel = new List<WorkInProgressMasterCustomerViewModel>();
        public List<WorkInProgressMasterCustomerViewModel> _WorkInProgressMasterCustomerViewModel
        {
            get
            {
                return _objWorkInProgressMasterCustomerViewModel;
            }
            set { _objWorkInProgressMasterCustomerViewModel = value; }
        }

        private List<WorkInProgressMasterCompanyViewModel> _objWorkInProgressMasterCompanyViewModel = new List<WorkInProgressMasterCompanyViewModel>();
        public List<WorkInProgressMasterCompanyViewModel> _WorkInProgressMasterCompanyViewModel
        {
            get
            {
                return _objWorkInProgressMasterCompanyViewModel;
            }
            set { _objWorkInProgressMasterCompanyViewModel = value; }
        }
    }

    public class WorkInProgressMasterCustomerViewModel
    {
        public int? CustomerID { get; set; }
        public string CustomerName { get; set; }
        public bool IsVisibleCustomerID { get; set; }
        public bool IsDisableCustomerID { get; set; }

        public int? CustomerIdentificationID { get; set; }
        public string CustomerIdentification { get; set; }
        public bool IsVisibleCustomerIdentification { get; set; }
        public bool IsDisableCustomerIdentification { get; set; }
    }

    public class WorkInProgressMasterCompanyViewModel
    {
        public int? CompanyID { get; set; }
        public string CompanyName { get; set; }
        public bool IsVisibleCompanyID { get; set; }
        public bool IsDisableCompanyID { get; set; }

        public string CompanyCode { get; set; }
        public bool IsVisibleCompanyCode { get; set; }
        public bool IsDisableCompanyCode { get; set; }
    }
}
