﻿using System.Collections.Generic;
using LITS.Infrastructure.Context;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Model.Views.AutoLoan
{
    public class CreditInitiativeViewModel
    {
        public ApplicationInformationViewModel _applicationInformationViewModel { get; set; }
        public AppliedLoanInformationViewModel _appliedLoanInformationViewModel { get; set; }
        public ApprovalInformationViewModel _approvalInformationViewModel { get; set; }
        public ARTAViewModel _aRTAViewModel { get; set; }
        public CollateralInformationViewModel _collateralInformationViewModel { get; set; }
        public CustomerCreditBureauViewModel _customerCreditBureauViewModel { get; set; }
        public CustomerDemostrationViewModel _customerDemostrationViewModel { get; set; }
        public CustomerIncomeViewModel _customerIncomeViewModel { get; set; }
        public CustomerInformationViewModel _customerInformationViewModel { get; set; }

        #region List Meta Data
        public List<m_product> lst_m_product { get; set; }
        public List<m_program_type> lst_m_program_type { get; set; }
        public List<m_payment_type> lst_m_payment_type { get; set; }
        public List<m_property_sale> lst_m_property_sale { get; set; }
        public List<m_property_status> lst_m_property_status { get; set; }
        public List<m_property_type> lst_m_property_type { get; set; }
        public List<m_status> lst_m_status { get; set; }
        public List<m_trading_area> lst_m_trading_area { get; set; }
        public List<m_type> lst_m_type { get; set; }
        public List<m_branch_code> lst_m_branch_code { get; set; }
        public List<m_branch_location> lst_m_branch_location { get; set; }
        public List<m_loan_purpose> lst_m_loan_purpose { get; set; }
        public List<m_loan_tenor> lst_m_loan_tenor { get; set; }
        public List<m_floating_interest_rate> lst_m_floating_interest_rate { get; set; }
        public List<m_customer_type> lst_m_customer_type { get; set; }
        public List<m_sales_channel> lst_m_sales_channel { get; set; }
        public List<m_customer_segment> lst_m_customer_segment { get; set; }
        public List<m_reason> lst_m_reason_rework { get; set; }
        public List<m_cdd> lst_m_cdd { get; set; }
        #endregion
    }
}
