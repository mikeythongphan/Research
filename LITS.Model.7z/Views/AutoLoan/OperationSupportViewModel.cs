﻿using System.Collections.Generic;
using LITS.Model.Views.Management;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Model.Views.AutoLoan
{
    public class OperationSupportViewModel
    {        
        public ApplicationInformationViewModel _applicationInformationViewModel { get; set; }
        public AppliedLoanInformationViewModel _appliedLoanInformationViewModel { get; set; }        
        public CarDealerInformationViewModel _carDealerInformationViewModel { get; set; }
        public CollateralInformationViewModel _collateralInformationViewModel { get; set; }
        public CustomerCreditBureauViewModel _customerCreditBureauViewModel { get; set; }
        public CustomerDemostrationViewModel _customerDemostrationViewModel { get; set; }
        public CustomerIncomeViewModel _customerIncomeViewModel { get; set; }
        public CustomerInformationViewModel _customerInformationViewModel { get; set; }
        public ARTAViewModel _aRTAViewModel { get; set; }

        #region List MetaData
        public List<ProductViewModel> _ProductViewModel { get; set; }
        public List<ProgramTypeViewModel> _ProgramTypeViewModel { get; set; }
        public List<PaymentTypeViewModel> _PaymentTypeViewModel { get; set; }
        public List<PropertySaleViewModel> _PropertySaleViewModel { get; set; }
        public List<PropertyStatusViewModel> _PropertyStatusViewModel { get; set; }
        public List<PropertyTypeViewModel> _PropertyTypeViewModel { get; set; }
        public List<StatusViewModel> _StatusViewModel { get; set; }
        public List<TradingAreaViewModel> _TradingAreaViewModel { get; set; }
        public List<TypeViewModel> _TypeViewModel { get; set; }
        public List<BranchCodeViewModel> _BranchCodeViewModel { get; set; }
        public List<BranchLocationViewModel> _BranchLocationViewModel { get; set; }
        public List<LoanPurposeViewModel> _LoanPurposeViewModel { get; set; }
        public List<LoanTenorViewModel> _LoanTenorViewModel { get; set; }
        public List<FloatingInterestRateViewModel> _FloatingInterestRateViewModel { get; set; }
        public List<CustomerTypeViewModel> _CustomerTypeViewModel { get; set; }
        public List<SalesChannelViewModel> _SalesChannelViewModel { get; set; }
        public List<CustomerSegmentViewModel> _CustomerSegmentViewModel { get; set; }
        public List<ReasonViewModel> _ReasonViewModel { get; set; }
        public List<CDDViewModel> _CDDViewModel { get; set; }
        #endregion
    }
}
