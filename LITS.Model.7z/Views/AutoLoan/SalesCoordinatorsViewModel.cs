﻿using System.Collections.Generic;
using LITS.Model.Views.Management;
using LITS.Model.Domain.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;

namespace LITS.Model.Views.AutoLoan
{
    public class SalesCoordinatorsViewModel
    {
        private ApplicationInformationViewModel _objApplicationInformationViewModel = new ApplicationInformationViewModel();
        public ApplicationInformationViewModel _ApplicationInformationViewModel
        {
            get
            {
                return _objApplicationInformationViewModel;
            }
            set { _objApplicationInformationViewModel = value; }
        }

        private CustomerInformationViewModel _objCustomerInformationViewModel = new CustomerInformationViewModel();
        public CustomerInformationViewModel _CustomerInformationViewModel
        {
            get
            {
                return _objCustomerInformationViewModel;
            }
            set { _objCustomerInformationViewModel = value; }
        }

        private CustomerIncomeViewModel _objCustomerIncomeViewModel = new CustomerIncomeViewModel();
        public CustomerIncomeViewModel _CustomerIncomeViewModel
        {
            get
            {
                return _objCustomerIncomeViewModel;
            }
            set { _objCustomerIncomeViewModel = value; }
        }

        private CustomerCreditBureauViewModel _objCustomerCreditBureauViewModel = new CustomerCreditBureauViewModel();
        public CustomerCreditBureauViewModel _CustomerCreditBureauViewModel
        {
            get
            {
                return _objCustomerCreditBureauViewModel;
            }
            set { _objCustomerCreditBureauViewModel = value; }
        }

        private CollateralInformationViewModel _objCollateralInformationViewModel = new CollateralInformationViewModel();
        public CollateralInformationViewModel _CollateralInformationViewModel
        {
            get
            {
                return _objCollateralInformationViewModel;
            }
            set { _objCollateralInformationViewModel = value; }
        }

        private AppliedLoanInformationViewModel _objAppliedLoanInformationViewModel = new AppliedLoanInformationViewModel();
        public AppliedLoanInformationViewModel _AppliedLoanInformationViewModel
        {
            get
            {
                return _objAppliedLoanInformationViewModel;
            }
            set { _objAppliedLoanInformationViewModel = value; }
        }

        private CarDealerInformationViewModel _objCarDealerInformationViewModel = new CarDealerInformationViewModel();
        public CarDealerInformationViewModel _CarDealerInformationViewModel
        {
            get
            {
                return _objCarDealerInformationViewModel;
            }
            set { _objCarDealerInformationViewModel = value; }
        }

        private CustomerDemostrationViewModel _objCustomerDemostrationViewModel = new CustomerDemostrationViewModel();
        public CustomerDemostrationViewModel _CustomerDemostrationViewModel
        {
            get
            {
                return _objCustomerDemostrationViewModel;
            }
            set { _objCustomerDemostrationViewModel = value; }
        }

        private ARTAViewModel _objARTAViewModel = new ARTAViewModel();
        public ARTAViewModel _ARTAViewModel
        {
            get
            {
                return _objARTAViewModel;
            }
            set { _objARTAViewModel = value; }
        }

        #region List MetaData
        private List<ProductViewModel> _M_objProductViewModel = new List<ProductViewModel>();
        public List<ProductViewModel> _M_ProductViewModel
        {
            get
            {
                return _M_objProductViewModel;
            }
            set { _M_objProductViewModel = value; }
        }

        private List<ProgramTypeViewModel> _M_objProgramTypeViewModel = new List<ProgramTypeViewModel>();
        public List<ProgramTypeViewModel> _M_ProgramTypeViewModel
        {
            get
            {
                return _M_objProgramTypeViewModel;
            }
            set { _M_objProgramTypeViewModel = value; }
        }

        private List<PaymentTypeViewModel> _M_objPaymentTypeViewModel = new List<PaymentTypeViewModel>();
        public List<PaymentTypeViewModel> _M_PaymentTypeViewModel
        {
            get
            {
                return _M_objPaymentTypeViewModel;
            }
            set { _M_objPaymentTypeViewModel = value; }
        }

        private List<PropertySaleViewModel> _M_objPropertySaleViewModel = new List<PropertySaleViewModel>();
        public List<PropertySaleViewModel> _M_PropertySaleViewModel
        {
            get
            {
                return _M_objPropertySaleViewModel;
            }
            set { _M_objPropertySaleViewModel = value; }
        }

        private List<PropertyStatusViewModel> _M_objPropertyStatusViewModel = new List<PropertyStatusViewModel>();
        public List<PropertyStatusViewModel> _M_PropertyStatusViewModel
        {
            get
            {
                return _M_objPropertyStatusViewModel;
            }
            set { _M_objPropertyStatusViewModel = value; }
        }

        private List<PropertyTypeViewModel> _M_objPropertyTypeViewModel = new List<PropertyTypeViewModel>();
        public List<PropertyTypeViewModel> _M_PropertyTypeViewModel
        {
            get
            {
                return _M_objPropertyTypeViewModel;
            }
            set { _M_objPropertyTypeViewModel = value; }
        }

        private List<StatusViewModel> _M_objStatusViewModel = new List<StatusViewModel>();
        public List<StatusViewModel> _M_StatusViewModel
        {
            get
            {
                return _M_objStatusViewModel;
            }
            set { _M_objStatusViewModel = value; }
        }

        private List<TradingAreaViewModel> _M_objTradingAreaViewModel = new List<TradingAreaViewModel>();
        public List<TradingAreaViewModel> _M_TradingAreaViewModel
        {
            get
            {
                return _M_objTradingAreaViewModel;
            }
            set { _M_objTradingAreaViewModel = value; }
        }

        private List<TypeViewModel> _M_objTypeViewModel = new List<TypeViewModel>();
        public List<TypeViewModel> _M_TypeViewModel
        {
            get
            {
                return _M_objTypeViewModel;
            }
            set { _M_objTypeViewModel = value; }
        }

        private List<BranchCodeViewModel> _M_objBranchCodeViewModel = new List<BranchCodeViewModel>();
        public List<BranchCodeViewModel> _M_BranchCodeViewModel
        {
            get
            {
                return _M_objBranchCodeViewModel;
            }
            set { _M_objBranchCodeViewModel = value; }
        }

        private List<BranchLocationViewModel> _M_objBranchLocationViewModel = new List<BranchLocationViewModel>();
        public List<BranchLocationViewModel> _M_BranchLocationViewModel
        {
            get
            {
                return _M_objBranchLocationViewModel;
            }
            set { _M_objBranchLocationViewModel = value; }
        }

        private List<LoanPurposeViewModel> _M_objLoanPurposeViewModel = new List<LoanPurposeViewModel>();
        public List<LoanPurposeViewModel> _M_LoanPurposeViewModel
        {
            get
            {
                return _M_objLoanPurposeViewModel;
            }
            set { _M_objLoanPurposeViewModel = value; }
        }

        private List<LoanTenorViewModel> _M_objLoanTenorViewModel = new List<LoanTenorViewModel>();
        public List<LoanTenorViewModel> _M_LoanTenorViewModel
        {
            get
            {
                return _M_objLoanTenorViewModel;
            }
            set { _M_objLoanTenorViewModel = value; }
        }

        private List<FloatingInterestRateViewModel> _M_objFloatingInterestRateViewModel = new List<FloatingInterestRateViewModel>();
        public List<FloatingInterestRateViewModel> _M_FloatingInterestRateViewModel
        {
            get
            {
                return _M_objFloatingInterestRateViewModel;
            }
            set { _M_objFloatingInterestRateViewModel = value; }
        }

        private List<CustomerTypeViewModel> _M_objCustomerTypeViewModel = new List<CustomerTypeViewModel>();
        public List<CustomerTypeViewModel> _M_CustomerTypeViewModel
        {
            get
            {
                return _M_objCustomerTypeViewModel;
            }
            set { _M_objCustomerTypeViewModel = value; }
        }

        private List<SalesChannelViewModel> _M_objSalesChannelViewModel = new List<SalesChannelViewModel>();
        public List<SalesChannelViewModel> _M_SalesChannelViewModel
        {
            get
            {
                return _M_objSalesChannelViewModel;
            }
            set { _M_objSalesChannelViewModel = value; }
        }

        private List<CustomerSegmentViewModel> _M_objCustomerSegmentViewModel = new List<CustomerSegmentViewModel>();
        public List<CustomerSegmentViewModel> _M_CustomerSegmentViewModel
        {
            get
            {
                return _M_objCustomerSegmentViewModel;
            }
            set { _M_objCustomerSegmentViewModel = value; }
        }

        private List<ReasonViewModel> _M_objReasonViewModel = new List<ReasonViewModel>();
        public List<ReasonViewModel> _M_ReasonViewModel
        {
            get
            {
                return _M_objReasonViewModel;
            }
            set { _M_objReasonViewModel = value; }
        }

        private List<CDDViewModel> _M_objCDDViewModel = new List<CDDViewModel>();
        public List<CDDViewModel> _M_CDDViewModel
        {
            get
            {
                return _M_objCDDViewModel;
            }
            set { _M_objCDDViewModel = value; }
        }

        private List<CicViewModel> _M_objCicViewModel = new List<CicViewModel>();
        public List<CicViewModel> _M_CicViewModel
        {
            get
            {
                return _M_objCicViewModel;
            }
            set { _M_objCicViewModel = value; }
        }

        private List<CityViewModel> _M_objCityViewModel = new List<CityViewModel>();
        public List<CityViewModel> _M_CityViewModel
        {
            get
            {
                return _M_objCityViewModel;
            }
            set { _M_objCityViewModel = value; }
        }

        private List<CompanyTypeViewModel> _M_objCompanyTypeViewModel = new List<CompanyTypeViewModel>();
        public List<CompanyTypeViewModel> _M_CompanyTypeViewModel
        {
            get
            {
                return _M_objCompanyTypeViewModel;
            }
            set { _M_objCompanyTypeViewModel = value; }
        }

        private List<BusinessNatureViewModel> _M_objBusinessNatureViewModel = new List<BusinessNatureViewModel>();
        public List<BusinessNatureViewModel> _M_BusinessNatureViewModel
        {
            get
            {
                return _M_objBusinessNatureViewModel;
            }
            set { _M_objBusinessNatureViewModel = value; }
        }

        private List<BusinessTypeViewModel> _M_objBusinessTypeViewModel = new List<BusinessTypeViewModel>();
        public List<BusinessTypeViewModel> _M_BusinessTypeViewModel
        {
            get
            {
                return _M_objBusinessTypeViewModel;
            }
            set { _M_objBusinessTypeViewModel = value; }
        }

        private List<BorrowerTypeViewModel> _M_objBorrowerTypeViewModel = new List<BorrowerTypeViewModel>();
        public List<BorrowerTypeViewModel> _M_BorrowerTypeViewModel
        {
            get
            {
                return _M_objBorrowerTypeViewModel;
            }
            set { _M_objBorrowerTypeViewModel = value; }
        }

        private List<IndustryViewModel> _M_objIndustryViewModel = new List<IndustryViewModel>();
        public List<IndustryViewModel> _M_IndustryViewModel
        {
            get
            {
                return _M_objIndustryViewModel;
            }
            set { _M_objIndustryViewModel = value; }
        }

        private List<OccupationViewModel> _M_objOccupationViewModel = new List<OccupationViewModel>();
        public List<OccupationViewModel> _M_OccupationViewModel
        {
            get
            {
                return _M_objOccupationViewModel;
            }
            set { _M_objOccupationViewModel = value; }
        }

        private List<EmploymentTypeViewModel> _M_objEmploymentTypeViewModel = new List<EmploymentTypeViewModel>();
        public List<EmploymentTypeViewModel> _M_EmploymentTypeViewModel
        {
            get
            {
                return _M_objEmploymentTypeViewModel;
            }
            set { _M_objEmploymentTypeViewModel = value; }
        }

        private List<LabourContractTypeViewModel> _M_objLabourContractTypeViewModel = new List<LabourContractTypeViewModel>();
        public List<LabourContractTypeViewModel> _M_LabourContractTypeViewModel
        {
            get
            {
                return _M_objLabourContractTypeViewModel;
            }
            set { _M_objLabourContractTypeViewModel = value; }
        }

        private List<IncomeTypeViewModel> _M_objIncomeTypeViewModel = new List<IncomeTypeViewModel>();
        public List<IncomeTypeViewModel> _M_IncomeTypeViewModel
        {
            get
            {
                return _M_objIncomeTypeViewModel;
            }
            set { _M_objIncomeTypeViewModel = value; }
        }

        private List<CreditBureauTypeViewModel> _M_objCreditBureauTypeViewModel = new List<CreditBureauTypeViewModel>();
        public List<CreditBureauTypeViewModel> _M_CreditBureauTypeViewModel
        {
            get
            {
                return _M_objCreditBureauTypeViewModel;
            }
            set { _M_objCreditBureauTypeViewModel = value; }
        }

        private List<CampaignCodeViewModel> _M_objCampaignCodeViewModel = new List<CampaignCodeViewModel>();
        public List<CampaignCodeViewModel> _M_CampaignCodeViewModel
        {
            get
            {
                return _M_objCampaignCodeViewModel;
            }
            set { _M_objCampaignCodeViewModel = value; }
        }

        private List<CreditDeviationViewModel> _M_objCreditDeviationViewModel = new List<CreditDeviationViewModel>();
        public List<CreditDeviationViewModel> _M_CreditDeviationViewModel
        {
            get
            {
                return _M_objCreditDeviationViewModel;
            }
            set { _M_objCreditDeviationViewModel = value; }
        }

        private List<CustomerRelationshipViewModel> _M_objCustomerRelationshipViewModel = new List<CustomerRelationshipViewModel>();
        public List<CustomerRelationshipViewModel> _M_CustomerRelationshipViewModel
        {
            get
            {
                return _M_objCustomerRelationshipViewModel;
            }
            set { _M_objCustomerRelationshipViewModel = value; }
        }

        private List<NationalityViewModel> _M_objNationalityViewModel = new List<NationalityViewModel>();
        public List<NationalityViewModel> _M_NationalityViewModel
        {
            get
            {
                return _M_objNationalityViewModel;
            }
            set { _M_objNationalityViewModel = value; }
        }

        private List<DistrictViewModel> _M_objDistrictViewModel = new List<DistrictViewModel>();
        public List<DistrictViewModel> _M_DistrictViewModel
        {
            get
            {
                return _M_objDistrictViewModel;
            }
            set { _M_objDistrictViewModel = value; }
        }

        private List<ResidenceOwnershipViewModel> _M_objResidenceOwnershipViewModel = new List<ResidenceOwnershipViewModel>();
        public List<ResidenceOwnershipViewModel> _M_ResidenceOwnershipViewModel
        {
            get
            {
                return _M_objResidenceOwnershipViewModel;
            }
            set { _M_objResidenceOwnershipViewModel = value; }
        }

        private List<MaritalStatusViewModel> _M_objMaritalStatusViewModel = new List<MaritalStatusViewModel>();
        public List<MaritalStatusViewModel> _M_MaritalStatusViewModel
        {
            get
            {
                return _M_objMaritalStatusViewModel;
            }
            set { _M_objMaritalStatusViewModel = value; }
        }

        private List<EducationViewModel> _M_objEducationViewModel = new List<EducationViewModel>();
        public List<EducationViewModel> _M_EducationViewModel
        {
            get
            {
                return _M_objEducationViewModel;
            }
            set { _M_objEducationViewModel = value; }
        }

        private List<CarDealerViewModel> _M_objCarDealerViewModel = new List<CarDealerViewModel>();
        public List<CarDealerViewModel> _M_CarDealerViewModel
        {
            get
            {
                return _M_objCarDealerViewModel;
            }
            set { _M_objCarDealerViewModel = value; }
        }

        private List<CarMarkerBrandViewModel> _M_objCarMarkerBrandViewModel = new List<CarMarkerBrandViewModel>();
        public List<CarMarkerBrandViewModel> _M_CarMarkerBrandViewModel
        {
            get
            {
                return _M_objCarMarkerBrandViewModel;
            }
            set { _M_objCarMarkerBrandViewModel = value; }
        }

        private List<CarModelViewModel> _M_objCarModelViewModel = new List<CarModelViewModel>();
        public List<CarModelViewModel> _M_CarModelViewModel
        {
            get
            {
                return _M_objCarModelViewModel;
            }
            set { _M_objCarModelViewModel = value; }
        }

        private List<CarSourceViewModel> _M_objCarSourceViewModel = new List<CarSourceViewModel>();
        public List<CarSourceViewModel> _M_CarSourceViewModel
        {
            get
            {
                return _M_objCarSourceViewModel;
            }
            set { _M_objCarSourceViewModel = value; }
        }

        private List<CarTypeViewModel> _M_objCarTypeViewModel = new List<CarTypeViewModel>();
        public List<CarTypeViewModel> _M_CarTypeViewModel
        {
            get
            {
                return _M_objCarTypeViewModel;
            }
            set { _M_objCarTypeViewModel = value; }
        }

        private List<PaymentMethodViewModel> _M_objPaymentMethodViewModel = new List<PaymentMethodViewModel>();
        public List<PaymentMethodViewModel> _M_PaymentMethodViewModel
        {
            get
            {
                return _M_objPaymentMethodViewModel;
            }
            set { _M_objPaymentMethodViewModel = value; }
        }

        private List<PaymentOptionViewModel> _M_objPaymentOptionViewModel = new List<PaymentOptionViewModel>();
        public List<PaymentOptionViewModel> _M_PaymentOptionViewModel
        {
            get
            {
                return _M_objPaymentOptionViewModel;
            }
            set { _M_objPaymentOptionViewModel = value; }
        }

        private List<DefinitionTypeViewModel> _M_objCarRepaymentCycle = new List<DefinitionTypeViewModel>();
        public List<DefinitionTypeViewModel> _M_CarRepaymentCycle
        {
            get
            {
                return _M_objCarRepaymentCycle;
            }
            set { _M_objCarRepaymentCycle = value; }
        }

        private List<DefinitionTypeViewModel> _M_objPeriodOfSubmittedBSViewModel = new List<DefinitionTypeViewModel>();
        public List<DefinitionTypeViewModel> _M_PeriodOfSubmittedBSViewModel
        {
            get
            {
                return _M_objPeriodOfSubmittedBSViewModel;
            }
            set { _M_objPeriodOfSubmittedBSViewModel = value; }
        }

        private List<DefinitionTypeViewModel> _M_objHouseRepaymentCycle = new List<DefinitionTypeViewModel>();
        public List<DefinitionTypeViewModel> _M_HouseRepaymentCycle
        {
            get
            {
                return _M_objHouseRepaymentCycle;
            }
            set { _M_objHouseRepaymentCycle = value; }
        }

        private List<CompanyCodeViewModel> _M_objCompanyCodeViewModel = new List<CompanyCodeViewModel>();
        public List<CompanyCodeViewModel> _M_CompanyCodeViewModel
        {
            get
            {
                return _M_objCompanyCodeViewModel;
            }
            set { _M_objCompanyCodeViewModel = value; }
        }

        private List<PositionViewModel> _M_objPositionViewModel = new List<PositionViewModel>();
        public List<PositionViewModel> _M_PositionViewModel
        {
            get
            {
                return _M_objPositionViewModel;
            }
            set { _M_objPositionViewModel = value; }
        }
        #endregion
    }
}
