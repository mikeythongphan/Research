﻿using System.Collections.Generic;
using LITS.Model.Views.Management;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;

namespace LITS.Model.Views.AutoLoan
{
    public class SalesCoordinatorsViewModel
    {
        public ApplicationInformationViewModel _ApplicationInformationViewModel { get; set; }
        public CustomerInformationViewModel _AustomerInformationViewModel { get; set; }
        public CustomerIncomeViewModel _CustomerIncomeViewModel { get; set; }
        public CustomerCreditBureauViewModel _CustomerCreditBureauViewModel { get; set; }
        public CollateralInformationViewModel _CollateralInformationViewModel { get; set; }
        public AppliedLoanInformationViewModel _AppliedLoanInformationViewModel { get; set; }        
        public CarDealerInformationViewModel _CarDealerInformationViewModel { get; set; }
        public CustomerDemostrationViewModel _CustomerDemostrationViewModel { get; set; }
        public ARTAViewModel _ARTAViewModel { get; set; }

        #region List MetaData
        public List<ProductViewModel> _M_ProductViewModel { get; set; }
        public List<ProgramTypeViewModel> _M_ProgramTypeViewModel { get; set; }
        public List<PaymentTypeViewModel> _M_PaymentTypeViewModel { get; set; }
        public List<PropertySaleViewModel> _M_PropertySaleViewModel { get; set; }
        public List<PropertyStatusViewModel> _M_PropertyStatusViewModel { get; set; }
        public List<PropertyTypeViewModel> _M_PropertyTypeViewModel { get; set; }
        public List<StatusViewModel> _M_StatusViewModel { get; set; }
        public List<TradingAreaViewModel> _M_TradingAreaViewModel { get; set; }
        public List<TypeViewModel> _M_TypeViewModel { get; set; }
        public List<BranchCodeViewModel> _M_BranchCodeViewModel { get; set; }
        public List<BranchLocationViewModel> _M_BranchLocationViewModel { get; set; }
        public List<LoanPurposeViewModel> _M_LoanPurposeViewModel { get; set; }
        public List<LoanTenorViewModel> _M_LoanTenorViewModel { get; set; }
        public List<FloatingInterestRateViewModel> _M_FloatingInterestRateViewModel { get; set; }
        public List<CustomerTypeViewModel> _M_CustomerTypeViewModel { get; set; }
        public List<SalesChannelViewModel> _M_SalesChannelViewModel { get; set; }
        public List<CustomerSegmentViewModel> _M_CustomerSegmentViewModel { get; set; }
        public List<ReasonViewModel> _M_ReasonViewModel { get; set; }
        public List<CDDViewModel> _M_CDDViewModel { get; set; }
        public List<CicViewModel> _M_CicViewModel { get; set; }
        public List<CityViewModel> _M_CityViewModel { get; set; }
        public List<CompanyTypeViewModel> _M_CompanyTypeViewModel { get; set; }
        public List<BusinessNatureViewModel> _M_BusinessNatureViewModel { get; set; }
        public List<BusinessTypeViewModel> _M_BusinessTypeViewModel { get; set; }
        public List<BorrowerTypeViewModel> _M_BorrowerTypeViewModel { get; set; }
        public List<IndustryViewModel> _M_IndustryViewModel { get; set; }
        public List<OccupationViewModel> _M_OccupationViewModel { get; set; }
        public List<EmploymentTypeViewModel> _M_EmploymentTypeViewModel { get; set; }
        public List<LabourContractTypeViewModel> _M_LabourContractTypeViewModel { get; set; }
        public List<IncomeTypeViewModel> _M_IncomeTypeViewModel { get; set; }
        public List<CreditBureauTypeViewModel> _M_CreditBureauTypeViewModel { get; set; }
        public List<CampaignCodeViewModel> _M_CampaignCodeViewModel { get; set; }
        public List<CreditDeviationViewModel> _M_CreditDeviationViewModel { get; set; }
        #endregion
    }
}
