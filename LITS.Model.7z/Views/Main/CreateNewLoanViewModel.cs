﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.PartialViews.Main.CreateNewLoan;
using LITS.Model.Views.Management; 

namespace LITS.Model.Views.Main
{
    public class CreateNewLoanViewModel
    {
        public CreateNewLoanStep1ViewModel _CreateNewLoanStep1ViewModel { get; set; }        
        public CreateNewLoanStep2ViewModel _CreateNewLoanStep2ViewModel { get; set; }        
        public CreateNewLoanStep3ViewModel _CreateNewLoanStep3ViewModel { get; set; }

        public List<IdentificationTypeViewModel> _M_IdentificationTypeViewModel { get; set; }
        public List<CompanyTypeViewModel> _M_CompanyTypeViewModel { get; set; }
    }
}
