﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.PartialViews.Main.FRMWorkInProgress;
using LITS.Model.Views.Management;

namespace LITS.Model.Views.Main
{
    public class FRMFRMWorkInProgressViewModel
    {
        public FRMWorkInProgressMasterViewModel _FRMWorkInProgressMasterViewModel { get; set; }
        public List<FRMWorkInProgressDetailViewModel> _FRMWorkInProgressDetailViewModel { get; set; }      
        public List<FRMWorkInProgressTreeViewModel> _FRMWorkInProgressTreeViewModel { get; set; }

        public List<StatusViewModel> _StatusViewModel { get; set; }
        public List<TypeViewModel> _TypeViewModel { get; set; }
    }
}
