﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.PartialViews.Main.ReportsChart;
using LITS.Model.Views.Management;

namespace LITS.Model.Views.Main
{
    public class ReportsChartViewModel
    {
        public ReportsChartMasterViewModel _ReportsChartMasterViewModel { get; set; }
        public List<ReportsChartDetailViewModel> _ReportsChartDetailViewModel { get; set; }
        public List<ReportsChartTreeViewModel> _ReportsChartTreeViewModel { get; set; }

        public List<StatusViewModel> _StatusViewModel { get; set; }
        public List<TypeViewModel> _TypeViewModel { get; set; }
    }
}
