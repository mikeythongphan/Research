﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.PartialViews.Main.SalesCoordinators;

namespace LITS.Model.Views.Main
{
    public class SalesCoordinatorsViewModel
    {
        public List<ApplicationInformationViewModel> applicationInformationViewModel { get; set; }
        public List<CustomerInformationViewModel> customerInformationViewModel { get; set; }
    }
}
