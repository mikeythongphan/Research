﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.PartialViews.Main.WorkInProgress;
using LITS.Model.Views.Management;

namespace LITS.Model.Views.Main
{
    public class WorkInProgressViewModel
    {
        public WorkInProgressMasterViewModel _WorkInProgressMasterViewModel { get; set; }
        public List<WorkInProgressDetailViewModel> _WorkInProgressDetailViewModel { get; set; }
        public List<WorkInProgressDetailChildViewModel> _WorkInProgressDetailChildViewModel { get; set; }
        public List<WorkInProgressTreeViewModel> _WorkInProgressTreeViewModel { get; set; }

        public List<StatusViewModel> lstStatusViewModel { get; set; }
        public List<TypeViewModel> lstTypeViewModel { get; set; }
    }
}