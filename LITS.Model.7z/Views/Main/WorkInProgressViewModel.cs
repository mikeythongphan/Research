﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Model.PartialViews.Main.WorkInProgress;
using LITS.Model.Views.Management;

namespace LITS.Model.Views.Main
{
    public class WorkInProgressViewModel
    {
        private WorkInProgressMasterViewModel _objWorkInProgressMasterViewModel = new WorkInProgressMasterViewModel();
        public WorkInProgressMasterViewModel _WorkInProgressMasterViewModel
        {
            get
            {
                return _objWorkInProgressMasterViewModel;
            }
            set { _objWorkInProgressMasterViewModel = value; }
        }

        private List<WorkInProgressDetailViewModel> _objWorkInProgressDetailViewModel = new List<WorkInProgressDetailViewModel>();
        public List<WorkInProgressDetailViewModel> _WorkInProgressDetailViewModel
        {
            get
            {
                return _objWorkInProgressDetailViewModel;
            }
            set { _objWorkInProgressDetailViewModel = value; }
        }

        private List<WorkInProgressDetailChildViewModel> _objWorkInProgressDetailChildViewModel = new List<WorkInProgressDetailChildViewModel>();
        public List<WorkInProgressDetailChildViewModel> _WorkInProgressDetailChildViewModel
        {
            get
            {
                return _objWorkInProgressDetailChildViewModel;
            }
            set { _objWorkInProgressDetailChildViewModel = value; }
        }

        private List<WorkInProgressTreeViewModel> _objWorkInProgressTreeViewModel = new List<WorkInProgressTreeViewModel>();
        public List<WorkInProgressTreeViewModel> _WorkInProgressTreeViewModel
        {
            get
            {
                return _objWorkInProgressTreeViewModel;
            }
            set { _objWorkInProgressTreeViewModel = value; }
        }

        private List<StatusViewModel> _objStatusViewModel = new List<StatusViewModel>();
        public List<StatusViewModel> lstStatusViewModel
        {
            get
            {
                return _objStatusViewModel;
            }
            set { _objStatusViewModel = value; }
        }

        private List<TypeViewModel> _objTypeViewModel = new List<TypeViewModel>();
        public List<TypeViewModel> lstTypeViewModel
        {
            get
            {
                return _objTypeViewModel;
            }
            set { _objTypeViewModel = value; }
        }
    }
}