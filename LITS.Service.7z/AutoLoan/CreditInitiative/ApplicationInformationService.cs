﻿using System;
using System.Data.Entity;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Service.AutoLoan.CreditInitiative
{
    public class ApplicationInformationService : IApplicationInformationService
    {

        public ApplicationInformationService()
        {
        }

        public void Create(ApplicationInformationViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        application_information data = AutoMapper.Mapper.Map<ApplicationInformationViewModel, application_information>(sc);

                        context.application_information.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public void Delete(ApplicationInformationViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<ApplicationInformationViewModel, application_information>(obj);
                            context.application_information.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        public ApplicationInformationViewModel GetAll()
        {
            throw new NotImplementedException();
        }

        public application_information GetApplicationInformation(int Id)
        {
            throw new NotImplementedException();
        }

        public ApplicationInformationViewModel GetById(int Id)
        {
            ApplicationInformationViewModel obj = new ApplicationInformationViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.application_information.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<application_information, ApplicationInformationViewModel>(data);
            return obj;
        }

        public void Update(ApplicationInformationViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<ApplicationInformationViewModel, application_information>(obj);
                        context.application_information.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
