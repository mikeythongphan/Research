﻿using System;
using System.Data.Entity;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Service.AutoLoan.CreditInitiative
{
    public class AppliedLoanInformationService : IAppliedLoanInformationService
    {
        public AppliedLoanInformationService()
        {
        }

        public void Create(AppliedLoanInformationViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        al_personal_application data = AutoMapper.Mapper.Map<AppliedLoanInformationViewModel, al_personal_application>(sc);

                        context.al_personal_application.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public void Delete(AppliedLoanInformationViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<AppliedLoanInformationViewModel, al_personal_application>(obj);
                            context.al_personal_application.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        public AppliedLoanInformationViewModel GetAll()
        {
            throw new NotImplementedException();
        }

        public al_personal_application GetApplicationInformation(int? Id)
        {
            throw new NotImplementedException();
        }

        public AppliedLoanInformationViewModel GetById(int? Id)
        {
            AppliedLoanInformationViewModel obj = new AppliedLoanInformationViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.al_personal_application.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<al_personal_application, AppliedLoanInformationViewModel>(data);
            return obj;
        }

        public void Update(AppliedLoanInformationViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<AppliedLoanInformationViewModel, al_personal_application>(obj);
                        context.al_personal_application.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
