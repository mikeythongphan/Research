﻿using System;
using System.Data.Entity;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Service.AutoLoan.CreditInitiative
{
    public class CollateralInformationService : ICollateralInformationService
    {
        public CollateralInformationService()
        {
        }

        public void Create(CollateralInformationViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        approval_information data = AutoMapper.Mapper.Map<CollateralInformationViewModel, approval_information>(sc);
                        context.approval_information.Add(data);
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public void Delete(CollateralInformationViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<CollateralInformationViewModel, approval_information>(obj);
                            context.approval_information.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        public CollateralInformationViewModel GetAll()
        {
            throw new NotImplementedException();
        }


        public CollateralInformationViewModel GetById(int Id)
        {
            CollateralInformationViewModel obj = new CollateralInformationViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.approval_information.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<approval_information, CollateralInformationViewModel>(data);
            return obj;
        }

        public void Update(CollateralInformationViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<CollateralInformationViewModel, approval_information>(obj);
                        context.approval_information.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
