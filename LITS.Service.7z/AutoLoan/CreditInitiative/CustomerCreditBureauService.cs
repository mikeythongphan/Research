﻿using System;
using System.Data.Entity;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Service.AutoLoan.CreditInitiative
{
    public class CustomerCreditBureauService : ICustomerCreditBureauService
    {
        public CustomerCreditBureauService()
        {
        }

        public void Create(CustomerCreditBureauViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        al_customer_credit_bureau data = AutoMapper.Mapper.Map<CustomerCreditBureauViewModel, al_customer_credit_bureau>(sc);
                        context.al_customer_credit_bureau.Add(data);
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public void Delete(CustomerCreditBureauViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            //obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<CustomerCreditBureauViewModel, al_customer_credit_bureau>(obj);
                            context.al_customer_credit_bureau.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        public CustomerCreditBureauViewModel GetAll()
        {
            throw new NotImplementedException();
        }


        public CustomerCreditBureauViewModel GetById(int Id)
        {
            CustomerCreditBureauViewModel obj = new CustomerCreditBureauViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.al_customer_credit_bureau.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<al_customer_credit_bureau, CustomerCreditBureauViewModel>(data);
            return obj;
        }

        public void Update(CustomerCreditBureauViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<CustomerCreditBureauViewModel, al_customer_credit_bureau>(obj);
                        context.al_customer_credit_bureau.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
