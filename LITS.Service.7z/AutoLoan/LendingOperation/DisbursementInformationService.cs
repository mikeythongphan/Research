﻿using System;
using System.Data.Entity;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.LendingOperation;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;

namespace LITS.Service.AutoLoan.LendingOperation
{
    public class DisbursementInformationService : IDisbursementInformationService
    {
        public void Create(DisbursementInformationViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        disbursement_information data = AutoMapper.Mapper.Map<DisbursementInformationViewModel, disbursement_information>(sc);

                        context.disbursement_information.Add(data);
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        public void Delete(DisbursementInformationViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<DisbursementInformationViewModel, disbursement_information>(obj);
                            context.disbursement_information.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        public DisbursementInformationViewModel GetAll()
        {
            throw new NotImplementedException();
        }

        public DisbursementInformationViewModel GetById(int Id)
        {
            DisbursementInformationViewModel obj = new DisbursementInformationViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.disbursement_information.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<disbursement_information, DisbursementInformationViewModel>(data);
            return obj;
        }

        public void Update(DisbursementInformationViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<DisbursementInformationViewModel, disbursement_information>(obj);

                        context.disbursement_information.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
    }
}
