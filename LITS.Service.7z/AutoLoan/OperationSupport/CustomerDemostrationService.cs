﻿using System;
using System.Linq;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.AutoLoan.OperationSupport;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using System.Data.Entity;

namespace LITS.Service.AutoLoan.OperationSupport
{
    public class CustomerDemostrationService : ICustomerDemostrationService
    {
        public CustomerDemostrationService()
        {
        }

        #region ApplicationInformationService Members
        /// <summary>
        /// Application Information ViewModel
        /// </summary>
        /// <param name="Id">int</param>
        public CustomerDemostrationViewModel GetById(int Id)
        {
            CustomerDemostrationViewModel obj = new CustomerDemostrationViewModel();
            LITSEntities entities = new LITSEntities();
            var data = entities.al_wealth_demonstration.FirstOrDefault(p => p.pk_id == Id);
            obj = AutoMapper.Mapper.Map<al_wealth_demonstration, CustomerDemostrationViewModel>(data);
            return obj;
        }
        /// <summary>
        /// GetAll
        /// </summary>
        /// <returns></returns>
        public CustomerDemostrationViewModel GetAll()
        {
            CustomerDemostrationViewModel obj = new CustomerDemostrationViewModel();
            return obj;
        }

        /// <summary>
        /// Create
        /// </summary>
        /// <param name="sc">ApplicationInformationViewModel</param>
        public void Create(CustomerDemostrationViewModel sc)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        al_wealth_demonstration data = AutoMapper.Mapper.Map<CustomerDemostrationViewModel, al_wealth_demonstration>(sc);
                        context.al_wealth_demonstration.Add(data);
                        context.SaveChanges();
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="obj">ApplicationInformationViewModel</param>
        public void Update(CustomerDemostrationViewModel obj)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var data = AutoMapper.Mapper.Map<CustomerDemostrationViewModel, al_wealth_demonstration>(obj);

                        context.al_wealth_demonstration.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="id">int</param>
        public void Delete(CustomerDemostrationViewModel obj)
        {
            if (obj != null)
            {
                using (var context = new LITSEntities())
                {
                    using (DbContextTransaction transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            obj.IsActive = false;
                            var data = AutoMapper.Mapper.Map<CustomerDemostrationViewModel, al_wealth_demonstration>(obj);
                            context.al_wealth_demonstration.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Save
        /// </summary>
        public void Save()
        { }

        #endregion
    }
}
