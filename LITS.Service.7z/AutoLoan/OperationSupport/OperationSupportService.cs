﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#region Infrastructure
using LITS.Infrastructure.Factory;
#endregion

#region Interface
using LITS.Interface.Service.AutoLoan.OperationSupport;
using LITS.Interface.Repository.AutoLoan.OperationSupport;
using LITS.Interface.Repository.Management;
#endregion

#region Model
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
#endregion

namespace LITS.Service.AutoLoan.OperationSupport
{
    public class OperationSupportService : IOperationSupportService
    {
        #region SalesCoordinators
        private readonly IOperationSupportRepository _OperationSupportRepository;
        private readonly IApplicationInformationRepository _ApplicationInformationRepository;
        private readonly IAppliedLoanInformationRepository _AppliedLoanInformationRepository;
        private readonly IARTARepository _ARTARepository;
        private readonly ICarDealerInformationRepository _CarDealerInformationRepository;
        private readonly ICollateralInformationRepository _CollateralInformationRepository;
        private readonly ICustomerInformationRepository _CustomerInformationRepository;
        private readonly ICustomerCreditBureauRepository _CustomerCreditBureauRepository;
        private readonly ICustomerDemostrationRepository _CustomerDemostrationRepository;
        private readonly ICustomerIncomeRepository _CustomerIncomeRepository;
        #endregion

        #region MetaData
        private readonly IBranchCodeRepository _BranchCodeRepository;
        private readonly IBranchLocationRepository _BranchLocationRepository;
        private readonly ICustomerTypeRepository _CustomerTypeRepository;
        private readonly IFloatingInterestRateRepository _FloatingInterestRateRepository;
        private readonly ILoanPurposeRepository _LoanPurposeRepository;
        private readonly ILoanTenorRepository _LoanTenorRepository;
        private readonly IPaymentTypeRepository _PaymentTypeRepository;
        private readonly IProductTypeRepository _ProductTypeRepository;
        private readonly IProductRepository _ProductRepository;
        private readonly IProgramTypeRepository _ProgramTypeRepository;
        private readonly IPropertySaleRepository _PropertySaleRepository;
        private readonly IPropertyStatusRepository _PropertyStatusRepository;
        private readonly IPropertyTypeRepository _PropertyTypeRepository;
        private readonly ITradingAreaRepository _TradingAreaRepository;
        private readonly IIncomeTypeRepository _IncomeTypeRepository;
        private readonly ISalesChannelRepository _SalesChannelRepository;
        private readonly ICustomerSegmentRepository _CustomerSegmentRepository;
        private readonly ICustomerRelationshipRepository _CustomerRelationshipRepository;
        private readonly ICDDRepository _CDDRepository;
        private readonly ICICRepository _CICRepository;
        private readonly IReasonRepository _ReasonRepository;
        private readonly IStatusRepository _StatusRepository;
        private readonly ITypeRepository _TypeRepository;
        #endregion

        private readonly IUnitOfWork _unitOfWork;

        public OperationSupportService(IOperationSupportRepository OperationSupportRepository,
            IApplicationInformationRepository ApplicationInformationRepository,
            IAppliedLoanInformationRepository AppliedLoanInformationRepository,
            IARTARepository ARTARepository,
            ICarDealerInformationRepository CarDealerInformationRepository,
            ICollateralInformationRepository CollateralInformationRepository,
            ICustomerInformationRepository CustomerInformationRepository,
            ICustomerCreditBureauRepository CustomerCreditBureauRepository,
            ICustomerDemostrationRepository CustomerDemostrationRepository,
            ICustomerIncomeRepository CustomerIncomeRepository,
            IBranchCodeRepository BranchCodeRepository,
            IBranchLocationRepository BranchLocationRepository,
            ICustomerTypeRepository CustomerTypeRepository,
            IFloatingInterestRateRepository FloatingInterestRateRepository,
            ILoanPurposeRepository LoanPurposeRepository,
            ILoanTenorRepository LoanTenorRepository,
            IPaymentTypeRepository PaymentTypeRepository,
            IProductTypeRepository ProductTypeRepository,
            IProductRepository ProductRepository,
            IProgramTypeRepository ProgramTypeRepository,
            IPropertySaleRepository PropertySaleRepository,
            IPropertyStatusRepository PropertyStatusRepository,
            IPropertyTypeRepository PropertyTypeRepository,
            ITradingAreaRepository TradingAreaRepository,
            IIncomeTypeRepository IncomeTypeRepository,
            ISalesChannelRepository SalesChannelRepository,
            ICustomerSegmentRepository CustomerSegmentRepository,
            ICustomerRelationshipRepository CustomerRelationshipRepository,
            ICDDRepository CDDRepository,
            ICICRepository CICRepository,
            IReasonRepository ReasonRepository,
            IStatusRepository StatusRepository,
            ITypeRepository TypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._OperationSupportRepository = OperationSupportRepository;
            this._ApplicationInformationRepository = ApplicationInformationRepository;
            this._AppliedLoanInformationRepository = AppliedLoanInformationRepository;
            this._ARTARepository = ARTARepository;
            this._CarDealerInformationRepository = CarDealerInformationRepository;
            this._CollateralInformationRepository = CollateralInformationRepository;
            this._CustomerInformationRepository = CustomerInformationRepository;
            this._CustomerCreditBureauRepository = CustomerCreditBureauRepository;
            this._CustomerDemostrationRepository = CustomerDemostrationRepository;
            this._CustomerIncomeRepository = CustomerIncomeRepository;
            this._BranchCodeRepository = BranchCodeRepository;
            this._BranchLocationRepository = BranchLocationRepository;
            this._CustomerTypeRepository = CustomerTypeRepository;
            this._FloatingInterestRateRepository = FloatingInterestRateRepository;
            this._LoanPurposeRepository = LoanPurposeRepository;
            this._LoanTenorRepository = LoanTenorRepository;
            this._PaymentTypeRepository = PaymentTypeRepository;
            this._ProductTypeRepository = ProductTypeRepository;
            this._ProductRepository = ProductRepository;
            this._ProgramTypeRepository = ProgramTypeRepository;
            this._PropertySaleRepository = PropertySaleRepository;
            this._PropertyStatusRepository = PropertyStatusRepository;
            this._PropertyTypeRepository = PropertyTypeRepository;
            this._TradingAreaRepository = TradingAreaRepository;
            this._IncomeTypeRepository = IncomeTypeRepository;
            this._SalesChannelRepository = SalesChannelRepository;
            this._CustomerSegmentRepository = CustomerSegmentRepository;
            this._CustomerRelationshipRepository = CustomerRelationshipRepository;
            this._CDDRepository = CDDRepository;
            this._CICRepository = CICRepository;
            this._ReasonRepository = ReasonRepository;
            this._StatusRepository = StatusRepository;
            this._TypeRepository = TypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public OperationSupportViewModel LoadIndex(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            #region ConfigControl
            //objParam = VisibleControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            //objParam = ReadonlyControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            #endregion

            #region MetaData
            objParam._M_BranchCodeViewModel = _BranchCodeRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_BranchLocationViewModel = _BranchLocationRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerTypeViewModel = _CustomerTypeRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_FloatingInterestRateViewModel = _FloatingInterestRateRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_LoanPurposeViewModel = _LoanPurposeRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_LoanTenorViewModel = _LoanTenorRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PaymentTypeViewModel = _PaymentTypeRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_ProductViewModel = _ProductRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_ProgramTypeViewModel = _ProgramTypeRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PropertySaleViewModel = _PropertySaleRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PropertyStatusViewModel = _PropertyStatusRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_PropertyTypeViewModel = _PropertyTypeRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_TradingAreaViewModel = _TradingAreaRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_StatusViewModel = _StatusRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_TypeViewModel = _TypeRepository.GetListActiveById((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_SalesChannelViewModel = _SalesChannelRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CustomerSegmentViewModel = _CustomerSegmentRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_ReasonViewModel = _ReasonRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            objParam._M_CDDViewModel = _CDDRepository.GetListActiveByTypeId((int)objParam._ApplicationInformationViewModel.ApplicationTypeID);
            #endregion

            return objParam;
        }

        public OperationSupportViewModel Save(OperationSupportViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// Visible Control
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public SalesCoordinatorsViewModel VisibleControl(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            switch (ControllerNameParam)
            {
                case "SCMaker":
                    {
                        #region ApplicationInformation
                        objParam._ApplicationInformationViewModel.IsVisibleApplicationDuplication = true;
                        objParam._ApplicationInformationViewModel.IsVisibleApplicationNo = true;
                        objParam._ApplicationInformationViewModel.IsVisibleApplicationStatus = true;
                        objParam._ApplicationInformationViewModel.IsVisibleApplicationType = true;
                        objParam._ApplicationInformationViewModel.IsVisibleARMCode = true;
                        objParam._ApplicationInformationViewModel.IsVisibleBlackList = true;
                        objParam._ApplicationInformationViewModel.IsVisibleBranchCode = true;
                        objParam._ApplicationInformationViewModel.IsVisibleBranchLocation = true;
                        objParam._ApplicationInformationViewModel.IsVisibleCDD = true;
                        objParam._ApplicationInformationViewModel.IsVisibleChannel = true;
                        objParam._ApplicationInformationViewModel.IsVisibleCustomerSegment = true;
                        objParam._ApplicationInformationViewModel.IsVisibleCustomerType = true;
                        objParam._ApplicationInformationViewModel.IsVisibleEOpsTxnReference = true;
                        objParam._ApplicationInformationViewModel.IsVisibleExisting = true;
                        objParam._ApplicationInformationViewModel.IsVisibleExpectingDisbursedDate = true;
                        objParam._ApplicationInformationViewModel.IsVisibleHardCopyApplicationDate = true;
                        objParam._ApplicationInformationViewModel.IsVisibleICT = true;
                        objParam._ApplicationInformationViewModel.IsVisiblePeoplewiseIDofSaleStaf = true;
                        objParam._ApplicationInformationViewModel.IsVisibleProductType = true;
                        objParam._ApplicationInformationViewModel.IsVisibleProgramType = true;
                        objParam._ApplicationInformationViewModel.IsVisibleReasonForRework = true;
                        objParam._ApplicationInformationViewModel.IsVisibleReceivingDate = true;
                        objParam._ApplicationInformationViewModel.IsVisibleRework = true;
                        objParam._ApplicationInformationViewModel.IsVisibleSalesCode = true;
                        objParam._ApplicationInformationViewModel.IsVisibleSaleTMPWID = true;
                        objParam._ApplicationInformationViewModel.IsVisibleStafNonStaf = true;
                        objParam._ApplicationInformationViewModel.IsVisibleTradingArea = true;
                        #endregion

                        #region CustomerInformation                        
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleApplicationType = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleBillingAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleCurrentResidentalAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleCurrentResidentalAddressCity = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleCurrentResidentalAddressDistrict = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleCurrentResidentalAddressWard = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleCustomerSCRelationship = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleDOB = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleEducationLevel = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleEmailAddress1 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleEmailAddress2 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleEmploymentBusinessTerm = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleFullName = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleHomePhoneNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleIdentification = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleIntitial = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleMaritalStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleMobileNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleNationality = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleNumberOfDependants = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisiblePermanentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisiblePermanentAddressCity = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisiblePermanentAddressDistrict = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisiblePermanentAddressWard = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleTimeAtCurrentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co1.IsVisibleTypeOfResidenceOwnership = true;

                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleApplicationType = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleBillingAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleCurrentResidentalAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleCurrentResidentalAddressCity = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleCurrentResidentalAddressDistrict = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleCurrentResidentalAddressWard = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleCustomerSCRelationship = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleDOB = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleEducationLevel = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleEmailAddress1 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleEmailAddress2 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleEmploymentBusinessTerm = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleFullName = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleHomePhoneNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleIdentification = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleIntitial = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleMaritalStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleMobileNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleNationality = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleNumberOfDependants = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisiblePermanentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisiblePermanentAddressCity = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisiblePermanentAddressDistrict = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisiblePermanentAddressWard = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleTimeAtCurrentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co2.IsVisibleTypeOfResidenceOwnership = true;

                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleApplicationType = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleBillingAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleCurrentResidentalAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleCurrentResidentalAddressCity = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleCurrentResidentalAddressDistrict = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleCurrentResidentalAddressWard = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleCustomerSCRelationship = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleDOB = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleEducationLevel = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleEmailAddress1 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleEmailAddress2 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleEmploymentBusinessTerm = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleFullName = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleHomePhoneNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleIdentification = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleIntitial = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleMaritalStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleMobileNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleNationality = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleNumberOfDependants = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisiblePermanentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisiblePermanentAddressCity = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisiblePermanentAddressDistrict = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisiblePermanentAddressWard = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleTimeAtCurrentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Co3.IsVisibleTypeOfResidenceOwnership = true;

                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleApplicationType = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleBillingAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleCurrentResidentalAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleCurrentResidentalAddressCity = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleCurrentResidentalAddressDistrict = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleCurrentResidentalAddressWard = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleCustomerSCRelationship = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleDOB = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleEducationLevel = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleEmailAddress1 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleEmailAddress2 = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleEmploymentBusinessTerm = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleFullName = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleHomePhoneNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleIdentification = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleIntitial = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleMaritalStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleMobileNo = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleNationality = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleNumberOfDependants = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisiblePermanentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisiblePermanentAddressCity = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisiblePermanentAddressDistrict = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisiblePermanentAddressWard = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleStatus = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleTimeAtCurrentAddress = true;
                        objParam._CustomerInformationViewModel._CustomerDetailViewModel_Main.IsVisibleTypeOfResidenceOwnership = true;
                        #endregion

                        #region CustomerIncome

                        #endregion

                        #region AppliedLoanInformation
                        objParam._AppliedLoanInformationViewModel.IsVisibleAmountRequested = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleApplicationStatus = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleApplicationType = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleCampaignCode = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleCreditDeviation = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleFloatingInterestRate = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleLoanPurpose = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleLTV = true;
                        objParam._AppliedLoanInformationViewModel.IsVisiblePaymentType = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleProgramType = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleReasonForDeviation = true;
                        objParam._AppliedLoanInformationViewModel.IsVisibleTenors = true;
                        #endregion

                        #region ARTA
                        objParam._ARTAViewModel.IsVisibleApplicationNumber = true;
                        objParam._ARTAViewModel.IsVisibleApplicationStatus = true;
                        objParam._ARTAViewModel.IsVisibleApplicationType = true;
                        objParam._ARTAViewModel.IsVisibleAppliedPremium = true;
                        objParam._ARTAViewModel.IsVisibleAppliedSumAssured = true;
                        objParam._ARTAViewModel.IsVisibleARTA = true;
                        objParam._ARTAViewModel.IsVisibleLifeAssured = true;
                        objParam._ARTAViewModel.IsVisiblePaymentOption = true;
                        #endregion

                        #region CarDealerInformation
                        objParam._CarDealerInformationViewModel.IsVisibleApplicationStatus = true;
                        objParam._CarDealerInformationViewModel.IsVisibleApplicationType = true;
                        objParam._CarDealerInformationViewModel.IsVisibleCarDealerAddress = true;
                        objParam._CarDealerInformationViewModel.IsVisibleCarDealerCity = true;
                        objParam._CarDealerInformationViewModel.IsVisibleCarDealerDistrict = true;
                        objParam._CarDealerInformationViewModel.IsVisibleCarDealerILCap = true;
                        objParam._CarDealerInformationViewModel.IsVisibleCarDealerName = true;
                        objParam._CarDealerInformationViewModel.IsVisibleCarDealerPromissoryDisbursementAvailableLimit = true;
                        objParam._CarDealerInformationViewModel.IsVisibleCarDealerPromissoryDisbursementCap = true;
                        objParam._CarDealerInformationViewModel.IsVisibleCarDealerTotalDisbursement = true;
                        objParam._CarDealerInformationViewModel.IsVisibleCarDealerWards = true;
                        objParam._CarDealerInformationViewModel.IsVisibleCooperationContractActive = true;
                        #endregion

                        #region CollateralInformation
                        objParam._CollateralInformationViewModel.IsVisibleApplicationStatus = true;
                        objParam._CollateralInformationViewModel.IsVisibleApplicationType = true;
                        objParam._CollateralInformationViewModel.IsVisibleCarMarkerBrand = true;
                        objParam._CollateralInformationViewModel.IsVisibleCarSource = true;
                        objParam._CollateralInformationViewModel.IsVisibleCarType = true;
                        objParam._CollateralInformationViewModel.IsVisibleChassisNumber = true;
                        objParam._CollateralInformationViewModel.IsVisibleCollateralValue = true;
                        objParam._CollateralInformationViewModel.IsVisibleColor = true;
                        objParam._CollateralInformationViewModel.IsVisibleModel = true;
                        objParam._CollateralInformationViewModel.IsVisibleNumberOfSeats = true;
                        objParam._CollateralInformationViewModel.IsVisiblePropertyStatus = true;
                        objParam._CollateralInformationViewModel.IsVisiblePurchasingPriceOrFairMarketValue = true;
                        objParam._CollateralInformationViewModel.IsVisiblePurchasingSPContractNumber = true;
                        objParam._CollateralInformationViewModel.IsVisibleYearOfManufacture = true; ;
                        #endregion

                        #region CustomerCreditBureau
                        objParam._CustomerCreditBureauViewModel.IsVisibleTotalCurrentMonthlyIndividualObligationRepayment = true;

                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleApplicationType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleBureauDataCardCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleBureauDataCardHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleBureauDataLoanCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleBureauDataLoanHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCard = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCreditBureauType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCurrentCardUtilization = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCurrentTotalEMIOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCurrentTotalEMIOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCurrentUnsecuredOutstandingOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCurrentUnsecuredOutstandingOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleCurrentUnsecureLimitOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleLoan = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleTotalLimitCreditCard = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co1.IsVisibleTotalOutStandingBalanceCreditCard = true;

                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleApplicationType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleBureauDataCardCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleBureauDataCardHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleBureauDataLoanCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleBureauDataLoanHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCard = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCreditBureauType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCurrentCardUtilization = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCurrentTotalEMIOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCurrentTotalEMIOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCurrentUnsecuredOutstandingOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCurrentUnsecuredOutstandingOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleCurrentUnsecureLimitOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleLoan = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleTotalLimitCreditCard = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co2.IsVisibleTotalOutStandingBalanceCreditCard = true;

                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleApplicationType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleBureauDataCardCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleBureauDataCardHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleBureauDataLoanCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleBureauDataLoanHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCard = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCreditBureauType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCurrentCardUtilization = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCurrentTotalEMIOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCurrentTotalEMIOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCurrentUnsecuredOutstandingOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCurrentUnsecuredOutstandingOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleCurrentUnsecureLimitOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleLoan = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleTotalLimitCreditCard = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Co3.IsVisibleTotalOutStandingBalanceCreditCard = true;

                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleApplicationType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleBureauDataCardCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleBureauDataCardHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleBureauDataLoanCurrent = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleBureauDataLoanHistory = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCard = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCreditBureauType = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCurrentCardUtilization = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCurrentTotalEMIOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCurrentTotalEMIOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCurrentUnsecuredOutstandingOfUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCurrentUnsecuredOutstandingOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleCurrentUnsecureLimitOnUs = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleLoan = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleTotalBorrowerCurrentMonthlyIndividualObligationRepayment = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleTotalLimitCreditCard = true;
                        objParam._CustomerCreditBureauViewModel._CustomerCreditBureauDetailViewModel_Main.IsVisibleTotalOutStandingBalanceCreditCard = true;
                        #endregion

                        #region CustomerDemostration
                        objParam._CustomerDemostrationViewModel.IsVisibleApplicationStatus = true;
                        objParam._CustomerDemostrationViewModel.IsVisibleApplicationType = true;
                        objParam._CustomerDemostrationViewModel.IsVisibleMonthlyExpenditure = true;
                        objParam._CustomerDemostrationViewModel.IsVisibleOtherAsset = true;
                        objParam._CustomerDemostrationViewModel.IsVisibleTotalCarOwned = true;
                        objParam._CustomerDemostrationViewModel.IsVisibleTotalFDvalue = true;
                        objParam._CustomerDemostrationViewModel.IsVisibleTotalPropertyOwned = true;
                        #endregion

                        break;
                    }
                case "SCChecker":
                    {

                        break;
                    }
                case "SCMaster":
                    {

                        break;
                    }
                case "SCViewer":
                    {

                        break;
                    }
                default:
                    {
                        break;
                    }
            }

            return objParam;
        }

        /// <summary>
        /// Readonly Control
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public SalesCoordinatorsViewModel ReadonlyControl(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            switch (ControllerNameParam)
            {
                case "SCMaker":
                    {
                        #region CreateNewLoanStep1

                        #endregion

                        #region CreateNewLoanStep2

                        #endregion

                        #region CreateNewLoanStep3

                        #endregion

                        break;
                    }
                case "SCChecker":
                    {

                        break;
                    }
                case "SCMaster":
                    {

                        break;
                    }
                case "SCViewer":
                    {

                        break;
                    }
                default:
                    {
                        break;
                    }
            }

            return objParam;
        }
    }
}
