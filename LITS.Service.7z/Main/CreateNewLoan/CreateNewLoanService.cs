﻿using System;

using LITS.Core.Resources;

using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

using LITS.Interface.Service.Main.CreateNewLoan;
using LITS.Interface.Service.Management;
using LITS.Interface.Repository.Main.CreateNewLoan;
using LITS.Interface.Repository.Management;

using LITS.Model.PartialViews.Main.CreateNewLoan;
using LITS.Model.Views.Main;
using LITS.Model.Views.Management;

namespace LITS.Service.Main.CreateNewLoan
{
    public class CreateNewLoanService : ICreateNewLoanService
    {
        private readonly ICreateNewLoanRepository _CreateNewLoanRepository;

        private readonly ICreateNewLoanStep1Repository _CreateNewLoanStep1Repository;
        private readonly ICreateNewLoanStep2Repository _CreateNewLoanStep2Repository;
        private readonly ICreateNewLoanStep3Repository _CreateNewLoanStep3Repository;

        private readonly IIdentificationTypeRepository _IdentificationTypeRepository;
        private readonly ICompanyTypeRepository _CompanyTypeRepository;
        private readonly IDefinitionTypeRepository _DefinitionTypeRepository;
        private readonly IDistrictRepository _DistrictRepository;
        private readonly ICityRepository _CityRepository;
        private readonly INationalityRepository _NationalityRepository;
        private readonly ICustomerRelationshipRepository _CustomerRelationshipRepository;
        private readonly ITypeRepository _TypeRepository;

        private LITSEntities _LITSEntities;

        private readonly IUnitOfWork _unitOfWork;

        public CreateNewLoanService(ICreateNewLoanRepository createNewLoanRepository,
            ICreateNewLoanStep1Repository createNewLoanStep1Repository,
            ICreateNewLoanStep2Repository createNewLoanStep2Repository,
            ICreateNewLoanStep3Repository createNewLoanStep3Repository,
            IIdentificationTypeRepository IdentificationTypeRepository,
            ICompanyTypeRepository CompanyTypeRepository,
            ICityRepository CityRepository,
            IDistrictRepository DistrictRepository,
            IDefinitionTypeRepository DefinitionTypeRepository,
            INationalityRepository NationalityRepository,
            ICustomerRelationshipRepository CustomerRelationshipRepository,
            ITypeRepository TypeRepository,
            IUnitOfWork unitOfWork,
            LITSEntities litsEntities)
        {
            this._CreateNewLoanRepository = createNewLoanRepository;
            this._CreateNewLoanStep1Repository = createNewLoanStep1Repository;
            this._CreateNewLoanStep2Repository = createNewLoanStep2Repository;
            this._CreateNewLoanStep3Repository = createNewLoanStep3Repository;
            this._IdentificationTypeRepository = IdentificationTypeRepository;
            this._CompanyTypeRepository = CompanyTypeRepository;
            this._CityRepository = CityRepository;
            this._DistrictRepository = DistrictRepository;
            this._NationalityRepository = NationalityRepository;
            this._DefinitionTypeRepository = DefinitionTypeRepository;
            this._CustomerRelationshipRepository = CustomerRelationshipRepository;
            this._TypeRepository = TypeRepository;
            this._unitOfWork = unitOfWork;
            this._LITSEntities = litsEntities;
        }

        /// <summary>
        /// LoadIndexStep1
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="strAreaName"></param>
        /// <param name="strControllerName"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep1(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam = VisibleControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = ReadonlyControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = LoadMetaDataStep1(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

            return _CreateNewLoanRepository.LoadIndexStep1(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// LoadIndexStep2
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="strAreaName"></param>
        /// <param name="strControllerName"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep2(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam = VisibleControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = ReadonlyControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = LoadMetaDataStep2(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

            return _CreateNewLoanRepository.LoadIndexStep2(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// LoadIndexStep3
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="strAreaName"></param>
        /// <param name="strControllerName"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep3(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam = VisibleControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = ReadonlyControl(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = LoadMetaDataStep3(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

            return _CreateNewLoanRepository.LoadIndexStep3(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam); ;
        }

        /// <summary>
        /// Submit
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="strAreaName"></param>
        /// <param name="strControllerName"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel Submit(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam = _CreateNewLoanRepository.Submit(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

            _unitOfWork.Commit();

            return LoadIndexStep3(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
        }

        /// <summary>
        /// Visible Control
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel VisibleControl(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            switch (ControllerNameParam)
            {
                case "CreateNewLoanMaker":
                    {
                        #region CreateNewLoanStep1
                        objParam._CreateNewLoanStep1ViewModel.IsVisibleApplicationTypeID = true;
                        objParam._CreateNewLoanStep1ViewModel.IsVisibleProductTypeID = true;
                        objParam._CreateNewLoanStep1ViewModel.IsVisibleCreateNewLoanStep1Tree = true;
                        #endregion

                        #region CreateNewLoanStep2
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleApplication = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleApplicationStatus = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleApplicationTypeID = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleBusinessRegistrationNumber = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyAddress = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCAT = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCity = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCode = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCodeRLS = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyDistrict = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyEmail = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyName = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyPhone = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyRemark = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyType = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyWard = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerSCRelationship = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleIntitial = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleLegalLegalRepresentativeNationality = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleLegalRepresentative = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleLegalRepresentativeDateOfBirth = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleProductTypeID = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleTaxNumber = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationLegalRepresentative = true;
                        #endregion

                        #region CreateNewLoanStep3
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleApplicationNo = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleApplicationTypeID = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleProductTypeID = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleCreateNewLoanStep3CompanyBlackList = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleCreateNewLoanStep3CustomerBlackList = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleCreateNewLoanStep3DuplicateViewModel = true;
                        #endregion

                        break;
                    }
                case "CreateNewLoanChecker":
                    {
                        #region CreateNewLoanStep1
                        objParam._CreateNewLoanStep1ViewModel.IsVisibleApplicationTypeID = true;
                        objParam._CreateNewLoanStep1ViewModel.IsVisibleProductTypeID = true;
                        objParam._CreateNewLoanStep1ViewModel.IsVisibleCreateNewLoanStep1Tree = true;
                        #endregion

                        #region CreateNewLoanStep2
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleApplication = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleApplicationStatus = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleApplicationTypeID = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleBusinessRegistrationNumber = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyAddress = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCAT = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCity = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCode = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCodeRLS = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyDistrict = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyEmail = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyName = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyPhone = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyRemark = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyType = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyWard = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerSCRelationship = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleIntitial = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleLegalLegalRepresentativeNationality = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleLegalRepresentative = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleLegalRepresentativeDateOfBirth = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleProductTypeID = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleTaxNumber = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationLegalRepresentative = true;
                        #endregion

                        #region CreateNewLoanStep3
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleApplicationNo = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleApplicationTypeID = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleProductTypeID = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleCreateNewLoanStep3CompanyBlackList = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleCreateNewLoanStep3CustomerBlackList = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleCreateNewLoanStep3DuplicateViewModel = true;
                        #endregion

                        break;
                    }
                case "CreateNewLoanViewer":
                    {
                        #region CreateNewLoanStep1
                        objParam._CreateNewLoanStep1ViewModel.IsVisibleApplicationTypeID = true;
                        objParam._CreateNewLoanStep1ViewModel.IsVisibleProductTypeID = true;
                        objParam._CreateNewLoanStep1ViewModel.IsVisibleCreateNewLoanStep1Tree = true;
                        #endregion

                        #region CreateNewLoanStep2
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleApplication = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleApplicationStatus = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleApplicationTypeID = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleBusinessRegistrationNumber = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyAddress = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCAT = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCity = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCode = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCodeRLS = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyDistrict = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyEmail = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyName = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyPhone = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyRemark = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyType = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyWard = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerSCRelationship = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleIntitial = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleLegalLegalRepresentativeNationality = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleLegalRepresentative = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleLegalRepresentativeDateOfBirth = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleProductTypeID = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleTaxNumber = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationLegalRepresentative = true;
                        #endregion

                        #region CreateNewLoanStep3
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleApplicationNo = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleApplicationTypeID = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleProductTypeID = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleCreateNewLoanStep3CompanyBlackList = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleCreateNewLoanStep3CustomerBlackList = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleCreateNewLoanStep3DuplicateViewModel = true;
                        #endregion
                        break;
                    }
                case "CreateNewLoanMaster":
                    {
                        #region CreateNewLoanStep1
                        objParam._CreateNewLoanStep1ViewModel.IsVisibleApplicationTypeID = true;
                        objParam._CreateNewLoanStep1ViewModel.IsVisibleProductTypeID = true;
                        objParam._CreateNewLoanStep1ViewModel.IsVisibleCreateNewLoanStep1Tree = true;
                        #endregion

                        #region CreateNewLoanStep2
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleApplication = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleApplicationStatus = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleApplicationTypeID = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleBusinessRegistrationNumber = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyAddress = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCAT = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCity = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCode = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyCodeRLS = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyDistrict = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyEmail = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyName = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyPhone = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyRemark = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyType = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCompanyWard = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerNameMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCustomerSCRelationship = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleDateOfBirthMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleIntitial = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleLegalLegalRepresentativeNationality = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleLegalRepresentative = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleLegalRepresentativeDateOfBirth = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleProductTypeID = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleTaxNumber = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2CompanyMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationCo1 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationCo2 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationCo3 = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationMain = true;
                        objParam._CreateNewLoanStep2ViewModel.IsVisibleCreateNewLoanStep2IdentificationLegalRepresentative = true;
                        #endregion

                        #region CreateNewLoanStep3
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleApplicationNo = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleApplicationTypeID = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleProductTypeID = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleCreateNewLoanStep3CompanyBlackList = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleCreateNewLoanStep3CustomerBlackList = true;
                        objParam._CreateNewLoanStep3ViewModel.IsVisibleCreateNewLoanStep3DuplicateViewModel = true;
                        #endregion

                        break;
                    }
                default:
                    {
                        break;
                    }
            }

            return objParam;
        }

        /// <summary>
        /// Readonly Control
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel ReadonlyControl(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            switch (ControllerNameParam)
            {
                case "CreateNewLoanMaker":
                    {
                        #region CreateNewLoanStep1
                        objParam._CreateNewLoanStep1ViewModel.IsDisableApplicationTypeID = false;
                        objParam._CreateNewLoanStep1ViewModel.IsDisableProductTypeID = false;
                        objParam._CreateNewLoanStep1ViewModel.IsDisableCreateNewLoanStep1Tree = false;
                        #endregion

                        #region CreateNewLoanStep2
                        objParam._CreateNewLoanStep2ViewModel.IsDisableApplication = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableApplicationStatus = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableApplicationTypeID = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableBusinessRegistrationNumber = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyAddress = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCAT = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCity = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCode = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCodeRLS = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyDistrict = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyEmail = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyName = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyPhone = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyRemark = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyType = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyWard = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerSCRelationship = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableIntitial = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableLegalLegalRepresentativeNationality = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableLegalRepresentative = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableLegalRepresentativeDateOfBirth = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableProductTypeID = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableTaxNumber = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationLegalRepresentative = false;
                        #endregion

                        #region CreateNewLoanStep3
                        objParam._CreateNewLoanStep3ViewModel.IsDisableApplicationNo = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableApplicationTypeID = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableProductTypeID = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableCreateNewLoanStep3CompanyBlackList = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableCreateNewLoanStep3CustomerBlackList = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableCreateNewLoanStep3DuplicateViewModel = false;
                        #endregion

                        break;
                    }
                case "CreateNewLoanChecker":
                    {
                        #region CreateNewLoanStep1
                        objParam._CreateNewLoanStep1ViewModel.IsDisableApplicationTypeID = false;
                        objParam._CreateNewLoanStep1ViewModel.IsDisableProductTypeID = false;
                        objParam._CreateNewLoanStep1ViewModel.IsDisableCreateNewLoanStep1Tree = false;
                        #endregion

                        #region CreateNewLoanStep2
                        objParam._CreateNewLoanStep2ViewModel.IsDisableApplication = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableApplicationStatus = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableApplicationTypeID = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableBusinessRegistrationNumber = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyAddress = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCAT = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCity = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCode = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCodeRLS = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyDistrict = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyEmail = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyName = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyPhone = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyRemark = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyType = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyWard = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerSCRelationship = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableIntitial = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableLegalLegalRepresentativeNationality = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableLegalRepresentative = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableLegalRepresentativeDateOfBirth = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableProductTypeID = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableTaxNumber = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationLegalRepresentative = false;
                        #endregion

                        #region CreateNewLoanStep3
                        objParam._CreateNewLoanStep3ViewModel.IsDisableApplicationNo = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableApplicationTypeID = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableProductTypeID = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableCreateNewLoanStep3CompanyBlackList = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableCreateNewLoanStep3CustomerBlackList = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableCreateNewLoanStep3DuplicateViewModel = false;
                        #endregion

                        break;
                    }
                case "CreateNewLoanViewer":
                    {
                        #region CreateNewLoanStep1
                        objParam._CreateNewLoanStep1ViewModel.IsDisableApplicationTypeID = false;
                        objParam._CreateNewLoanStep1ViewModel.IsDisableProductTypeID = false;
                        objParam._CreateNewLoanStep1ViewModel.IsDisableCreateNewLoanStep1Tree = false;
                        #endregion

                        #region CreateNewLoanStep2
                        objParam._CreateNewLoanStep2ViewModel.IsDisableApplication = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableApplicationStatus = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableApplicationTypeID = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableBusinessRegistrationNumber = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyAddress = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCAT = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCity = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCode = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCodeRLS = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyDistrict = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyEmail = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyName = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyPhone = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyRemark = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyType = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyWard = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerSCRelationship = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableIntitial = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableLegalLegalRepresentativeNationality = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableLegalRepresentative = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableLegalRepresentativeDateOfBirth = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableProductTypeID = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableTaxNumber = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationLegalRepresentative = false;
                        #endregion

                        #region CreateNewLoanStep3
                        objParam._CreateNewLoanStep3ViewModel.IsDisableApplicationNo = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableApplicationTypeID = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableProductTypeID = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableCreateNewLoanStep3CompanyBlackList = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableCreateNewLoanStep3CustomerBlackList = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableCreateNewLoanStep3DuplicateViewModel = false;
                        #endregion

                        break;
                    }
                case "CreateNewLoanMaster":
                    {
                        #region CreateNewLoanStep1
                        objParam._CreateNewLoanStep1ViewModel.IsDisableApplicationTypeID = false;
                        objParam._CreateNewLoanStep1ViewModel.IsDisableProductTypeID = false;
                        objParam._CreateNewLoanStep1ViewModel.IsDisableCreateNewLoanStep1Tree = false;
                        #endregion

                        #region CreateNewLoanStep2
                        objParam._CreateNewLoanStep2ViewModel.IsDisableApplication = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableApplicationStatus = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableApplicationTypeID = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableBusinessRegistrationNumber = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyAddress = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCAT = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCity = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCode = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyCodeRLS = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyDistrict = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyEmail = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyName = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyPhone = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyRemark = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyType = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCompanyWard = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerNameMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCustomerSCRelationship = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableDateOfBirthMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableIntitial = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableLegalLegalRepresentativeNationality = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableLegalRepresentative = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableLegalRepresentativeDateOfBirth = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableProductTypeID = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableTaxNumber = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2CompanyMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationCo1 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationCo2 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationCo3 = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationMain = false;
                        objParam._CreateNewLoanStep2ViewModel.IsDisableCreateNewLoanStep2IdentificationLegalRepresentative = false;
                        #endregion

                        #region CreateNewLoanStep3
                        objParam._CreateNewLoanStep3ViewModel.IsDisableApplicationNo = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableApplicationTypeID = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableProductTypeID = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableCreateNewLoanStep3CompanyBlackList = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableCreateNewLoanStep3CustomerBlackList = false;
                        objParam._CreateNewLoanStep3ViewModel.IsDisableCreateNewLoanStep3DuplicateViewModel = false;
                        #endregion

                        break;
                    }
                default:
                    {
                        break;
                    }
            }

            return objParam;
        }

        /// <summary>
        /// LoadMetaData
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadMetaData(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            objParam = LoadMetaDataStep1(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = LoadMetaDataStep2(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);
            objParam = LoadMetaDataStep3(objParam, AreaNameParam, ControllerNameParam, UserPWIDParam);

            return objParam;
        }

        public CreateNewLoanViewModel LoadMetaDataStep1(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {            
            return objParam;
        }

        public CreateNewLoanViewModel LoadMetaDataStep2(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            if (objParam != null && objParam._CreateNewLoanStep2ViewModel != null)
            {
                objParam._CreateNewLoanStep2ViewModel._M_CityViewModel =
                _CityRepository.GetListActiveByTypeId(objParam._CreateNewLoanStep2ViewModel.ProductTypeID);

                objParam._CreateNewLoanStep2ViewModel._M_CompanyTypeViewModel =
                    _CompanyTypeRepository.GetListActiveByTypeId(objParam._CreateNewLoanStep2ViewModel.ProductTypeID);

                objParam._CreateNewLoanStep2ViewModel._M_CustomerRelationshipViewModel =
                    _CustomerRelationshipRepository.GetListActiveByTypeId(objParam._CreateNewLoanStep2ViewModel.ProductTypeID);

                objParam._CreateNewLoanStep2ViewModel._M_DistrictViewModel =
                    _DistrictRepository.GetListActiveByTypeId(objParam._CreateNewLoanStep2ViewModel.ProductTypeID);

                objParam._CreateNewLoanStep2ViewModel._M_IdentificationTypeViewModel =
                    _IdentificationTypeRepository.GetListActiveByTypeId(objParam._CreateNewLoanStep2ViewModel.ProductTypeID);

                objParam._CreateNewLoanStep2ViewModel._M_InitialViewModel =
                    _DefinitionTypeRepository.GetListActiveByGroupId((int)EnumList.Group.Initial);

                objParam._CreateNewLoanStep2ViewModel._M_NationalityViewModel =
                    _NationalityRepository.GetListActiveByTypeId(objParam._CreateNewLoanStep2ViewModel.ProductTypeID);

                objParam._CreateNewLoanStep2ViewModel._M_CustomerRelationshipViewModel =
                    _CustomerRelationshipRepository.GetListActiveByTypeId(objParam._CreateNewLoanStep2ViewModel.ProductTypeID);
            }

            return objParam;
        }

        public CreateNewLoanViewModel LoadMetaDataStep3(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            if (objParam != null && objParam._CreateNewLoanStep3ViewModel != null)
            {
                objParam._CreateNewLoanStep3ViewModel._M_CompanyTypeViewModel =
                    _CompanyTypeRepository.GetListActiveByTypeId(objParam._CreateNewLoanStep3ViewModel.ProductTypeID);

                objParam._CreateNewLoanStep3ViewModel._M_IdentificationTypeViewModel =
                    _IdentificationTypeRepository.GetListActiveByTypeId(objParam._CreateNewLoanStep3ViewModel.ProductTypeID);

                objParam._CreateNewLoanStep3ViewModel._M_NationalityViewModel =
                    _NationalityRepository.GetListActiveByTypeId(objParam._CreateNewLoanStep3ViewModel.ProductTypeID);

                objParam._CreateNewLoanStep3ViewModel._M_ApplicationTypeViewModel =
                    _TypeRepository.GetListActiveAll();
            }

            return objParam;
        }
    }
}
