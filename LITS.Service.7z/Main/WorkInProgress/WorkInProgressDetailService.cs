﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Service.Main.WorkInProgress;
using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Data.Repository.Main.SalesCoordinators;
using LITS.Model.PartialViews.Main.WorkInProgress;

namespace LITS.Service.Main.WorkInProgress
{
    public class WorkInProgressDetailService : IWorkInProgressDetailService
    {


        public WorkInProgressDetailService()
        {

        }

        public void Create(WorkInProgressDetailViewModel obj)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public WorkInProgressDetailViewModel GetAll()
        {
            throw new NotImplementedException();
        }

        public WorkInProgressDetailViewModel GetById(int Id)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }
    }
}
