﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using AutoMapper;

using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;

using LITS.Interface.Repository.Main.WorkInProgress;
using LITS.Interface.Service.Main.WorkInProgress;

using LITS.Model.PartialViews.Main.WorkInProgress;
using LITS.Model.Views.Main;

namespace LITS.Service.Main.WorkInProgress
{
    public class WorkInProgressService : IWorkInProgressService
    {
        private readonly IWorkInProgressMasterRepository _WorkInProgressMasterRepository;
        private readonly IWorkInProgressDetailRepository _WorkInProgressDetailRepository;
        private readonly IWorkInProgressTreeRepository _WorkInProgressTreeRepository;
        private readonly IWorkInProgressRepository _WorkInProgressRepository;
        private LITSEntities _LITSEntities;

        private readonly IUnitOfWork _unitOfWork;

        public WorkInProgressService(IWorkInProgressMasterRepository workInProgressMasterRepository,
            IWorkInProgressDetailRepository workInProgressDetailRepository,
            IWorkInProgressTreeRepository workInProgressTreeRepository,
            IWorkInProgressRepository workInProgressRepository,
            IUnitOfWork unitOfWork,
            LITSEntities litsEntities)
        {
            this._WorkInProgressDetailRepository = workInProgressDetailRepository;
            this._WorkInProgressMasterRepository = workInProgressMasterRepository;
            this._WorkInProgressTreeRepository = workInProgressTreeRepository;
            this._WorkInProgressRepository = workInProgressRepository;
            this._unitOfWork = unitOfWork;
            this._LITSEntities = litsEntities;
        }

        public WorkInProgressViewModel LoadIndex()
        {
            WorkInProgressViewModel obj = new WorkInProgressViewModel();

            obj._WorkInProgressTreeViewModel = _WorkInProgressTreeRepository.GetListTreeProductIsActive();
            obj._WorkInProgressMasterViewModel._WorkInProgressMasterCustomerViewModel = _WorkInProgressMasterRepository.GetListCustomerLargeDatabase();
            obj._WorkInProgressMasterViewModel._WorkInProgressMasterCompanyViewModel = _WorkInProgressMasterRepository.GetListCompanyLargeDatabase();

            return obj;
        }

        public WorkInProgressViewModel SearchData(WorkInProgressViewModel obj, string strAreaName, string strControllerName)
        {
            WorkInProgressViewModel objResult = new WorkInProgressViewModel();

            objResult = _WorkInProgressRepository.SearchData(obj, strAreaName, strControllerName);

            return objResult;
        }

        public WorkInProgressViewModel LoadChildDetail(int appId, string strAreaName, string strControllerName)
        {
            WorkInProgressViewModel objResult = new WorkInProgressViewModel();

            objResult = _WorkInProgressRepository.LoadChildDetail(appId, strAreaName, strControllerName);

            return objResult;
        }
    }
}
