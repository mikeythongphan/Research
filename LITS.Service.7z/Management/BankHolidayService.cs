﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class BankHolidayService : IBankHolidayService
    {
        private readonly IBankHolidayRepository _BankHolidayRepository;

        private readonly IUnitOfWork _unitOfWork;

        public BankHolidayService(IBankHolidayRepository BankHolidayRepository,
            IUnitOfWork unitOfWork)
        {
            this._BankHolidayRepository = BankHolidayRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<BankHolidayViewModel> GetListAll()
        {
            return _BankHolidayRepository.GetListAll();
        }

        public List<BankHolidayViewModel> GetListById(int Id)
        {
            return _BankHolidayRepository.GetListById(Id);
        }

        public List<BankHolidayViewModel> GetListByStatusId(int StatusId)
        {
            return _BankHolidayRepository.GetListByStatusId(StatusId);
        }

        public List<BankHolidayViewModel> GetListByTypeId(int TypeId)
        {
            return _BankHolidayRepository.GetListByTypeId(TypeId);
        }

        public List<BankHolidayViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _BankHolidayRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<BankHolidayViewModel> GetListActiveAll()
        {
            return _BankHolidayRepository.GetListActiveAll();
        }

        public List<BankHolidayViewModel> GetListActiveById(int Id)
        {
            return _BankHolidayRepository.GetListActiveById(Id);
        }

        public List<BankHolidayViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _BankHolidayRepository.GetListActiveByStatusId(StatusId);
        }

        public List<BankHolidayViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _BankHolidayRepository.GetListActiveByTypeId(TypeId);
        }

        public List<BankHolidayViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _BankHolidayRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(BankHolidayViewModel objModel)
        {
            return _BankHolidayRepository.Create(objModel);
        }

        public bool Update(BankHolidayViewModel objModel)
        {
            return _BankHolidayRepository.Update(objModel);
        }

        public bool Delete(BankHolidayViewModel objModel)
        {
            return _BankHolidayRepository.Delete(objModel);
        }
    }
}
