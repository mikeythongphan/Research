﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class BonusTypeService : IBonusTypeService
    {
        private readonly IBonusTypeRepository _BonusTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public BonusTypeService(IBonusTypeRepository BonusTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._BonusTypeRepository = BonusTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<BonusTypeViewModel> GetListAll()
        {
            return _BonusTypeRepository.GetListAll();
        }

        public List<BonusTypeViewModel> GetListById(int? Id)
        {
            return _BonusTypeRepository.GetListById(Id);
        }

        public List<BonusTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _BonusTypeRepository.GetListByStatusId(StatusId);
        }

        public List<BonusTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _BonusTypeRepository.GetListByTypeId(TypeId);
        }

        public List<BonusTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _BonusTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<BonusTypeViewModel> GetListActiveAll()
        {
            return _BonusTypeRepository.GetListActiveAll();
        }

        public List<BonusTypeViewModel> GetListActiveById(int? Id)
        {
            return _BonusTypeRepository.GetListActiveById(Id);
        }

        public List<BonusTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _BonusTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<BonusTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _BonusTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<BonusTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _BonusTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(BonusTypeViewModel objModel)
        {
            return _BonusTypeRepository.Create(objModel);
        }

        public bool Update(BonusTypeViewModel objModel)
        {
            return _BonusTypeRepository.Update(objModel);
        }

        public bool Delete(BonusTypeViewModel objModel)
        {
            return _BonusTypeRepository.Delete(objModel);
        }
    }
}
