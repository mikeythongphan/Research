﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class BranchCodeService : IBranchCodeService
    {
        private readonly IBranchCodeRepository _BranchCodeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public BranchCodeService(IBranchCodeRepository BranchCodeRepository,
            IUnitOfWork unitOfWork)
        {
            this._BranchCodeRepository = BranchCodeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<BranchCodeViewModel> GetListAll()
        {
            return _BranchCodeRepository.GetListAll();
        }

        public List<BranchCodeViewModel> GetListById(int Id)
        {
            return _BranchCodeRepository.GetListById(Id);
        }

        public List<BranchCodeViewModel> GetListByStatusId(int StatusId)
        {
            return _BranchCodeRepository.GetListByStatusId(StatusId);
        }

        public List<BranchCodeViewModel> GetListByTypeId(int TypeId)
        {
            return _BranchCodeRepository.GetListByTypeId(TypeId);
        }

        public List<BranchCodeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _BranchCodeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<BranchCodeViewModel> GetListActiveAll()
        {
            return _BranchCodeRepository.GetListActiveAll();
        }

        public List<BranchCodeViewModel> GetListActiveById(int Id)
        {
            return _BranchCodeRepository.GetListActiveById(Id);
        }

        public List<BranchCodeViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _BranchCodeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<BranchCodeViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _BranchCodeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<BranchCodeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _BranchCodeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(BranchCodeViewModel objModel)
        {
            return _BranchCodeRepository.Create(objModel);
        }

        public bool Update(BranchCodeViewModel objModel)
        {
            return _BranchCodeRepository.Update(objModel);
        }

        public bool Delete(BranchCodeViewModel objModel)
        {
            return _BranchCodeRepository.Delete(objModel);
        }
    }
}
