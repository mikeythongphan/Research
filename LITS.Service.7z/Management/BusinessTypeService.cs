﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class BusinessTypeService : IBusinessTypeService
    {
        private readonly IBusinessTypeRepository _BusinessTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public BusinessTypeService(IBusinessTypeRepository BusinessTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._BusinessTypeRepository = BusinessTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<BusinessTypeViewModel> GetListAll()
        {
            return _BusinessTypeRepository.GetListAll();
        }

        public List<BusinessTypeViewModel> GetListById(int? Id)
        {
            return _BusinessTypeRepository.GetListById(Id);
        }

        public List<BusinessTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _BusinessTypeRepository.GetListByStatusId(StatusId);
        }

        public List<BusinessTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _BusinessTypeRepository.GetListByTypeId(TypeId);
        }

        public List<BusinessTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _BusinessTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<BusinessTypeViewModel> GetListActiveAll()
        {
            return _BusinessTypeRepository.GetListActiveAll();
        }

        public List<BusinessTypeViewModel> GetListActiveById(int? Id)
        {
            return _BusinessTypeRepository.GetListActiveById(Id);
        }

        public List<BusinessTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _BusinessTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<BusinessTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _BusinessTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<BusinessTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _BusinessTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(BusinessTypeViewModel objModel)
        {
            return _BusinessTypeRepository.Create(objModel);
        }

        public bool Update(BusinessTypeViewModel objModel)
        {
            return _BusinessTypeRepository.Update(objModel);
        }

        public bool Delete(BusinessTypeViewModel objModel)
        {
            return _BusinessTypeRepository.Delete(objModel);
        }
    }
}
