﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CDDService : ICDDService
    {
        private readonly ICDDRepository _CDDRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CDDService(ICDDRepository CDDRepository,
            IUnitOfWork unitOfWork)
        {
            this._CDDRepository = CDDRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CDDViewModel> GetListAll()
        {
            return _CDDRepository.GetListAll();
        }

        public List<CDDViewModel> GetListById(int Id)
        {
            return _CDDRepository.GetListById(Id);
        }

        public List<CDDViewModel> GetListByStatusId(int StatusId)
        {
            return _CDDRepository.GetListByStatusId(StatusId);
        }

        public List<CDDViewModel> GetListByTypeId(int TypeId)
        {
            return _CDDRepository.GetListByTypeId(TypeId);
        }

        public List<CDDViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _CDDRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CDDViewModel> GetListActiveAll()
        {
            return _CDDRepository.GetListActiveAll();
        }

        public List<CDDViewModel> GetListActiveById(int Id)
        {
            return _CDDRepository.GetListActiveById(Id);
        }

        public List<CDDViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _CDDRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CDDViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _CDDRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CDDViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _CDDRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CDDViewModel objModel)
        {
            return _CDDRepository.Create(objModel);
        }

        public bool Update(CDDViewModel objModel)
        {
            return _CDDRepository.Update(objModel);
        }

        public bool Delete(CDDViewModel objModel)
        {
            return _CDDRepository.Delete(objModel);
        }
    }
}
