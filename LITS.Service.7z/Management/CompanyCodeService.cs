﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CompanyCodeService : ICompanyCodeService
    {
        private readonly ICompanyCodeRepository _CompanyCodeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CompanyCodeService(ICompanyCodeRepository CompanyCodeRepository,
            IUnitOfWork unitOfWork)
        {
            this._CompanyCodeRepository = CompanyCodeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CompanyCodeViewModel> GetListAll()
        {
            return _CompanyCodeRepository.GetListAll();
        }

        public List<CompanyCodeViewModel> GetListById(int? Id)
        {
            return _CompanyCodeRepository.GetListById(Id);
        }

        public List<CompanyCodeViewModel> GetListByStatusId(int? StatusId)
        {
            return _CompanyCodeRepository.GetListByStatusId(StatusId);
        }

        public List<CompanyCodeViewModel> GetListByTypeId(int? TypeId)
        {
            return _CompanyCodeRepository.GetListByTypeId(TypeId);
        }

        public List<CompanyCodeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CompanyCodeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CompanyCodeViewModel> GetListActiveAll()
        {
            return _CompanyCodeRepository.GetListActiveAll();
        }

        public List<CompanyCodeViewModel> GetListActiveById(int? Id)
        {
            return _CompanyCodeRepository.GetListActiveById(Id);
        }

        public List<CompanyCodeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _CompanyCodeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CompanyCodeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _CompanyCodeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CompanyCodeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CompanyCodeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CompanyCodeViewModel objModel)
        {
            return _CompanyCodeRepository.Create(objModel);
        }

        public bool Update(CompanyCodeViewModel objModel)
        {
            return _CompanyCodeRepository.Update(objModel);
        }

        public bool Delete(CompanyCodeViewModel objModel)
        {
            return _CompanyCodeRepository.Delete(objModel);
        }
    }
}
