﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CreditDeviationService : ICreditDeviationService
    {
        private readonly ICreditDeviationRepository _CreditDeviationRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CreditDeviationService(ICreditDeviationRepository CreditDeviationRepository,
            IUnitOfWork unitOfWork)
        {
            this._CreditDeviationRepository = CreditDeviationRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CreditDeviationViewModel> GetListAll()
        {
            return _CreditDeviationRepository.GetListAll();
        }

        public List<CreditDeviationViewModel> GetListById(int Id)
        {
            return _CreditDeviationRepository.GetListById(Id);
        }

        public List<CreditDeviationViewModel> GetListByStatusId(int StatusId)
        {
            return _CreditDeviationRepository.GetListByStatusId(StatusId);
        }

        public List<CreditDeviationViewModel> GetListByTypeId(int TypeId)
        {
            return _CreditDeviationRepository.GetListByTypeId(TypeId);
        }

        public List<CreditDeviationViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _CreditDeviationRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CreditDeviationViewModel> GetListActiveAll()
        {
            return _CreditDeviationRepository.GetListActiveAll();
        }

        public List<CreditDeviationViewModel> GetListActiveById(int Id)
        {
            return _CreditDeviationRepository.GetListActiveById(Id);
        }

        public List<CreditDeviationViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _CreditDeviationRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CreditDeviationViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _CreditDeviationRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CreditDeviationViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _CreditDeviationRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CreditDeviationViewModel objModel)
        {
            return _CreditDeviationRepository.Create(objModel);
        }

        public bool Update(CreditDeviationViewModel objModel)
        {
            return _CreditDeviationRepository.Update(objModel);
        }

        public bool Delete(CreditDeviationViewModel objModel)
        {
            return _CreditDeviationRepository.Delete(objModel);
        }
    }
}
