﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CriteriaService : ICriteriaService
    {
        private readonly ICriteriaRepository _CriteriaRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CriteriaService(ICriteriaRepository CriteriaRepository,
            IUnitOfWork unitOfWork)
        {
            this._CriteriaRepository = CriteriaRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CriteriaViewModel> GetListAll()
        {
            return _CriteriaRepository.GetListAll();
        }

        public List<CriteriaViewModel> GetListById(int Id)
        {
            return _CriteriaRepository.GetListById(Id);
        }

        public List<CriteriaViewModel> GetListByStatusId(int StatusId)
        {
            return _CriteriaRepository.GetListByStatusId(StatusId);
        }

        public List<CriteriaViewModel> GetListByTypeId(int TypeId)
        {
            return _CriteriaRepository.GetListByTypeId(TypeId);
        }

        public List<CriteriaViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _CriteriaRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CriteriaViewModel> GetListActiveAll()
        {
            return _CriteriaRepository.GetListActiveAll();
        }

        public List<CriteriaViewModel> GetListActiveById(int Id)
        {
            return _CriteriaRepository.GetListActiveById(Id);
        }

        public List<CriteriaViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _CriteriaRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CriteriaViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _CriteriaRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CriteriaViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _CriteriaRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CriteriaViewModel objModel)
        {
            return _CriteriaRepository.Create(objModel);
        }

        public bool Update(CriteriaViewModel objModel)
        {
            return _CriteriaRepository.Update(objModel);
        }

        public bool Delete(CriteriaViewModel objModel)
        {
            return _CriteriaRepository.Delete(objModel);
        }
    }
}
