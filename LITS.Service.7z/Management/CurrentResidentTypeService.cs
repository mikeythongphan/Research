﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CurrentResidentTypeService : ICurrentResidentTypeService
    {
        private readonly ICurrentResidentTypeRepository _CurrentResidentTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CurrentResidentTypeService(ICurrentResidentTypeRepository CurrentResidentTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._CurrentResidentTypeRepository = CurrentResidentTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CurrentResidentTypeViewModel> GetListAll()
        {
            return _CurrentResidentTypeRepository.GetListAll();
        }

        public List<CurrentResidentTypeViewModel> GetListById(int? Id)
        {
            return _CurrentResidentTypeRepository.GetListById(Id);
        }

        public List<CurrentResidentTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _CurrentResidentTypeRepository.GetListByStatusId(StatusId);
        }

        public List<CurrentResidentTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _CurrentResidentTypeRepository.GetListByTypeId(TypeId);
        }

        public List<CurrentResidentTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CurrentResidentTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CurrentResidentTypeViewModel> GetListActiveAll()
        {
            return _CurrentResidentTypeRepository.GetListActiveAll();
        }

        public List<CurrentResidentTypeViewModel> GetListActiveById(int? Id)
        {
            return _CurrentResidentTypeRepository.GetListActiveById(Id);
        }

        public List<CurrentResidentTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _CurrentResidentTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CurrentResidentTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _CurrentResidentTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CurrentResidentTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CurrentResidentTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CurrentResidentTypeViewModel objModel)
        {
            return _CurrentResidentTypeRepository.Create(objModel);
        }

        public bool Update(CurrentResidentTypeViewModel objModel)
        {
            return _CurrentResidentTypeRepository.Update(objModel);
        }

        public bool Delete(CurrentResidentTypeViewModel objModel)
        {
            return _CurrentResidentTypeRepository.Delete(objModel);
        }
    }
}
