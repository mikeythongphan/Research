﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CustomerRelationshipService : ICustomerRelationshipService
    {
        private readonly ICustomerRelationshipRepository _CustomerRelationshipRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CustomerRelationshipService(ICustomerRelationshipRepository CustomerRelationshipRepository,
            IUnitOfWork unitOfWork)
        {
            this._CustomerRelationshipRepository = CustomerRelationshipRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CustomerRelationshipViewModel> GetListAll()
        {
            return _CustomerRelationshipRepository.GetListAll();
        }

        public List<CustomerRelationshipViewModel> GetListById(int Id)
        {
            return _CustomerRelationshipRepository.GetListById(Id);
        }

        public List<CustomerRelationshipViewModel> GetListByStatusId(int StatusId)
        {
            return _CustomerRelationshipRepository.GetListByStatusId(StatusId);
        }

        public List<CustomerRelationshipViewModel> GetListByTypeId(int TypeId)
        {
            return _CustomerRelationshipRepository.GetListByTypeId(TypeId);
        }

        public List<CustomerRelationshipViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _CustomerRelationshipRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CustomerRelationshipViewModel> GetListActiveAll()
        {
            return _CustomerRelationshipRepository.GetListActiveAll();
        }

        public List<CustomerRelationshipViewModel> GetListActiveById(int Id)
        {
            return _CustomerRelationshipRepository.GetListActiveById(Id);
        }

        public List<CustomerRelationshipViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _CustomerRelationshipRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CustomerRelationshipViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _CustomerRelationshipRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CustomerRelationshipViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _CustomerRelationshipRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CustomerRelationshipViewModel objModel)
        {
            return _CustomerRelationshipRepository.Create(objModel);
        }

        public bool Update(CustomerRelationshipViewModel objModel)
        {
            return _CustomerRelationshipRepository.Update(objModel);
        }

        public bool Delete(CustomerRelationshipViewModel objModel)
        {
            return _CustomerRelationshipRepository.Delete(objModel);
        }
    }
}
