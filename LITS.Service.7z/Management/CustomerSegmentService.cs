﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class CustomerSegmentService : ICustomerSegmentService
    {
        private readonly ICustomerSegmentRepository _CustomerSegmentRepository;

        private readonly IUnitOfWork _unitOfWork;

        public CustomerSegmentService(ICustomerSegmentRepository CustomerSegmentRepository,
            IUnitOfWork unitOfWork)
        {
            this._CustomerSegmentRepository = CustomerSegmentRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<CustomerSegmentViewModel> GetListAll()
        {
            return _CustomerSegmentRepository.GetListAll();
        }

        public List<CustomerSegmentViewModel> GetListById(int? Id)
        {
            return _CustomerSegmentRepository.GetListById(Id);
        }

        public List<CustomerSegmentViewModel> GetListByStatusId(int? StatusId)
        {
            return _CustomerSegmentRepository.GetListByStatusId(StatusId);
        }

        public List<CustomerSegmentViewModel> GetListByTypeId(int? TypeId)
        {
            return _CustomerSegmentRepository.GetListByTypeId(TypeId);
        }

        public List<CustomerSegmentViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CustomerSegmentRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<CustomerSegmentViewModel> GetListActiveAll()
        {
            return _CustomerSegmentRepository.GetListActiveAll();
        }

        public List<CustomerSegmentViewModel> GetListActiveById(int? Id)
        {
            return _CustomerSegmentRepository.GetListActiveById(Id);
        }

        public List<CustomerSegmentViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _CustomerSegmentRepository.GetListActiveByStatusId(StatusId);
        }

        public List<CustomerSegmentViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _CustomerSegmentRepository.GetListActiveByTypeId(TypeId);
        }

        public List<CustomerSegmentViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _CustomerSegmentRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(CustomerSegmentViewModel objModel)
        {
            return _CustomerSegmentRepository.Create(objModel);
        }

        public bool Update(CustomerSegmentViewModel objModel)
        {
            return _CustomerSegmentRepository.Update(objModel);
        }

        public bool Delete(CustomerSegmentViewModel objModel)
        {
            return _CustomerSegmentRepository.Delete(objModel);
        }
    }
}
