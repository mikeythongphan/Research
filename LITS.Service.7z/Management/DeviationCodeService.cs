﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class DeviationCodeService : IDeviationCodeService
    {
        private readonly IDeviationCodeRepository _DeviationCodeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public DeviationCodeService(IDeviationCodeRepository DeviationCodeRepository,
            IUnitOfWork unitOfWork)
        {
            this._DeviationCodeRepository = DeviationCodeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<DeviationCodeViewModel> GetListAll()
        {
            return _DeviationCodeRepository.GetListAll();
        }

        public List<DeviationCodeViewModel> GetListById(int Id)
        {
            return _DeviationCodeRepository.GetListById(Id);
        }

        public List<DeviationCodeViewModel> GetListByStatusId(int StatusId)
        {
            return _DeviationCodeRepository.GetListByStatusId(StatusId);
        }

        public List<DeviationCodeViewModel> GetListByTypeId(int TypeId)
        {
            return _DeviationCodeRepository.GetListByTypeId(TypeId);
        }

        public List<DeviationCodeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _DeviationCodeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<DeviationCodeViewModel> GetListActiveAll()
        {
            return _DeviationCodeRepository.GetListActiveAll();
        }

        public List<DeviationCodeViewModel> GetListActiveById(int Id)
        {
            return _DeviationCodeRepository.GetListActiveById(Id);
        }

        public List<DeviationCodeViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _DeviationCodeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<DeviationCodeViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _DeviationCodeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<DeviationCodeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _DeviationCodeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(DeviationCodeViewModel objModel)
        {
            return _DeviationCodeRepository.Create(objModel);
        }

        public bool Update(DeviationCodeViewModel objModel)
        {
            return _DeviationCodeRepository.Update(objModel);
        }

        public bool Delete(DeviationCodeViewModel objModel)
        {
            return _DeviationCodeRepository.Delete(objModel);
        }
    }
}
