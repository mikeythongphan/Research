﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class DistrictService : IDistrictService
    {
        private readonly IDistrictRepository _DistrictRepository;

        private readonly IUnitOfWork _unitOfWork;

        public DistrictService(IDistrictRepository DistrictRepository,
            IUnitOfWork unitOfWork)
        {
            this._DistrictRepository = DistrictRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<DistrictViewModel> GetListAll()
        {
            return _DistrictRepository.GetListAll();
        }

        public List<DistrictViewModel> GetListById(int Id)
        {
            return _DistrictRepository.GetListById(Id);
        }

        public List<DistrictViewModel> GetListByStatusId(int StatusId)
        {
            return _DistrictRepository.GetListByStatusId(StatusId);
        }

        public List<DistrictViewModel> GetListByTypeId(int TypeId)
        {
            return _DistrictRepository.GetListByTypeId(TypeId);
        }

        public List<DistrictViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _DistrictRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<DistrictViewModel> GetListByCityId(int Id)
        {
            return _DistrictRepository.GetListByCityId(Id);
        }

        public List<DistrictViewModel> GetListActiveAll()
        {
            return _DistrictRepository.GetListActiveAll();
        }

        public List<DistrictViewModel> GetListActiveById(int Id)
        {
            return _DistrictRepository.GetListActiveById(Id);
        }

        public List<DistrictViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _DistrictRepository.GetListActiveByStatusId(StatusId);
        }

        public List<DistrictViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _DistrictRepository.GetListActiveByTypeId(TypeId);
        }

        public List<DistrictViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _DistrictRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<DistrictViewModel> GetListActiveByCityId(int Id)
        {
            return _DistrictRepository.GetListActiveByCityId(Id);
        }

        public bool Create(DistrictViewModel objModel)
        {
            return _DistrictRepository.Create(objModel);
        }

        public bool Update(DistrictViewModel objModel)
        {
            return _DistrictRepository.Update(objModel);
        }

        public bool Delete(DistrictViewModel objModel)
        {
            return _DistrictRepository.Delete(objModel);
        }
    }
}
