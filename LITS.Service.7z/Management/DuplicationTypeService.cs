﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class DuplicationTypeService : IDuplicationTypeService
    {
        private readonly IDuplicationTypeRepository _DuplicationTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public DuplicationTypeService(IDuplicationTypeRepository DuplicationTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._DuplicationTypeRepository = DuplicationTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<DuplicationTypeViewModel> GetListAll()
        {
            return _DuplicationTypeRepository.GetListAll();
        }

        public List<DuplicationTypeViewModel> GetListById(int Id)
        {
            return _DuplicationTypeRepository.GetListById(Id);
        }

        public List<DuplicationTypeViewModel> GetListByStatusId(int StatusId)
        {
            return _DuplicationTypeRepository.GetListByStatusId(StatusId);
        }

        public List<DuplicationTypeViewModel> GetListByTypeId(int TypeId)
        {
            return _DuplicationTypeRepository.GetListByTypeId(TypeId);
        }

        public List<DuplicationTypeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _DuplicationTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<DuplicationTypeViewModel> GetListActiveAll()
        {
            return _DuplicationTypeRepository.GetListActiveAll();
        }

        public List<DuplicationTypeViewModel> GetListActiveById(int Id)
        {
            return _DuplicationTypeRepository.GetListActiveById(Id);
        }

        public List<DuplicationTypeViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _DuplicationTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<DuplicationTypeViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _DuplicationTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<DuplicationTypeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _DuplicationTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(DuplicationTypeViewModel objModel)
        {
            return _DuplicationTypeRepository.Create(objModel);
        }

        public bool Update(DuplicationTypeViewModel objModel)
        {
            return _DuplicationTypeRepository.Update(objModel);
        }

        public bool Delete(DuplicationTypeViewModel objModel)
        {
            return _DuplicationTypeRepository.Delete(objModel);
        }
    }
}
