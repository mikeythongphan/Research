﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class IdentificationTypeService : IIdentificationTypeService
    {
        private readonly IIdentificationTypeRepository _IdentificationTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public IdentificationTypeService(IIdentificationTypeRepository IdentificationTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._IdentificationTypeRepository = IdentificationTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<IdentificationTypeViewModel> GetListAll()
        {
            return _IdentificationTypeRepository.GetListAll();
        }

        public List<IdentificationTypeViewModel> GetListById(int? Id)
        {
            return _IdentificationTypeRepository.GetListById(Id);
        }

        public List<IdentificationTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _IdentificationTypeRepository.GetListByStatusId(StatusId);
        }

        public List<IdentificationTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _IdentificationTypeRepository.GetListByTypeId(TypeId);
        }

        public List<IdentificationTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _IdentificationTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<IdentificationTypeViewModel> GetListActiveAll()
        {
            return _IdentificationTypeRepository.GetListActiveAll();
        }

        public List<IdentificationTypeViewModel> GetListActiveById(int? Id)
        {
            return _IdentificationTypeRepository.GetListActiveById(Id);
        }

        public List<IdentificationTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _IdentificationTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<IdentificationTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _IdentificationTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<IdentificationTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _IdentificationTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(IdentificationTypeViewModel objModel)
        {
            return _IdentificationTypeRepository.Create(objModel);
        }

        public bool Update(IdentificationTypeViewModel objModel)
        {
            return _IdentificationTypeRepository.Update(objModel);
        }

        public bool Delete(IdentificationTypeViewModel objModel)
        {
            return _IdentificationTypeRepository.Delete(objModel);
        }
    }
}
