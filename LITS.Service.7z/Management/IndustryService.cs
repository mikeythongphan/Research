﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class IndustryService : IIndustryService
    {
        private readonly IIndustryRepository _IndustryRepository;

        private readonly IUnitOfWork _unitOfWork;

        public IndustryService(IIndustryRepository IndustryRepository,
            IUnitOfWork unitOfWork)
        {
            this._IndustryRepository = IndustryRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<IndustryViewModel> GetListAll()
        {
            return _IndustryRepository.GetListAll();
        }

        public List<IndustryViewModel> GetListById(int? Id)
        {
            return _IndustryRepository.GetListById(Id);
        }

        public List<IndustryViewModel> GetListByStatusId(int? StatusId)
        {
            return _IndustryRepository.GetListByStatusId(StatusId);
        }

        public List<IndustryViewModel> GetListByTypeId(int? TypeId)
        {
            return _IndustryRepository.GetListByTypeId(TypeId);
        }

        public List<IndustryViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _IndustryRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<IndustryViewModel> GetListActiveAll()
        {
            return _IndustryRepository.GetListActiveAll();
        }

        public List<IndustryViewModel> GetListActiveById(int? Id)
        {
            return _IndustryRepository.GetListActiveById(Id);
        }

        public List<IndustryViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _IndustryRepository.GetListActiveByStatusId(StatusId);
        }

        public List<IndustryViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _IndustryRepository.GetListActiveByTypeId(TypeId);
        }

        public List<IndustryViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _IndustryRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(IndustryViewModel objModel)
        {
            return _IndustryRepository.Create(objModel);
        }

        public bool Update(IndustryViewModel objModel)
        {
            return _IndustryRepository.Update(objModel);
        }

        public bool Delete(IndustryViewModel objModel)
        {
            return _IndustryRepository.Delete(objModel);
        }
    }
}
