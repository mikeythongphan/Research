﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class InvestigaveTypeService : IInvestigaveTypeService
    {
        private readonly IInvestigaveTypeRepository _InvestigaveTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public InvestigaveTypeService(IInvestigaveTypeRepository InvestigaveTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._InvestigaveTypeRepository = InvestigaveTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<InvestigaveTypeViewModel> GetListAll()
        {
            return _InvestigaveTypeRepository.GetListAll();
        }

        public List<InvestigaveTypeViewModel> GetListById(int? Id)
        {
            return _InvestigaveTypeRepository.GetListById(Id);
        }

        public List<InvestigaveTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _InvestigaveTypeRepository.GetListByStatusId(StatusId);
        }

        public List<InvestigaveTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _InvestigaveTypeRepository.GetListByTypeId(TypeId);
        }

        public List<InvestigaveTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _InvestigaveTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<InvestigaveTypeViewModel> GetListActiveAll()
        {
            return _InvestigaveTypeRepository.GetListActiveAll();
        }

        public List<InvestigaveTypeViewModel> GetListActiveById(int? Id)
        {
            return _InvestigaveTypeRepository.GetListActiveById(Id);
        }

        public List<InvestigaveTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _InvestigaveTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<InvestigaveTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _InvestigaveTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<InvestigaveTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _InvestigaveTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(InvestigaveTypeViewModel objModel)
        {
            return _InvestigaveTypeRepository.Create(objModel);
        }

        public bool Update(InvestigaveTypeViewModel objModel)
        {
            return _InvestigaveTypeRepository.Update(objModel);
        }

        public bool Delete(InvestigaveTypeViewModel objModel)
        {
            return _InvestigaveTypeRepository.Delete(objModel);
        }
    }
}
