﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class LoanTenorService : ILoanTenorService
    {
        private readonly ILoanTenorRepository _LoanTenorRepository;

        private readonly IUnitOfWork _unitOfWork;

        public LoanTenorService(ILoanTenorRepository LoanTenorRepository,
            IUnitOfWork unitOfWork)
        {
            this._LoanTenorRepository = LoanTenorRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<LoanTenorViewModel> GetListAll()
        {
            return _LoanTenorRepository.GetListAll();
        }

        public List<LoanTenorViewModel> GetListById(int? Id)
        {
            return _LoanTenorRepository.GetListById(Id);
        }

        public List<LoanTenorViewModel> GetListByStatusId(int? StatusId)
        {
            return _LoanTenorRepository.GetListByStatusId(StatusId);
        }

        public List<LoanTenorViewModel> GetListByTypeId(int? TypeId)
        {
            return _LoanTenorRepository.GetListByTypeId(TypeId);
        }

        public List<LoanTenorViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _LoanTenorRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<LoanTenorViewModel> GetListActiveAll()
        {
            return _LoanTenorRepository.GetListActiveAll();
        }

        public List<LoanTenorViewModel> GetListActiveById(int? Id)
        {
            return _LoanTenorRepository.GetListActiveById(Id);
        }

        public List<LoanTenorViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _LoanTenorRepository.GetListActiveByStatusId(StatusId);
        }

        public List<LoanTenorViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _LoanTenorRepository.GetListActiveByTypeId(TypeId);
        }

        public List<LoanTenorViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _LoanTenorRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(LoanTenorViewModel objModel)
        {
            return _LoanTenorRepository.Create(objModel);
        }

        public bool Update(LoanTenorViewModel objModel)
        {
            return _LoanTenorRepository.Update(objModel);
        }

        public bool Delete(LoanTenorViewModel objModel)
        {
            return _LoanTenorRepository.Delete(objModel);
        }
    }
}
