﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class LoanTrendService : ILoanTrendService
    {
        private readonly ILoanTrendRepository _LoanTrendRepository;

        private readonly IUnitOfWork _unitOfWork;

        public LoanTrendService(ILoanTrendRepository LoanTrendRepository,
            IUnitOfWork unitOfWork)
        {
            this._LoanTrendRepository = LoanTrendRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<LoanTrendViewModel> GetListAll()
        {
            return _LoanTrendRepository.GetListAll();
        }

        public List<LoanTrendViewModel> GetListById(int? Id)
        {
            return _LoanTrendRepository.GetListById(Id);
        }

        public List<LoanTrendViewModel> GetListByStatusId(int? StatusId)
        {
            return _LoanTrendRepository.GetListByStatusId(StatusId);
        }

        public List<LoanTrendViewModel> GetListByTypeId(int? TypeId)
        {
            return _LoanTrendRepository.GetListByTypeId(TypeId);
        }

        public List<LoanTrendViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _LoanTrendRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<LoanTrendViewModel> GetListActiveAll()
        {
            return _LoanTrendRepository.GetListActiveAll();
        }

        public List<LoanTrendViewModel> GetListActiveById(int? Id)
        {
            return _LoanTrendRepository.GetListActiveById(Id);
        }

        public List<LoanTrendViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _LoanTrendRepository.GetListActiveByStatusId(StatusId);
        }

        public List<LoanTrendViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _LoanTrendRepository.GetListActiveByTypeId(TypeId);
        }

        public List<LoanTrendViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _LoanTrendRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(LoanTrendViewModel objModel)
        {
            return _LoanTrendRepository.Create(objModel);
        }

        public bool Update(LoanTrendViewModel objModel)
        {
            return _LoanTrendRepository.Update(objModel);
        }

        public bool Delete(LoanTrendViewModel objModel)
        {
            return _LoanTrendRepository.Delete(objModel);
        }
    }
}
