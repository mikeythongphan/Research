﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class LoanTypeService : ILoanTypeService
    {
        private readonly ILoanTypeRepository _LoanTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public LoanTypeService(ILoanTypeRepository LoanTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._LoanTypeRepository = LoanTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<LoanTypeViewModel> GetListAll()
        {
            return _LoanTypeRepository.GetListAll();
        }

        public List<LoanTypeViewModel> GetListById(int Id)
        {
            return _LoanTypeRepository.GetListById(Id);
        }

        public List<LoanTypeViewModel> GetListByStatusId(int StatusId)
        {
            return _LoanTypeRepository.GetListByStatusId(StatusId);
        }

        public List<LoanTypeViewModel> GetListByTypeId(int TypeId)
        {
            return _LoanTypeRepository.GetListByTypeId(TypeId);
        }

        public List<LoanTypeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _LoanTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<LoanTypeViewModel> GetListActiveAll()
        {
            return _LoanTypeRepository.GetListActiveAll();
        }

        public List<LoanTypeViewModel> GetListActiveById(int Id)
        {
            return _LoanTypeRepository.GetListActiveById(Id);
        }

        public List<LoanTypeViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _LoanTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<LoanTypeViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _LoanTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<LoanTypeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _LoanTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(LoanTypeViewModel objModel)
        {
            return _LoanTypeRepository.Create(objModel);
        }

        public bool Update(LoanTypeViewModel objModel)
        {
            return _LoanTypeRepository.Update(objModel);
        }

        public bool Delete(LoanTypeViewModel objModel)
        {
            return _LoanTypeRepository.Delete(objModel);
        }
    }
}
