﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class MaritalStatusService : IMaritalStatusService
    {
        private readonly IMaritalStatusRepository _MaritalStatusRepository;

        private readonly IUnitOfWork _unitOfWork;

        public MaritalStatusService(IMaritalStatusRepository MaritalStatusRepository,
            IUnitOfWork unitOfWork)
        {
            this._MaritalStatusRepository = MaritalStatusRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<MaritalStatusViewModel> GetListAll()
        {
            return _MaritalStatusRepository.GetListAll();
        }

        public List<MaritalStatusViewModel> GetListById(int? Id)
        {
            return _MaritalStatusRepository.GetListById(Id);
        }

        public List<MaritalStatusViewModel> GetListByStatusId(int? StatusId)
        {
            return _MaritalStatusRepository.GetListByStatusId(StatusId);
        }

        public List<MaritalStatusViewModel> GetListByTypeId(int? TypeId)
        {
            return _MaritalStatusRepository.GetListByTypeId(TypeId);
        }

        public List<MaritalStatusViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _MaritalStatusRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<MaritalStatusViewModel> GetListActiveAll()
        {
            return _MaritalStatusRepository.GetListActiveAll();
        }

        public List<MaritalStatusViewModel> GetListActiveById(int? Id)
        {
            return _MaritalStatusRepository.GetListActiveById(Id);
        }

        public List<MaritalStatusViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _MaritalStatusRepository.GetListActiveByStatusId(StatusId);
        }

        public List<MaritalStatusViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _MaritalStatusRepository.GetListActiveByTypeId(TypeId);
        }

        public List<MaritalStatusViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _MaritalStatusRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(MaritalStatusViewModel objModel)
        {
            return _MaritalStatusRepository.Create(objModel);
        }

        public bool Update(MaritalStatusViewModel objModel)
        {
            return _MaritalStatusRepository.Update(objModel);
        }

        public bool Delete(MaritalStatusViewModel objModel)
        {
            return _MaritalStatusRepository.Delete(objModel);
        }
    }
}
