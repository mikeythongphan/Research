﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class MessageService : IMessageService
    {
        private readonly IMessageRepository _MessageRepository;

        private readonly IUnitOfWork _unitOfWork;

        public MessageService(IMessageRepository MessageRepository,
            IUnitOfWork unitOfWork)
        {
            this._MessageRepository = MessageRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<MessageViewModel> GetListAll()
        {
            return _MessageRepository.GetListAll();
        }

        public List<MessageViewModel> GetListById(int? Id)
        {
            return _MessageRepository.GetListById(Id);
        }

        public List<MessageViewModel> GetListByStatusId(int? StatusId)
        {
            return _MessageRepository.GetListByStatusId(StatusId);
        }

        public List<MessageViewModel> GetListByTypeId(int? TypeId)
        {
            return _MessageRepository.GetListByTypeId(TypeId);
        }

        public List<MessageViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _MessageRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<MessageViewModel> GetListActiveAll()
        {
            return _MessageRepository.GetListActiveAll();
        }

        public List<MessageViewModel> GetListActiveById(int? Id)
        {
            return _MessageRepository.GetListActiveById(Id);
        }

        public List<MessageViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _MessageRepository.GetListActiveByStatusId(StatusId);
        }

        public List<MessageViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _MessageRepository.GetListActiveByTypeId(TypeId);
        }

        public List<MessageViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _MessageRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(MessageViewModel objModel)
        {
            return _MessageRepository.Create(objModel);
        }

        public bool Update(MessageViewModel objModel)
        {
            return _MessageRepository.Update(objModel);
        }

        public bool Delete(MessageViewModel objModel)
        {
            return _MessageRepository.Delete(objModel);
        }
    }
}
