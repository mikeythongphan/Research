﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class MessageTypeService : IMessageTypeService
    {
        private readonly IMessageTypeRepository _MessageTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public MessageTypeService(IMessageTypeRepository MessageTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._MessageTypeRepository = MessageTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<MessageTypeViewModel> GetListAll()
        {
            return _MessageTypeRepository.GetListAll();
        }

        public List<MessageTypeViewModel> GetListById(int Id)
        {
            return _MessageTypeRepository.GetListById(Id);
        }

        public List<MessageTypeViewModel> GetListByStatusId(int StatusId)
        {
            return _MessageTypeRepository.GetListByStatusId(StatusId);
        }

        public List<MessageTypeViewModel> GetListByTypeId(int TypeId)
        {
            return _MessageTypeRepository.GetListByTypeId(TypeId);
        }

        public List<MessageTypeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _MessageTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<MessageTypeViewModel> GetListActiveAll()
        {
            return _MessageTypeRepository.GetListActiveAll();
        }

        public List<MessageTypeViewModel> GetListActiveById(int Id)
        {
            return _MessageTypeRepository.GetListActiveById(Id);
        }

        public List<MessageTypeViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _MessageTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<MessageTypeViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _MessageTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<MessageTypeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _MessageTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(MessageTypeViewModel objModel)
        {
            return _MessageTypeRepository.Create(objModel);
        }

        public bool Update(MessageTypeViewModel objModel)
        {
            return _MessageTypeRepository.Update(objModel);
        }

        public bool Delete(MessageTypeViewModel objModel)
        {
            return _MessageTypeRepository.Delete(objModel);
        }
    }
}
