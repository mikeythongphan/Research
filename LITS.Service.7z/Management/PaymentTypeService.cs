﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class PaymentTypeService : IPaymentTypeService
    {
        private readonly IPaymentTypeRepository _PaymentTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public PaymentTypeService(IPaymentTypeRepository PaymentTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._PaymentTypeRepository = PaymentTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<PaymentTypeViewModel> GetListAll()
        {
            return _PaymentTypeRepository.GetListAll();
        }

        public List<PaymentTypeViewModel> GetListById(int Id)
        {
            return _PaymentTypeRepository.GetListById(Id);
        }

        public List<PaymentTypeViewModel> GetListByStatusId(int StatusId)
        {
            return _PaymentTypeRepository.GetListByStatusId(StatusId);
        }

        public List<PaymentTypeViewModel> GetListByTypeId(int TypeId)
        {
            return _PaymentTypeRepository.GetListByTypeId(TypeId);
        }

        public List<PaymentTypeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _PaymentTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<PaymentTypeViewModel> GetListActiveAll()
        {
            return _PaymentTypeRepository.GetListActiveAll();
        }

        public List<PaymentTypeViewModel> GetListActiveById(int Id)
        {
            return _PaymentTypeRepository.GetListActiveById(Id);
        }

        public List<PaymentTypeViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _PaymentTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<PaymentTypeViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _PaymentTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<PaymentTypeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _PaymentTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(PaymentTypeViewModel objModel)
        {
            return _PaymentTypeRepository.Create(objModel);
        }

        public bool Update(PaymentTypeViewModel objModel)
        {
            return _PaymentTypeRepository.Update(objModel);
        }

        public bool Delete(PaymentTypeViewModel objModel)
        {
            return _PaymentTypeRepository.Delete(objModel);
        }
    }
}
