﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class ProductTypeService : IProductTypeService
    {
        private readonly IProductTypeRepository _ProductTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public ProductTypeService(IProductTypeRepository ProductTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._ProductTypeRepository = ProductTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<ProductTypeViewModel> GetListAll()
        {
            return _ProductTypeRepository.GetListAll();
        }

        public List<ProductTypeViewModel> GetListById(int? Id)
        {
            return _ProductTypeRepository.GetListById(Id);
        }

        public List<ProductTypeViewModel> GetListByStatusId(int? StatusId)
        {
            return _ProductTypeRepository.GetListByStatusId(StatusId);
        }

        public List<ProductTypeViewModel> GetListByTypeId(int? TypeId)
        {
            return _ProductTypeRepository.GetListByTypeId(TypeId);
        }

        public List<ProductTypeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _ProductTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<ProductTypeViewModel> GetListActiveAll()
        {
            return _ProductTypeRepository.GetListActiveAll();
        }

        public List<ProductTypeViewModel> GetListActiveById(int? Id)
        {
            return _ProductTypeRepository.GetListActiveById(Id);
        }

        public List<ProductTypeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _ProductTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<ProductTypeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _ProductTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<ProductTypeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _ProductTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(ProductTypeViewModel objModel)
        {
            return _ProductTypeRepository.Create(objModel);
        }

        public bool Update(ProductTypeViewModel objModel)
        {
            return _ProductTypeRepository.Update(objModel);
        }

        public bool Delete(ProductTypeViewModel objModel)
        {
            return _ProductTypeRepository.Delete(objModel);
        }
    }
}
