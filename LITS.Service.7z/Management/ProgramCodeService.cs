﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class ProgramCodeService : IProgramCodeService
    {
        private readonly IProgramCodeRepository _ProgramCodeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public ProgramCodeService(IProgramCodeRepository ProgramCodeRepository,
            IUnitOfWork unitOfWork)
        {
            this._ProgramCodeRepository = ProgramCodeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<ProgramCodeViewModel> GetListAll()
        {
            return _ProgramCodeRepository.GetListAll();
        }

        public List<ProgramCodeViewModel> GetListById(int? Id)
        {
            return _ProgramCodeRepository.GetListById(Id);
        }

        public List<ProgramCodeViewModel> GetListByStatusId(int? StatusId)
        {
            return _ProgramCodeRepository.GetListByStatusId(StatusId);
        }

        public List<ProgramCodeViewModel> GetListByTypeId(int? TypeId)
        {
            return _ProgramCodeRepository.GetListByTypeId(TypeId);
        }

        public List<ProgramCodeViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _ProgramCodeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<ProgramCodeViewModel> GetListActiveAll()
        {
            return _ProgramCodeRepository.GetListActiveAll();
        }

        public List<ProgramCodeViewModel> GetListActiveById(int? Id)
        {
            return _ProgramCodeRepository.GetListActiveById(Id);
        }

        public List<ProgramCodeViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _ProgramCodeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<ProgramCodeViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _ProgramCodeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<ProgramCodeViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _ProgramCodeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(ProgramCodeViewModel objModel)
        {
            return _ProgramCodeRepository.Create(objModel);
        }

        public bool Update(ProgramCodeViewModel objModel)
        {
            return _ProgramCodeRepository.Update(objModel);
        }

        public bool Delete(ProgramCodeViewModel objModel)
        {
            return _ProgramCodeRepository.Delete(objModel);
        }
    }
}
