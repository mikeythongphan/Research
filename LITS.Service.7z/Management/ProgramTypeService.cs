﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class ProgramTypeService : IProgramTypeService
    {
        private readonly IProgramTypeRepository _ProgramTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public ProgramTypeService(IProgramTypeRepository ProgramTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._ProgramTypeRepository = ProgramTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<ProgramTypeViewModel> GetListAll()
        {
            return _ProgramTypeRepository.GetListAll();
        }

        public List<ProgramTypeViewModel> GetListById(int Id)
        {
            return _ProgramTypeRepository.GetListById(Id);
        }

        public List<ProgramTypeViewModel> GetListByStatusId(int StatusId)
        {
            return _ProgramTypeRepository.GetListByStatusId(StatusId);
        }

        public List<ProgramTypeViewModel> GetListByTypeId(int TypeId)
        {
            return _ProgramTypeRepository.GetListByTypeId(TypeId);
        }

        public List<ProgramTypeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _ProgramTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<ProgramTypeViewModel> GetListActiveAll()
        {
            return _ProgramTypeRepository.GetListActiveAll();
        }

        public List<ProgramTypeViewModel> GetListActiveById(int Id)
        {
            return _ProgramTypeRepository.GetListActiveById(Id);
        }

        public List<ProgramTypeViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _ProgramTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<ProgramTypeViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _ProgramTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<ProgramTypeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _ProgramTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(ProgramTypeViewModel objModel)
        {
            return _ProgramTypeRepository.Create(objModel);
        }

        public bool Update(ProgramTypeViewModel objModel)
        {
            return _ProgramTypeRepository.Update(objModel);
        }

        public bool Delete(ProgramTypeViewModel objModel)
        {
            return _ProgramTypeRepository.Delete(objModel);
        }
    }
}
