﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class PropertySaleService : IPropertySaleService
    {
        private readonly IPropertySaleRepository _PropertySaleRepository;

        private readonly IUnitOfWork _unitOfWork;

        public PropertySaleService(IPropertySaleRepository PropertySaleRepository,
            IUnitOfWork unitOfWork)
        {
            this._PropertySaleRepository = PropertySaleRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<PropertySaleViewModel> GetListAll()
        {
            return _PropertySaleRepository.GetListAll();
        }

        public List<PropertySaleViewModel> GetListById(int? Id)
        {
            return _PropertySaleRepository.GetListById(Id);
        }

        public List<PropertySaleViewModel> GetListByStatusId(int? StatusId)
        {
            return _PropertySaleRepository.GetListByStatusId(StatusId);
        }

        public List<PropertySaleViewModel> GetListByTypeId(int? TypeId)
        {
            return _PropertySaleRepository.GetListByTypeId(TypeId);
        }

        public List<PropertySaleViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _PropertySaleRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<PropertySaleViewModel> GetListActiveAll()
        {
            return _PropertySaleRepository.GetListActiveAll();
        }

        public List<PropertySaleViewModel> GetListActiveById(int? Id)
        {
            return _PropertySaleRepository.GetListActiveById(Id);
        }

        public List<PropertySaleViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _PropertySaleRepository.GetListActiveByStatusId(StatusId);
        }

        public List<PropertySaleViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _PropertySaleRepository.GetListActiveByTypeId(TypeId);
        }

        public List<PropertySaleViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _PropertySaleRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(PropertySaleViewModel objModel)
        {
            return _PropertySaleRepository.Create(objModel);
        }

        public bool Update(PropertySaleViewModel objModel)
        {
            return _PropertySaleRepository.Update(objModel);
        }

        public bool Delete(PropertySaleViewModel objModel)
        {
            return _PropertySaleRepository.Delete(objModel);
        }
    }
}
