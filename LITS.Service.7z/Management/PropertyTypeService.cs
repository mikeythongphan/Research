﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class PropertyTypeService : IPropertyTypeService
    {
        private readonly IPropertyTypeRepository _PropertyTypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public PropertyTypeService(IPropertyTypeRepository PropertyTypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._PropertyTypeRepository = PropertyTypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<PropertyTypeViewModel> GetListAll()
        {
            return _PropertyTypeRepository.GetListAll();
        }

        public List<PropertyTypeViewModel> GetListById(int Id)
        {
            return _PropertyTypeRepository.GetListById(Id);
        }

        public List<PropertyTypeViewModel> GetListByStatusId(int StatusId)
        {
            return _PropertyTypeRepository.GetListByStatusId(StatusId);
        }

        public List<PropertyTypeViewModel> GetListByTypeId(int TypeId)
        {
            return _PropertyTypeRepository.GetListByTypeId(TypeId);
        }

        public List<PropertyTypeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _PropertyTypeRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<PropertyTypeViewModel> GetListActiveAll()
        {
            return _PropertyTypeRepository.GetListActiveAll();
        }

        public List<PropertyTypeViewModel> GetListActiveById(int Id)
        {
            return _PropertyTypeRepository.GetListActiveById(Id);
        }

        public List<PropertyTypeViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _PropertyTypeRepository.GetListActiveByStatusId(StatusId);
        }

        public List<PropertyTypeViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _PropertyTypeRepository.GetListActiveByTypeId(TypeId);
        }

        public List<PropertyTypeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _PropertyTypeRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(PropertyTypeViewModel objModel)
        {
            return _PropertyTypeRepository.Create(objModel);
        }

        public bool Update(PropertyTypeViewModel objModel)
        {
            return _PropertyTypeRepository.Update(objModel);
        }

        public bool Delete(PropertyTypeViewModel objModel)
        {
            return _PropertyTypeRepository.Delete(objModel);
        }
    }
}
