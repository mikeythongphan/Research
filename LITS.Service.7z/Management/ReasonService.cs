﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class ReasonService : IReasonService
    {
        private readonly IReasonRepository _ReasonRepository;

        private readonly IUnitOfWork _unitOfWork;

        public ReasonService(IReasonRepository ReasonRepository,
            IUnitOfWork unitOfWork)
        {
            this._ReasonRepository = ReasonRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<ReasonViewModel> GetListAll()
        {
            return _ReasonRepository.GetListAll();
        }

        public List<ReasonViewModel> GetListById(int? Id)
        {
            return _ReasonRepository.GetListById(Id);
        }

        public List<ReasonViewModel> GetListByStatusId(int? StatusId)
        {
            return _ReasonRepository.GetListByStatusId(StatusId);
        }

        public List<ReasonViewModel> GetListByTypeId(int? TypeId)
        {
            return _ReasonRepository.GetListByTypeId(TypeId);
        }

        public List<ReasonViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _ReasonRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<ReasonViewModel> GetListActiveAll()
        {
            return _ReasonRepository.GetListActiveAll();
        }

        public List<ReasonViewModel> GetListActiveById(int? Id)
        {
            return _ReasonRepository.GetListActiveById(Id);
        }

        public List<ReasonViewModel> GetListActiveByStatusId(int? StatusId)
        {
            return _ReasonRepository.GetListActiveByStatusId(StatusId);
        }

        public List<ReasonViewModel> GetListActiveByTypeId(int? TypeId)
        {
            return _ReasonRepository.GetListActiveByTypeId(TypeId);
        }

        public List<ReasonViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            return _ReasonRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(ReasonViewModel objModel)
        {
            return _ReasonRepository.Create(objModel);
        }

        public bool Update(ReasonViewModel objModel)
        {
            return _ReasonRepository.Update(objModel);
        }

        public bool Delete(ReasonViewModel objModel)
        {
            return _ReasonRepository.Delete(objModel);
        }
    }
}
