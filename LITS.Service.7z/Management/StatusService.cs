﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class StatusService : IStatusService
    {
        private readonly IStatusRepository _StatusRepository;

        private readonly IUnitOfWork _unitOfWork;

        public StatusService(IStatusRepository StatusRepository,
            IUnitOfWork unitOfWork)
        {
            this._StatusRepository = StatusRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<StatusViewModel> GetListAll()
        {
            return _StatusRepository.GetListAll();
        }

        public List<StatusViewModel> GetListById(int Id)
        {
            return _StatusRepository.GetListById(Id);
        }

        public List<StatusViewModel> GetListByStatusId(int StatusId)
        {
            return _StatusRepository.GetListByStatusId(StatusId);
        }

        public List<StatusViewModel> GetListByTypeId(int TypeId)
        {
            return _StatusRepository.GetListByTypeId(TypeId);
        }

        public List<StatusViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _StatusRepository.GetListByStatusIdAndTypeId(StatusId, TypeId);
        }

        public List<StatusViewModel> GetListActiveAll()
        {
            return _StatusRepository.GetListActiveAll();
        }

        public List<StatusViewModel> GetListActiveById(int Id)
        {
            return _StatusRepository.GetListActiveById(Id);
        }

        public List<StatusViewModel> GetListActiveByStatusId(int StatusId)
        {
            return _StatusRepository.GetListActiveByStatusId(StatusId);
        }

        public List<StatusViewModel> GetListActiveByTypeId(int TypeId)
        {
            return _StatusRepository.GetListActiveByTypeId(TypeId);
        }

        public List<StatusViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            return _StatusRepository.GetListActiveByStatusIdAndTypeId(StatusId, TypeId);
        }

        public bool Create(StatusViewModel objModel)
        {
            return _StatusRepository.Create(objModel);
        }

        public bool Update(StatusViewModel objModel)
        {
            return _StatusRepository.Update(objModel);
        }

        public bool Delete(StatusViewModel objModel)
        {
            return _StatusRepository.Delete(objModel);
        }
    }
}
