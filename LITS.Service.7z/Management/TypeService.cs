﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Interface.Service.Management;
using LITS.Model.Views.Management;

namespace LITS.Service.Management
{
    public class TypeService : ITypeService
    {
        private readonly ITypeRepository _TypeRepository;

        private readonly IUnitOfWork _unitOfWork;

        public TypeService(ITypeRepository TypeRepository,
            IUnitOfWork unitOfWork)
        {
            this._TypeRepository = TypeRepository;
            this._unitOfWork = unitOfWork;
        }

        public List<TypeViewModel> GetListAll()
        {
            return _TypeRepository.GetListAll();
        }

        public List<TypeViewModel> GetListById(int? Id)
        {
            return _TypeRepository.GetListById(Id);
        }

        public List<TypeViewModel> GetListByParentId(int? ParentId)
        {
            return _TypeRepository.GetListByParentId(ParentId);
        }

        public List<TypeViewModel> GetListActiveAll()
        {
            return _TypeRepository.GetListActiveAll();
        }

        public List<TypeViewModel> GetListActiveById(int? Id)
        {
            return _TypeRepository.GetListActiveById(Id);
        }

        public List<TypeViewModel> GetListActiveByParentId(int? ParentId)
        {
            return _TypeRepository.GetListActiveByParentId(ParentId);
        }

        public bool Create(TypeViewModel objModel)
        {
            return _TypeRepository.Create(objModel);
        }

        public bool Update(TypeViewModel objModel)
        {
            return _TypeRepository.Update(objModel);
        }

        public bool Delete(TypeViewModel objModel)
        {
            return _TypeRepository.Delete(objModel);
        }
    }
}
