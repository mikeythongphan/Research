# Contribution
- Before you start writing a pull request you should discuss it using GitHub issues.
- Bugs, improvements or features should be reported using GitHub issues.
