﻿namespace MvcTemplate.Components.Alerts
{
    public enum AlertType
    {
        Danger,
        Warning,
        Info,
        Success
    }
}
