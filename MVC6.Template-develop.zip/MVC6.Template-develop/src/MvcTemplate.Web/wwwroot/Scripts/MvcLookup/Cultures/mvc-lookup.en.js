﻿window.cultures = window.cultures || {};
window.cultures.lookup = window.cultures.lookup || {};
window.cultures.lookup['en'] = {
    error: 'Error while retrieving records',
    noData: 'No data found',
    select: 'Select ({0})',
    search: 'Search...'
};
