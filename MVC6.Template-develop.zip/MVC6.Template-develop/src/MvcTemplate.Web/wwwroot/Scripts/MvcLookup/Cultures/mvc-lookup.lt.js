﻿window.cultures = window.cultures || {};
window.cultures.lookup = window.cultures.lookup || {};
window.cultures.lookup['lt'] = {
    error: 'Įvyko klaida, susisiekite su administratoriumi',
    select: 'Pasirinkti ({0})',
    noData: 'Irašų nerasta',
    search: 'Ieškoti...'
};
