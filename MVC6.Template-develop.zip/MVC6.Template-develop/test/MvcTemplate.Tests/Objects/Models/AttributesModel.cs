﻿using System;

namespace MvcTemplate.Tests.Objects
{
    public class AttributesModel
    {
        public Int32 Sum { get; set; }
        public Int32 Total { get; set; }
    }
}
