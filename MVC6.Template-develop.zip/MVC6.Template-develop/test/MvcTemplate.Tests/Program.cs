﻿namespace MvcTemplate.Tests
{
    public class Program
    {
        public static void Main()
        {
        }
    }
}
