﻿using MvcTemplate.Components.Extensions;

namespace MvcTemplate.Tests.Unit.Components.Extensions
{
    public class JsTreeView
    {
        public JsTree JsTree { get; set; }

        public JsTreeView()
        {
            JsTree = new JsTree();
        }
    }
}
