
var gulp = require("gulp");
var shell = require("gulp-shell");
var merge = require("merge-stream")();
var rimraf = require("rimraf");
var runSequence = require("run-sequence");
var Q = require("q");

//=================================== Method ===================================

var deletePathAsync = function (str) {

    var deferred = Q.defer();
    rimraf(str, function (err) {
        if (err)
            deferred.reject(err);
        else
            deferred.resolve();
    });
    return deferred.promise;

};

var getCopyFilesPipe = function (sourcePatten, targetPath) {

    return gulp.src(sourcePatten)
        .pipe(gulp.dest(targetPath));

};

gulp.task("copySettingFileToCore", function () {

    merge.add(getCopyFilesPipe(
        "./src/Web/appsettings.json*",
        "./src/Core"
        ));

    return merge;

});

gulp.task("copySettingFileToWebTest", function () {

    merge.add(getCopyFilesPipe(
        "./src/Web/appsettings.json*",
        "./src/Web.Test"
        ));

    return merge;

});

gulp.task("cleanCoreSettingFileAndCoreMigration", function (cb) {

    deletePathAsync("./src/Core/appsettings.json")
        .then(function () {
            return deletePathAsync("./src/Core/Migrations");
        })
        .fin(function () {
            cb();
        });

});

gulp.task("cleanCoreSettingFile", function (cb) {

    deletePathAsync("./src/Core/appsettings.json")
        .fin(function () {
            cb();
        });

});

gulp.task("cleanWebTestSettingFile", function (cb) {

    deletePathAsync("./src/Web.Test/appsettings.json")
        .fin(function () {
            cb();
        });

});

gulp.task("dbMigration", shell.task([

    "cd src/Core && dnx ef migrations add dbMigration"

]));

gulp.task("dbUpdate", shell.task([

    "cd src/Core && dnx ef database update"

]));

gulp.task("testWebTestAndCoreTest", shell.task([

// "cd src/Core && dnu build",
// "cd src/Core.Test && dnu build",
// "cd src/Web && dnu build",
// "cd src/Web.Test && dnu build",
//"dnx -p src/Core.Test/project.json test",
//"dnx -p src/Web.Test/project.json test",
//"gulp --gulpfile src/Client/gulpfile.js default"
    
    //"~/.dnx/runtimes/dnx-coreclr-darwin-x64.1.0.0-rc1-update1/bin/dnx -p src/Core.Test/project.json test",
    "~/.dnx/runtimes/dnx-coreclr-darwin-x64.1.0.0-rc1-update1/bin/dnx -p src/Web.Test/project.json test",

]));

//=================================== Tasks ===================================

//db migration
gulp.task("dbm", function (cb) {
    runSequence(
        "cleanCoreSettingFileAndCoreMigration",
        "copySettingFileToCore",
        "dbMigration",
        "cleanCoreSettingFile",
        cb
        );
});

gulp.task("dbu", function (cb) {
    runSequence(
        "copySettingFileToCore",
        "dbUpdate",
        "cleanCoreSettingFileAndCoreMigration",
        cb
        );
});

//restore
gulp.task("restore", shell.task([

    "cd src/Core && dnu restore",
    "cd src/Core.Test && dnu restore",
    "cd src/Web && dnu restore",
    "cd src/Web.Test && dnu restore"

]));

//run test
gulp.task("test", function (cb) {
    runSequence(
        "copySettingFileToWebTest",
        "testWebTestAndCoreTest",
        "cleanWebTestSettingFile",
        cb
        );
});


//run server
gulp.task("server", shell.task([

    "nodemon --ext 'cs,json' --exec 'dnx -p src/Web/project.json web'"

]));

