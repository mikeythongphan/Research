﻿using LightMock;
using MyMVC6Template.Core.Interfaces.Repositories;
using MyMVC6Template.Core.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyMVC6Template.Core.Test.Mocks
{
    public class MyInfoRepositoryMock : IMyInfoRepository
    {
        private IInvocationContext<IMyInfoRepository> _contextMock;

        public MyInfoRepositoryMock()
        {
            this._contextMock = new MockContext<IMyInfoRepository>();
        }

        public MockContext<IMyInfoRepository> Mock
        {
            get
            {
                return this._contextMock as MockContext<IMyInfoRepository>;
            }
        }

        public IList<Person> GetPersons()
        {
            return this._contextMock.Invoke(a => a.GetPersons());
        }

    }
}
