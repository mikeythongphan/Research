﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LightMock;
using Xunit;
using MyMVC6Template.Core.Interfaces.Repositories;
using MyMVC6Template.Core.Models.Entities;
using MyMVC6Template.Core.Services;
using MyMVC6Template.Core.Common;
using MyMVC6Template.Core.Test.Mocks;


namespace MyMVC6Template.Core.Test.Services
{
    //https://github.com/neil-119/LightMock
    //https://xunit.github.io/docs/getting-started-dnx.html
    public class MyInfoService
    {
        //GetInfo
        [Fact]
        void GetInfo_ToTest_PersonList()
        {
            var rep = new MyInfoRepositoryMock();
            var expectedCount = 2;
            var expectedP1 = FakeDataProvider.GetPerson(9);
            var expectedP2 = FakeDataProvider.GetPerson(77);
            var mock = rep.Mock;
            mock.Arrange(a => a.GetPersons())
                .Returns(() =>
                {
                    var list = new List<Person>();
                    list.Add(FakeDataProvider.GetPerson(9));
                    list.Add(FakeDataProvider.GetPerson(77));
                    return list;
                });


            var ser = new Core.Services.MyInfoService(rep);
            var actual = ser.GetInfo();


            Assert.Equal(expectedCount, actual.Count);
            mock.Assert(a => a.GetPersons(), Invoked.Once);

            var item1 = actual.First();
            Assert.Equal(expectedP1.Name, item1.Name);
            Assert.Equal(expectedP1.Age, item1.Age);
            Assert.Equal(expectedP1.Birthday, item1.Birthday);

            var item2 = actual.Skip(1).First();
            Assert.Equal(expectedP2.Name, item2.Name);
            Assert.Equal(expectedP2.Age, item2.Age);
        }
    }
}
