﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Autofac;

namespace MyMVC6Template.Core.Common
{
    public class AppHelper
    {
        public static string RootPath { get; set; }

        public static IContainer AutofacContainer { get; set; }

        private static IConfigurationRoot _configuration;
        public static IConfigurationRoot Configuration
        {
            get
            {
                if (_configuration == null)
                    AppHelper._configuration = new ConfigurationBuilder()
                                                    .AddJsonFile("appsettings.json")
                                                    .Build();
                return AppHelper._configuration;
            }
        }

        public static void ConsoleLog(object obj)
        {
            var str = Newtonsoft.Json.JsonConvert.SerializeObject(obj,
                    Formatting.None,
                    new JsonSerializerSettings()
                    {
                        ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                    });
            Console.WriteLine("=======================================");
            Console.WriteLine(str);

        }

    }
}
