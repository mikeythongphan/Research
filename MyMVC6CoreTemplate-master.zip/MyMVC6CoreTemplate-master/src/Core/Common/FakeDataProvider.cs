﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MyMVC6Template.Core.Interfaces.Repositories;
using MyMVC6Template.Core.Models.Entities;

namespace MyMVC6Template.Core.Common
{
    public static class FakeDataProvider
    {

        public static Person GetPerson(int salt)
        {
            var p = new Person();
            var guid = new Guid("d3eff50c-cbb4-42da-b1de-4a8fb679c951");
            var birthday = new DateTime(2014, 1, 3, 11, 25, 11);
            var dtCreated = new DateTime(2000, 5, 6, 8, 11, 9);
            p.Id = guid;
            p.Name = $"Bb{salt}";
            p.Age = 18 + salt;
            p.Birthday = birthday.AddYears(salt);
            p.Created = dtCreated.AddDays(salt);
            return p;
        }

    }
}
