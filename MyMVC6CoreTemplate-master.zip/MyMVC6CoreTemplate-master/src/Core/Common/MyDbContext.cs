﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.Entity;
using Microsoft.Data.Entity.Infrastructure;
using MyMVC6Template.Core.Models.Entities;


namespace MyMVC6Template.Core.Common
{
    //http://ef.readthedocs.org/en/latest/getting-started/aspnet5/new-db.html
    public class MyDbContext : DbContext
    {
        private bool isConfigurable = true;

        public MyDbContext() { }

        public MyDbContext(DbContextOptions options) : base(options)
        {
            this.isConfigurable = false;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (isConfigurable)
            {
                var connectionString = AppHelper.Configuration["Data:ConnectionString"];
                optionsBuilder.UseSqlServer(connectionString);

                Console.WriteLine(connectionString);
            }
            base.OnConfiguring(optionsBuilder);
        }

        public DbSet<Person> Persons { get; set; }

        public DbSet<User> Users { get; set; }
        public DbSet<UserRoleRel> UserRoleRels { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<RolePermissionRel> RolePermissionRels { get; set; }
        public DbSet<Permission> Permissions { get; set; }

    }
}
