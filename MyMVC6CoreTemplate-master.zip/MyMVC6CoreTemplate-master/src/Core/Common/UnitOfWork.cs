﻿using Microsoft.Data.Entity;
using MyMVC6Template.Core.Interfaces.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyMVC6Template.Core.Common
{
    public class UnitOfWork : IUnitOfWork
    {
        private DbContext _db;

        public UnitOfWork(DbContext db)
        {
            this._db = db;
        }

        public DbContext Context
        {
            get
            {
                return this._db;
            }
        }

        public void Dispose()
        {
            this.Context.Dispose();
        }

        public void SaveToChanges()
        {
            this.Context.SaveChanges();
        }

        public void SaveToChangesAsync()
        {
            this.Context.SaveChangesAsync();
        }
    }
}
