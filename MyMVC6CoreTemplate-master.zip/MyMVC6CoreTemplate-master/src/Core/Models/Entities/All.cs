﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.Entity.Metadata.Internal;

namespace MyMVC6Template.Core.Models.Entities
{
    public class Person
    {
        [Key]
        public Guid Id { get; set; }
        [Required]
        public string Name { get; set; }
        public int Age { get; set; }
        public DateTime Birthday { get; set; }
        [Required]
        public DateTime Created { get; set; }
    }



    public class Permission
    {
        public IList<RolePermissionRel> RolePermissionRels { get; set; }

        public Permission()
        {
            this.RolePermissionRels = new List<RolePermissionRel>();
        }

        [Key]
        public Guid Id { get; set; }
        [Required]
        [MaxLength(50)]
        public string Name { get; set; }
        public bool IsEnabled { get; set; }
    }

    public class RolePermissionRel
    {
        [Key]
        public Guid Id { get; set; }
        public Role Role { get; set; }
        public Permission Permission { get; set; }
    }

    public class Role
    {
        public IList<UserRoleRel> UserRoleRels { get; set; }
        public IList<RolePermissionRel> RolePermissionRels { get; set; }

        public Role()
        {
            this.UserRoleRels = new List<UserRoleRel>();
            this.RolePermissionRels = new List<RolePermissionRel>();
        }

        [Key]
        public Guid Id { get; set; }
        [Required]
        [MaxLength(50)]
        public string Name { get; set; }
    }

    public class UserRoleRel
    {
        [Key]
        public Guid Id { get; set; }
        public User User { get; set; }
        public Role Role { get; set; }
    }

    public class User
    {
        public IList<UserRoleRel> UserRoleRels { get; set; }

        public User()
        {
            this.UserRoleRels = new List<UserRoleRel>();
        }

        [Key]
        public Guid Id { get; set; }
        [Required]
        [MaxLength(50)]
        public string Name { get; set; }
        [Required]
        public string Email { get; set; }
    }

}
