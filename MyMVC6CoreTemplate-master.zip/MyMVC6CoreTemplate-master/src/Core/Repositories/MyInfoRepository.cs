﻿using Microsoft.Data.Entity;
using MyMVC6Template.Core.Common;
using MyMVC6Template.Core.Interfaces.Repositories;
using MyMVC6Template.Core.Models.Entities;
using MyMVC6Template.Core.Interfaces.Common;
using MyMVC6Template.Core.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyMVC6Template.Core.Repositories
{
    public class MyInfoRepository :
        RepositoryBase<MyDbContext>,
        IMyInfoRepository
    {
        public MyInfoRepository(IUnitOfWork unitOfWork)
            : base(unitOfWork)
        { }

        public IList<Person> GetPersons()
        {
            // var fakeData = new[]{
            //     FakeDataProvider.GetPerson(9),
            //     FakeDataProvider.GetPerson(87)
            // }.ToList();
            // return fakeData;


            return this._myContext.Persons.ToList();
        }
    }
}
