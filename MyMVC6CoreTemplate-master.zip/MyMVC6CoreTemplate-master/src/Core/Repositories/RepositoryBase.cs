﻿using Microsoft.Data.Entity;
using MyMVC6Template.Core.Interfaces.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyMVC6Template.Core.Repositories
{
    public abstract class RepositoryBase<T> where T : DbContext
    {
        protected T _myContext;
        public RepositoryBase(IUnitOfWork unitOfWork)
        {
            this._myContext = unitOfWork.Context as T;
        }
    }
}
