﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.AspNet.TestHost;
using Microsoft.Data.Entity;
using Xunit;
using Autofac;
using LightMock;
using Autofac.Extensions.DependencyInjection;
using MyMVC6Template.Core.Common;
using MyMVC6Template.Core.Models.DTOs;
using MyMVC6Template.Core.Models.Entities;
using MyMVC6Template.Core.Interfaces.Services;
using MyMVC6Template.Core.Interfaces.Repositories;
using MyMVC6Template.Core.Test.Mocks;

namespace MyMVC6Template.Web.Test.Controllers.Api
{
    public class MyInfoController
    {
        private readonly TestServer _server;
        private readonly HttpClient _client;
        public MyInfoController()
        {
            _server = new TestServer(TestServer.CreateBuilder()
                .UseStartup<Startup>());
            _client = _server.CreateClient();
        }

        [Fact]
        public async void MyInfo_MockRepository()
        {
            // Arrange
            var builder = new ContainerBuilder();
            var rep = new MyInfoRepositoryMock();
            rep.Mock.Arrange(a => a.GetPersons())
            .Returns(() =>
            {
                var list = new List<Person>();
                list.Add(FakeDataProvider.GetPerson(1));
                list.Add(FakeDataProvider.GetPerson(2));
                return list;
            });
            builder.RegisterInstance(rep).As<IMyInfoRepository>();
            var c = AppHelper.AutofacContainer;
            builder.Update(c);

            var expected0 = FakeDataProvider.GetPerson(1);
            var expected1 = FakeDataProvider.GetPerson(2);

            var path = "/Api/MyInfo/abc";

            using (var scope = c.BeginLifetimeScope())
            {
                var req = await _client.GetAsync(path);
                req.EnsureSuccessStatusCode();
                var body = await req.Content.ReadAsStringAsync();
                var actualArr = JsonConvert.DeserializeObject<List<PersonViewModel>>(body);

                // Assert
                rep.Mock.Assert(a => a.GetPersons(), Invoked.Once);

                Assert.Equal(expected0.Name, actualArr.First().Name);
                Assert.Equal(expected0.Age, actualArr.First().Age);
                Assert.Equal(expected0.Birthday, actualArr.First().Birthday);

                Assert.Equal(expected1.Name, actualArr.Skip(1).First().Name);
                Assert.Equal(expected1.Age, actualArr.Skip(1).First().Age);
                Assert.Equal(expected1.Birthday, actualArr.Skip(1).First().Birthday);
            }
        }

        private MyDbContext GetMyDbContextMock()
        {
            var db = new DbContextOptionsBuilder();
            db.UseInMemoryDatabase();
            var mc = new MyDbContext(db.Options);

            var builder = new ContainerBuilder();
            builder.RegisterInstance(mc).As<DbContext>();
            var c = AppHelper.AutofacContainer;
            builder.Update(c);
            return mc;
        }

        [Fact]
        public async void MyInfo_EF7MemoryDb()
        {
            var myDb = this.GetMyDbContextMock();

            using (var scope = AppHelper.AutofacContainer.BeginLifetimeScope())
            {
                var u = new User();
                u.Id = Guid.NewGuid();
                u.Name = "Bibby";
                u.Email = "bb@bb.bb";

                var r = new Role();
                r.Id = Guid.NewGuid();
                r.Name = "BibbyRole";

                var urRel = new UserRoleRel();
                urRel.Id = Guid.NewGuid();
                urRel.User = u;
                urRel.Role = r;

                myDb.UserRoleRels.Add(urRel);
                myDb.Users.Add(u);
                myDb.Roles.Add(r);
                myDb.SaveChanges();

                var uObj = myDb.Users
                            .Select(a => new
                            {
                                User_____ = a,
                                Role_____ = a.UserRoleRels.FirstOrDefault(),
                                Rel______ = a.UserRoleRels.FirstOrDefault().Role,
                            })
                            .ToList();
                AppHelper.ConsoleLog(uObj);

                var rObj = myDb.Users
                                .Select(a => a.UserRoleRels.FirstOrDefault().Role)
                                .FirstOrDefault();

                AppHelper.ConsoleLog(rObj);
            }

        }

    }
}
