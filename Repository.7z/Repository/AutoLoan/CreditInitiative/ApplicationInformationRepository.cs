﻿
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Data.Repository.AutoLoan.CreditInitiative
{
    public class ApplicationInformationRepository : RepositoryBase<ApplicationInformationViewModel>, IApplicationInformationRepository
    {
        public ApplicationInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
     
    }
}
