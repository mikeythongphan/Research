﻿using System;
using System.Collections.Generic;
using PagedList;
using System.Linq;
using System.Data.Entity;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Core.Resources;
using LITS.Interface.Repository.AutoLoan.CreditInitiative;
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;
using LITS.Core.Main;

namespace LITS.Data.Repository.AutoLoan.CreditInitiative
{
    public class CreditInitiativeRepository : RepositoryBase<CreditInitiativeViewModel>, ICreditInitiativeRepository
    {
        private LITSEntities _LITSEntities;

        public CreditInitiativeRepository(IDatabaseFactory databaseFactory,
           LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }
    }
}
