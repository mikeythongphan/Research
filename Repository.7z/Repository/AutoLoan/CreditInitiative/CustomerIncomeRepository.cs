﻿
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.CreditInitiative;
using LITS.Model.PartialViews.AutoLoan.CreditInitiative;

namespace LITS.Data.Repository.AutoLoan.CreditInitiative
{
    public class CustomerIncomeRepository : RepositoryBase<CustomerIncomeViewModel>, ICustomerIncomeRepository
    {
        public CustomerIncomeRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

    }
}
