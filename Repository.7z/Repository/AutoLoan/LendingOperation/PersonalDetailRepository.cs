﻿
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.LendingOperation;
using LITS.Model.PartialViews.AutoLoan.LendingOperation;

namespace LITS.Data.Repository.AutoLoan.LendingOperation
{
    public class PersonalDetailRepository : RepositoryBase<PersonalDetailViewModel>, IPersonalDetailRepository
    {
        public PersonalDetailRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

    }
}
