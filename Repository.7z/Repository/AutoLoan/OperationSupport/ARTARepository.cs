﻿using System;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.OperationSupport;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;
using PagedList;
using System.Linq.Expressions;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class ARTARepository : RepositoryBase<ARTAViewModel>, IARTARepository
    {
        public ARTARepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
    }
}
