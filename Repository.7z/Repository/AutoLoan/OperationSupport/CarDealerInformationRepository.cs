﻿using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.OperationSupport;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class CarDealerInformationRepository : RepositoryBase<CarDealerInformationViewModel>, ICarDealerInformationRepository
    {
        public CarDealerInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
    }
}
