﻿using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.AutoLoan.OperationSupport;
using LITS.Model.PartialViews.AutoLoan.OperationSupport;

namespace LITS.Data.Repository.AutoLoan.OperationSupport
{
    public class CollateralInformationRepository : RepositoryBase<CollateralInformationViewModel>, ICollateralInformationRepository
    {
        public CollateralInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }

    }
}
