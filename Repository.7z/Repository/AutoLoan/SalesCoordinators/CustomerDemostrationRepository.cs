﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class CustomerDemostrationRepository : RepositoryBase<CustomerDemostrationViewModel>, Interface.Repository.AutoLoan.SalesCoordinators.ICustomerDemostrationRepository
    {
        public CustomerDemostrationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
    }
}
