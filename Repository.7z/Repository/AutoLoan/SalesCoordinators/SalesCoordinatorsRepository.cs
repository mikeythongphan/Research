﻿using System;
using System.Collections.Generic;
using PagedList;
using System.Linq;
using System.Data.Entity;
using System.Linq.Expressions;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Core.Resources;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.Views.AutoLoan;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using LITS.Core.Main;

namespace LITS.Data.Repository.AutoLoan.SalesCoordinators
{
    public class SalesCoordinatorsRepository : RepositoryBase<SalesCoordinatorsViewModel>, ISalesCoordinatorsRepository
    {
        private LITSEntities _LITSEntities;

        public SalesCoordinatorsRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_sales_channel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_sales_channel Get(Expression<Func<m_sales_channel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_sales_channel> GetMany(Expression<Func<m_sales_channel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_sales_channel> GetPage<TOrder>(Page page, Expression<Func<m_sales_channel, bool>> where, Expression<Func<m_sales_channel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public SalesCoordinatorsViewModel LoadIndex(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            ApplicationInformationViewModel objApp = new ApplicationInformationViewModel();

            #region ApplicationInformation

            var dataApp = _LITSEntities.application_information.FirstOrDefault(p => p.pk_id == objParam._ApplicationInformationViewModel.ApplicationInformationID);
            objApp = AutoMapper.Mapper.Map<application_information, ApplicationInformationViewModel>(dataApp);
            objParam._ApplicationInformationViewModel = objApp;

            //objParam._ApplicationInformationViewModel._ApplicationDuplicationViewModel =
            //    _LITSEntities.application_duplication.Where(x => x.fk_application_information_id == objParam._ApplicationInformationViewModel.ApplicationInformationID).ToList();
            #endregion

            return objParam;
        }

        public SalesCoordinatorsViewModel Save(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public SalesCoordinatorsViewModel Submit(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public SalesCoordinatorsViewModel NSG(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public SalesCoordinatorsViewModel Cancel(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public SalesCoordinatorsViewModel Delete(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        public SalesCoordinatorsViewModel FRMQueue(SalesCoordinatorsViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }
        #endregion
    }
}
