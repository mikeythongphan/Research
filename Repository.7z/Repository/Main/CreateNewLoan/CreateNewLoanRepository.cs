﻿using System;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Data.Entity;
using System.Linq.Expressions;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Repository.Main.CreateNewLoan;
using LITS.Model.Views.Main;
using LITS.Model.PartialViews.Main.CreateNewLoan;

namespace LITS.Data.Repository.Main.CreateNewLoan
{
    public class CreateNewLoanRepository : RepositoryBase<CreateNewLoanViewModel>, ICreateNewLoanRepository
    {
        private LITSEntities _LITSEntities;

        public CreateNewLoanRepository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(CreateNewLoanViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<CreateNewLoanViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public CreateNewLoanViewModel Get(Expression<Func<CreateNewLoanViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CreateNewLoanViewModel> GetMany(Expression<Func<CreateNewLoanViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<CreateNewLoanViewModel> GetPage<TOrder>(Page page, Expression<Func<CreateNewLoanViewModel, bool>> where, Expression<Func<CreateNewLoanViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(CreateNewLoanViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        /// <summary>
        /// LoadIndexStep1
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep1(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
           var varType = _LITSEntities.m_type.Where(x => x.is_active == true && (x.pk_id == 2 || x.parent_id == 2)).ToList();

            objParam._CreateNewLoanStep1ViewModel.lstCreateNewLoanStep1Tree =
                Mapper.Map<List<m_type>, List<CreateNewLoanStep1TreeViewModel>>(varType);

            return objParam;
        }

        /// <summary>
        /// LoadIndexStep2
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep2(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// LoadIndexStep3
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel LoadIndexStep3(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// GetApplicationNextAppNo
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel GetApplicationNextAppNo(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            //BusinessRule.GetApplicationNextAppNo(objParam._applicationInformationViewModel.AnchorProduct, DateTime.Now);
            return objParam;
        }

        /// <summary>
        /// CreateNewLoan
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CreateNewLoan(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// CheckBlackList
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CheckBlackList(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// CheckDeDuplicate
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel CheckDeDuplicate(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        /// <summary>
        /// Submit
        /// </summary>
        /// <param name="objParam"></param>
        /// <param name="AreaNameParam"></param>
        /// <param name="ControllerNameParam"></param>
        /// <param name="UserPWIDParam"></param>
        /// <returns></returns>
        public CreateNewLoanViewModel Submit(CreateNewLoanViewModel objParam, string AreaNameParam, string ControllerNameParam, string UserPWIDParam)
        {
            return objParam;
        }

        //public SalesCoordinatorsViewModel CreateNewLoan(SalesCoordinatorsViewModel objParam, string strAreaName, string strControllerName)
        //{
        //    using (var context = new LITSEntities())
        //    {
        //        using (DbContextTransaction transaction = context.Database.BeginTransaction())
        //        {
        //            try
        //            {
        //                var data = AutoMapper.Mapper.Map<ApplicationInformationViewModel, application_information>(objParam._applicationInformationViewModel);

        //                context.application_information.Add(data);
        //                context.SaveChanges();

        //                #region AutoLoanPersonal

        //                if (objParam._applicationInformationViewModel.ApplicationTypeID == (int)EnumList.LoanType.AutoLoanPersonal)
        //                {
        //                    al_personal_application _al_personal_application = new al_personal_application();
        //                    _al_personal_application.fk_application_information_id = data.pk_id;
        //                    _al_personal_application.is_active = data.is_active;
        //                    _al_personal_application.fk_type_id = data.fk_m_type_id;
        //                    _al_personal_application.fk_status_id = data.fk_m_status_id;
        //                    _al_personal_application.created_date = data.created_date;
        //                    _al_personal_application.created_by = data.created_by;

        //                    context.al_personal_application.Add(_al_personal_application);
        //                    context.SaveChanges();
        //                }

        //                #endregion

        //                #region AutoLoanCorporate
        //                if (objParam._applicationInformationViewModel.ApplicationTypeID == (int)EnumList.LoanType.AutoLoanCorporate)
        //                {
        //                    al_corporate_application _al_corporate_application = new al_corporate_application();
        //                    _al_corporate_application.fk_application_information_id = data.pk_id;
        //                    _al_corporate_application.is_active = data.is_active;
        //                    _al_corporate_application.fk_type_id = data.fk_m_type_id;
        //                    _al_corporate_application.fk_status_id = data.fk_m_status_id;
        //                    _al_corporate_application.created_date = data.created_date;
        //                    _al_corporate_application.created_by = data.created_by;

        //                    context.al_corporate_application.Add(_al_corporate_application);
        //                    context.SaveChanges();
        //                }
        //                #endregion

        //                #region Customer Information Main

        //                customer_information _customer_information_main = new customer_information();
        //                _customer_information_main.fk_application_information_id = data.pk_id;
        //                _customer_information_main.is_active = data.is_active;
        //                _customer_information_main.fk_type_id = data.fk_m_type_id;
        //                _customer_information_main.fk_status_id = data.fk_m_status_id;
        //                _customer_information_main.created_date = data.created_date;
        //                _customer_information_main.created_by = data.created_by;
        //                _customer_information_main.initital = objParam._customerInformationViewModel.Intitial_Main;
        //                _customer_information_main.full_name = objParam._customerInformationViewModel.FullName_Main;
        //                _customer_information_main.dob = objParam._customerInformationViewModel.DOB_Main;
        //                _customer_information_main.fk_m_borrower_type_id = (int)EnumList.BorrowerType.MainBorrower;

        //                context.customer_information.Add(_customer_information_main);
        //                context.SaveChanges();

        //                objParam._customerInformationViewModel.IsActive_Main = (bool)_customer_information_main.is_active;
        //                objParam._customerInformationViewModel.CreateBy_Main = _customer_information_main.created_by;
        //                objParam._customerInformationViewModel.CreateDate_Main = _customer_information_main.created_date;

        //                #endregion

        //                #region Customer Information Co1

        //                customer_information _customer_information_co1 = new customer_information();
        //                _customer_information_co1.fk_application_information_id = data.pk_id;
        //                _customer_information_co1.is_active = data.is_active;
        //                _customer_information_co1.fk_type_id = data.fk_m_type_id;
        //                _customer_information_co1.fk_status_id = data.fk_m_status_id;
        //                _customer_information_co1.created_date = data.created_date;
        //                _customer_information_co1.created_by = data.created_by;
        //                _customer_information_co1.initital = objParam._customerInformationViewModel.Intitial_Co1;
        //                _customer_information_co1.full_name = objParam._customerInformationViewModel.FullName_Co1;
        //                _customer_information_co1.dob = objParam._customerInformationViewModel.DOB_Co1;
        //                _customer_information_co1.fk_m_borrower_type_id = (int)EnumList.BorrowerType.CoBorrower1;

        //                context.customer_information.Add(_customer_information_co1);
        //                context.SaveChanges();

        //                #endregion

        //                #region Customer Information Co2

        //                customer_information _customer_information_co2 = new customer_information();
        //                _customer_information_co2.fk_application_information_id = data.pk_id;
        //                _customer_information_co2.is_active = data.is_active;
        //                _customer_information_co2.fk_type_id = data.fk_m_type_id;
        //                _customer_information_co2.fk_status_id = data.fk_m_status_id;
        //                _customer_information_co2.created_date = data.created_date;
        //                _customer_information_co2.created_by = data.created_by;
        //                _customer_information_co2.initital = objParam._customerInformationViewModel.Intitial_Co2;
        //                _customer_information_co2.full_name = objParam._customerInformationViewModel.FullName_Co2;
        //                _customer_information_co2.dob = objParam._customerInformationViewModel.DOB_Co2;
        //                _customer_information_co2.fk_m_borrower_type_id = (int)EnumList.BorrowerType.CoBorrower2;

        //                context.customer_information.Add(_customer_information_co2);
        //                context.SaveChanges();

        //                #endregion

        //                #region Customer Information Co3

        //                customer_information _customer_information_co3 = new customer_information();
        //                _customer_information_co3.fk_application_information_id = data.pk_id;
        //                _customer_information_co3.is_active = data.is_active;
        //                _customer_information_co3.fk_type_id = data.fk_m_type_id;
        //                _customer_information_co3.fk_status_id = data.fk_m_status_id;
        //                _customer_information_co3.created_date = data.created_date;
        //                _customer_information_co3.created_by = data.created_by;
        //                _customer_information_co3.initital = objParam._customerInformationViewModel.Intitial_Co3;
        //                _customer_information_co3.full_name = objParam._customerInformationViewModel.FullName_Co3;
        //                _customer_information_co3.dob = objParam._customerInformationViewModel.DOB_Co3;
        //                _customer_information_co3.fk_m_borrower_type_id = (int)EnumList.BorrowerType.CoBorrower3;

        //                context.customer_information.Add(_customer_information_co3);
        //                context.SaveChanges();

        //                #endregion

        //                transaction.Commit();

        //                objParam._applicationInformationViewModel = AutoMapper.Mapper.Map<application_information, ApplicationInformationViewModel>(data);
        //            }
        //            catch (Exception ex)
        //            {
        //                transaction.Rollback();
        //                throw ex;
        //            }
        //        }
        //    }

        //    return objParam;
        //}
        #endregion
    }
}
