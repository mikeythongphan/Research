﻿using System;
using System.Linq;
using PagedList;
using AutoMapper;
using System.Linq.Expressions;
using System.Collections.Generic;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Interface.Repository.Main.CreateNewLoan;
using LITS.Model.Views.Main;
using LITS.Model.PartialViews.Main.CreateNewLoan;

namespace LITS.Data.Repository.Main.CreateNewLoan
{
    public class CreateNewLoanStep3Repository : RepositoryBase<CreateNewLoanStep3ViewModel>, ICreateNewLoanStep3Repository
    {
        private LITSEntities _LITSEntities;

        public CreateNewLoanStep3Repository(IDatabaseFactory databaseFactory,
            LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }


        #region Base

        public void Add(CreateNewLoanStep3ViewModel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<CreateNewLoanStep3ViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public CreateNewLoanStep3ViewModel Get(Expression<Func<CreateNewLoanStep3ViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CreateNewLoanStep3ViewModel> GetMany(Expression<Func<CreateNewLoanStep3ViewModel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<CreateNewLoanStep3ViewModel> GetPage<TOrder>(Page page, Expression<Func<CreateNewLoanStep3ViewModel, bool>> where, Expression<Func<CreateNewLoanStep3ViewModel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(CreateNewLoanStep3ViewModel entity)
        {
            throw new NotImplementedException();
        }

        #endregion


    }
}
