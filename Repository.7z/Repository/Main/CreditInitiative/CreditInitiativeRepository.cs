﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Factory;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Configuration;
using LITS.Model.Views.Main;
using LITS.Interface.Repository.Main.SalesCoordinators;

namespace LITS.Data.Repository.Main
{
    public class CreditInitiativeRepository : RepositoryBase<SalesCoordinatorsViewModel>, ISalesCoordinatorsRepository
    {
        public CreditInitiativeRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        {}
    }
}
