﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Model.PartialViews.Main.SalesCoordinators;
using LITS.Interface.Repository.Main.SalesCoordinators;
using LITS.Interface.Repository.AutoLoan.SalesCoordinators;
using LITS.Model.PartialViews.AutoLoan.SalesCoordinators;
using PagedList;
using System.Linq.Expressions;

namespace LITS.Data.Repository.Main.SalesCoordinators
{
    public class ApplicationInformationRepository : RepositoryBase<Model.PartialViews.AutoLoan.SalesCoordinators.ApplicationInformationViewModel>, LITS.Interface.Repository.AutoLoan.SalesCoordinators.IApplicationInformationRepository
    {
        public ApplicationInformationRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        { }
    }
}
