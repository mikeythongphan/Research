﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class BusinessNatureRepository : RepositoryBase<BusinessNatureViewModel>, IBusinessNatureRepository
    {
        private LITSEntities _LITSEntities;

        public BusinessNatureRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_business_nature entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_business_nature entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_business_nature, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_business_nature Get(Expression<Func<m_business_nature, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_business_nature> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_business_nature GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_business_nature GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_business_nature> GetMany(Expression<Func<m_business_nature, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_business_nature> GetPage<TOrder>(Page page, Expression<Func<m_business_nature, bool>> where, Expression<Func<m_business_nature, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_business_nature entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<BusinessNatureViewModel> GetListActiveAll()
        {
            List<m_business_nature> bankHolidayList = _LITSEntities.m_business_nature.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<BusinessNatureViewModel> resultList = new List<BusinessNatureViewModel>();
            foreach (m_business_nature temp in bankHolidayList)
            {
                BusinessNatureViewModel data = Mapper.Map<m_business_nature, BusinessNatureViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BusinessNatureViewModel> GetListActiveById(int? Id)
        {
            List<m_business_nature> bankHolidayList = _LITSEntities.m_business_nature.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<BusinessNatureViewModel> resultList = new List<BusinessNatureViewModel>();
            foreach (m_business_nature temp in bankHolidayList)
            {
                BusinessNatureViewModel data = Mapper.Map<m_business_nature, BusinessNatureViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BusinessNatureViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_business_nature> bankHolidayList = _LITSEntities.m_business_nature.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<BusinessNatureViewModel> resultList = new List<BusinessNatureViewModel>();
            foreach (m_business_nature temp in bankHolidayList)
            {
                BusinessNatureViewModel data = Mapper.Map<m_business_nature, BusinessNatureViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BusinessNatureViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_business_nature> bankHolidayList = _LITSEntities.m_business_nature.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<BusinessNatureViewModel> resultList = new List<BusinessNatureViewModel>();
            foreach (m_business_nature temp in bankHolidayList)
            {
                BusinessNatureViewModel data = Mapper.Map<m_business_nature, BusinessNatureViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BusinessNatureViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_business_nature> bankHolidayList = _LITSEntities.m_business_nature.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<BusinessNatureViewModel> resultList = new List<BusinessNatureViewModel>();
            foreach (m_business_nature temp in bankHolidayList)
            {
                BusinessNatureViewModel data = Mapper.Map<m_business_nature, BusinessNatureViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BusinessNatureViewModel> GetListAll()
        {
            List<m_business_nature> bankHolidayList = _LITSEntities.m_business_nature.ToList();
            List<BusinessNatureViewModel> resultList = new List<BusinessNatureViewModel>();
            foreach (m_business_nature temp in bankHolidayList)
            {
                BusinessNatureViewModel data = Mapper.Map<m_business_nature, BusinessNatureViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BusinessNatureViewModel> GetListById(int? Id)
        {
            List<m_business_nature> bankHolidayList = _LITSEntities.m_business_nature.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<BusinessNatureViewModel> resultList = new List<BusinessNatureViewModel>();
            foreach (m_business_nature temp in bankHolidayList)
            {
                BusinessNatureViewModel data = Mapper.Map<m_business_nature, BusinessNatureViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BusinessNatureViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_business_nature> bankHolidayList = _LITSEntities.m_business_nature.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<BusinessNatureViewModel> resultList = new List<BusinessNatureViewModel>();
            foreach (m_business_nature temp in bankHolidayList)
            {
                BusinessNatureViewModel data = Mapper.Map<m_business_nature, BusinessNatureViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BusinessNatureViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_business_nature> bankHolidayList = _LITSEntities.m_business_nature.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<BusinessNatureViewModel> resultList = new List<BusinessNatureViewModel>();
            foreach (m_business_nature temp in bankHolidayList)
            {
                BusinessNatureViewModel data = Mapper.Map<m_business_nature, BusinessNatureViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<BusinessNatureViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_business_nature> bankHolidayList = _LITSEntities.m_business_nature.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<BusinessNatureViewModel> resultList = new List<BusinessNatureViewModel>();
            foreach (m_business_nature temp in bankHolidayList)
            {
                BusinessNatureViewModel data = Mapper.Map<m_business_nature, BusinessNatureViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(BusinessNatureViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<BusinessNatureViewModel, m_business_nature>(model[0]);
                            data.is_active = false;
                            context.m_business_nature.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(BusinessNatureViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_business_nature data = AutoMapper.Mapper.Map<BusinessNatureViewModel, m_business_nature>(objModel);
                        context.m_business_nature.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(BusinessNatureViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_business_nature data = Mapper.Map<BusinessNatureViewModel, m_business_nature>(objModel);
                        context.m_business_nature.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
