﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class CampaignCodeRepository : RepositoryBase<CampaignCodeViewModel>, ICampaignCodeRepository
    {
        private LITSEntities _LITSEntities;

        public CampaignCodeRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_campaign_code entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_campaign_code entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_campaign_code, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_campaign_code Get(Expression<Func<m_campaign_code, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_campaign_code> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_campaign_code GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_campaign_code GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_campaign_code> GetMany(Expression<Func<m_campaign_code, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_campaign_code> GetPage<TOrder>(Page page, Expression<Func<m_campaign_code, bool>> where, Expression<Func<m_campaign_code, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_campaign_code entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<CampaignCodeViewModel> GetListActiveAll()
        {
            List<m_campaign_code> bankHolidayList = _LITSEntities.m_campaign_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<CampaignCodeViewModel> resultList = new List<CampaignCodeViewModel>();
            foreach (m_campaign_code temp in bankHolidayList)
            {
                CampaignCodeViewModel data = Mapper.Map<m_campaign_code, CampaignCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CampaignCodeViewModel> GetListActiveById(int Id)
        {
            List<m_campaign_code> bankHolidayList = _LITSEntities.m_campaign_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<CampaignCodeViewModel> resultList = new List<CampaignCodeViewModel>();
            foreach (m_campaign_code temp in bankHolidayList)
            {
                CampaignCodeViewModel data = Mapper.Map<m_campaign_code, CampaignCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CampaignCodeViewModel> GetListActiveByStatusId(int StatusId)
        {
            List<m_campaign_code> bankHolidayList = _LITSEntities.m_campaign_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<CampaignCodeViewModel> resultList = new List<CampaignCodeViewModel>();
            foreach (m_campaign_code temp in bankHolidayList)
            {
                CampaignCodeViewModel data = Mapper.Map<m_campaign_code, CampaignCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CampaignCodeViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_campaign_code> bankHolidayList = _LITSEntities.m_campaign_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CampaignCodeViewModel> resultList = new List<CampaignCodeViewModel>();
            foreach (m_campaign_code temp in bankHolidayList)
            {
                CampaignCodeViewModel data = Mapper.Map<m_campaign_code, CampaignCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CampaignCodeViewModel> GetListActiveByTypeId(int TypeId)
        {
            List<m_campaign_code> bankHolidayList = _LITSEntities.m_campaign_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<CampaignCodeViewModel> resultList = new List<CampaignCodeViewModel>();
            foreach (m_campaign_code temp in bankHolidayList)
            {
                CampaignCodeViewModel data = Mapper.Map<m_campaign_code, CampaignCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CampaignCodeViewModel> GetListAll()
        {
            List<m_campaign_code> bankHolidayList = _LITSEntities.m_campaign_code.ToList();
            List<CampaignCodeViewModel> resultList = new List<CampaignCodeViewModel>();
            foreach (m_campaign_code temp in bankHolidayList)
            {
                CampaignCodeViewModel data = Mapper.Map<m_campaign_code, CampaignCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CampaignCodeViewModel> GetListById(int Id)
        {
            List<m_campaign_code> bankHolidayList = _LITSEntities.m_campaign_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<CampaignCodeViewModel> resultList = new List<CampaignCodeViewModel>();
            foreach (m_campaign_code temp in bankHolidayList)
            {
                CampaignCodeViewModel data = Mapper.Map<m_campaign_code, CampaignCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CampaignCodeViewModel> GetListByStatusId(int StatusId)
        {
            List<m_campaign_code> bankHolidayList = _LITSEntities.m_campaign_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<CampaignCodeViewModel> resultList = new List<CampaignCodeViewModel>();
            foreach (m_campaign_code temp in bankHolidayList)
            {
                CampaignCodeViewModel data = Mapper.Map<m_campaign_code, CampaignCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CampaignCodeViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_campaign_code> bankHolidayList = _LITSEntities.m_campaign_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CampaignCodeViewModel> resultList = new List<CampaignCodeViewModel>();
            foreach (m_campaign_code temp in bankHolidayList)
            {
                CampaignCodeViewModel data = Mapper.Map<m_campaign_code, CampaignCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CampaignCodeViewModel> GetListByTypeId(int TypeId)
        {
            List<m_campaign_code> bankHolidayList = _LITSEntities.m_campaign_code.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<CampaignCodeViewModel> resultList = new List<CampaignCodeViewModel>();
            foreach (m_campaign_code temp in bankHolidayList)
            {
                CampaignCodeViewModel data = Mapper.Map<m_campaign_code, CampaignCodeViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(CampaignCodeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<CampaignCodeViewModel, m_campaign_code>(model[0]);
                            data.is_active = false;
                            context.m_campaign_code.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(CampaignCodeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_campaign_code data = AutoMapper.Mapper.Map<CampaignCodeViewModel, m_campaign_code>(objModel);
                        context.m_campaign_code.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(CampaignCodeViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_campaign_code data = Mapper.Map<CampaignCodeViewModel, m_campaign_code>(objModel);
                        context.m_campaign_code.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
