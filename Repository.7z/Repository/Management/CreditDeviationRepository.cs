﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class CreditDeviationRepository : RepositoryBase<CreditDeviationViewModel>, ICreditDeviationRepository
    {
        private LITSEntities _LITSEntities;

        public CreditDeviationRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_credit_deviation entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_credit_deviation entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_credit_deviation, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_credit_deviation Get(Expression<Func<m_credit_deviation, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_credit_deviation> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_credit_deviation GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_credit_deviation GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_credit_deviation> GetMany(Expression<Func<m_credit_deviation, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_credit_deviation> GetPage<TOrder>(Page page, Expression<Func<m_credit_deviation, bool>> where, Expression<Func<m_credit_deviation, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_credit_deviation entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<CreditDeviationViewModel> GetListActiveAll()
        {
            List<m_credit_deviation> bankHolidayList = _LITSEntities.m_credit_deviation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<CreditDeviationViewModel> resultList = new List<CreditDeviationViewModel>();
            foreach (m_credit_deviation temp in bankHolidayList)
            {
                CreditDeviationViewModel data = Mapper.Map<m_credit_deviation, CreditDeviationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditDeviationViewModel> GetListActiveById(int Id)
        {
            List<m_credit_deviation> bankHolidayList = _LITSEntities.m_credit_deviation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<CreditDeviationViewModel> resultList = new List<CreditDeviationViewModel>();
            foreach (m_credit_deviation temp in bankHolidayList)
            {
                CreditDeviationViewModel data = Mapper.Map<m_credit_deviation, CreditDeviationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditDeviationViewModel> GetListActiveByStatusId(int StatusId)
        {
            List<m_credit_deviation> bankHolidayList = _LITSEntities.m_credit_deviation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<CreditDeviationViewModel> resultList = new List<CreditDeviationViewModel>();
            foreach (m_credit_deviation temp in bankHolidayList)
            {
                CreditDeviationViewModel data = Mapper.Map<m_credit_deviation, CreditDeviationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditDeviationViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_credit_deviation> bankHolidayList = _LITSEntities.m_credit_deviation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CreditDeviationViewModel> resultList = new List<CreditDeviationViewModel>();
            foreach (m_credit_deviation temp in bankHolidayList)
            {
                CreditDeviationViewModel data = Mapper.Map<m_credit_deviation, CreditDeviationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditDeviationViewModel> GetListActiveByTypeId(int TypeId)
        {
            List<m_credit_deviation> bankHolidayList = _LITSEntities.m_credit_deviation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<CreditDeviationViewModel> resultList = new List<CreditDeviationViewModel>();
            foreach (m_credit_deviation temp in bankHolidayList)
            {
                CreditDeviationViewModel data = Mapper.Map<m_credit_deviation, CreditDeviationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditDeviationViewModel> GetListAll()
        {
            List<m_credit_deviation> bankHolidayList = _LITSEntities.m_credit_deviation.ToList();
            List<CreditDeviationViewModel> resultList = new List<CreditDeviationViewModel>();
            foreach (m_credit_deviation temp in bankHolidayList)
            {
                CreditDeviationViewModel data = Mapper.Map<m_credit_deviation, CreditDeviationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditDeviationViewModel> GetListById(int Id)
        {
            List<m_credit_deviation> bankHolidayList = _LITSEntities.m_credit_deviation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<CreditDeviationViewModel> resultList = new List<CreditDeviationViewModel>();
            foreach (m_credit_deviation temp in bankHolidayList)
            {
                CreditDeviationViewModel data = Mapper.Map<m_credit_deviation, CreditDeviationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditDeviationViewModel> GetListByStatusId(int StatusId)
        {
            List<m_credit_deviation> bankHolidayList = _LITSEntities.m_credit_deviation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<CreditDeviationViewModel> resultList = new List<CreditDeviationViewModel>();
            foreach (m_credit_deviation temp in bankHolidayList)
            {
                CreditDeviationViewModel data = Mapper.Map<m_credit_deviation, CreditDeviationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditDeviationViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_credit_deviation> bankHolidayList = _LITSEntities.m_credit_deviation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CreditDeviationViewModel> resultList = new List<CreditDeviationViewModel>();
            foreach (m_credit_deviation temp in bankHolidayList)
            {
                CreditDeviationViewModel data = Mapper.Map<m_credit_deviation, CreditDeviationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CreditDeviationViewModel> GetListByTypeId(int TypeId)
        {
            List<m_credit_deviation> bankHolidayList = _LITSEntities.m_credit_deviation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<CreditDeviationViewModel> resultList = new List<CreditDeviationViewModel>();
            foreach (m_credit_deviation temp in bankHolidayList)
            {
                CreditDeviationViewModel data = Mapper.Map<m_credit_deviation, CreditDeviationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(CreditDeviationViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<CreditDeviationViewModel, m_credit_deviation>(model[0]);
                            data.is_active = false;
                            context.m_credit_deviation.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(CreditDeviationViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_credit_deviation data = AutoMapper.Mapper.Map<CreditDeviationViewModel, m_credit_deviation>(objModel);
                        context.m_credit_deviation.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(CreditDeviationViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_credit_deviation data = Mapper.Map<CreditDeviationViewModel, m_credit_deviation>(objModel);
                        context.m_credit_deviation.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
