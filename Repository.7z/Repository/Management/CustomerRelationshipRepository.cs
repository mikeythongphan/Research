﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class CustomerRelationshipRepository : RepositoryBase<CustomerRelationshipViewModel>, ICustomerRelationshipRepository
    {
        private LITSEntities _LITSEntities;

        public CustomerRelationshipRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_customer_relationship entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_customer_relationship entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_customer_relationship, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_customer_relationship Get(Expression<Func<m_customer_relationship, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_customer_relationship> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_customer_relationship GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_customer_relationship GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_customer_relationship> GetMany(Expression<Func<m_customer_relationship, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_customer_relationship> GetPage<TOrder>(Page page, Expression<Func<m_customer_relationship, bool>> where, Expression<Func<m_customer_relationship, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_customer_relationship entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<CustomerRelationshipViewModel> GetListActiveAll()
        {
            List<m_customer_relationship> bankHolidayList = _LITSEntities.m_customer_relationship.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<CustomerRelationshipViewModel> resultList = new List<CustomerRelationshipViewModel>();
            foreach (m_customer_relationship temp in bankHolidayList)
            {
                CustomerRelationshipViewModel data = Mapper.Map<m_customer_relationship, CustomerRelationshipViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerRelationshipViewModel> GetListActiveById(int? Id)
        {
            List<m_customer_relationship> bankHolidayList = _LITSEntities.m_customer_relationship.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<CustomerRelationshipViewModel> resultList = new List<CustomerRelationshipViewModel>();
            foreach (m_customer_relationship temp in bankHolidayList)
            {
                CustomerRelationshipViewModel data = Mapper.Map<m_customer_relationship, CustomerRelationshipViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerRelationshipViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_customer_relationship> bankHolidayList = _LITSEntities.m_customer_relationship.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<CustomerRelationshipViewModel> resultList = new List<CustomerRelationshipViewModel>();
            foreach (m_customer_relationship temp in bankHolidayList)
            {
                CustomerRelationshipViewModel data = Mapper.Map<m_customer_relationship, CustomerRelationshipViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerRelationshipViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_customer_relationship> bankHolidayList = _LITSEntities.m_customer_relationship.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CustomerRelationshipViewModel> resultList = new List<CustomerRelationshipViewModel>();
            foreach (m_customer_relationship temp in bankHolidayList)
            {
                CustomerRelationshipViewModel data = Mapper.Map<m_customer_relationship, CustomerRelationshipViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerRelationshipViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_customer_relationship> bankHolidayList = _LITSEntities.m_customer_relationship.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<CustomerRelationshipViewModel> resultList = new List<CustomerRelationshipViewModel>();
            foreach (m_customer_relationship temp in bankHolidayList)
            {
                CustomerRelationshipViewModel data = Mapper.Map<m_customer_relationship, CustomerRelationshipViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerRelationshipViewModel> GetListAll()
        {
            List<m_customer_relationship> bankHolidayList = _LITSEntities.m_customer_relationship.ToList();
            List<CustomerRelationshipViewModel> resultList = new List<CustomerRelationshipViewModel>();
            foreach (m_customer_relationship temp in bankHolidayList)
            {
                CustomerRelationshipViewModel data = Mapper.Map<m_customer_relationship, CustomerRelationshipViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerRelationshipViewModel> GetListById(int? Id)
        {
            List<m_customer_relationship> bankHolidayList = _LITSEntities.m_customer_relationship.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<CustomerRelationshipViewModel> resultList = new List<CustomerRelationshipViewModel>();
            foreach (m_customer_relationship temp in bankHolidayList)
            {
                CustomerRelationshipViewModel data = Mapper.Map<m_customer_relationship, CustomerRelationshipViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerRelationshipViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_customer_relationship> bankHolidayList = _LITSEntities.m_customer_relationship.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<CustomerRelationshipViewModel> resultList = new List<CustomerRelationshipViewModel>();
            foreach (m_customer_relationship temp in bankHolidayList)
            {
                CustomerRelationshipViewModel data = Mapper.Map<m_customer_relationship, CustomerRelationshipViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerRelationshipViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_customer_relationship> bankHolidayList = _LITSEntities.m_customer_relationship.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<CustomerRelationshipViewModel> resultList = new List<CustomerRelationshipViewModel>();
            foreach (m_customer_relationship temp in bankHolidayList)
            {
                CustomerRelationshipViewModel data = Mapper.Map<m_customer_relationship, CustomerRelationshipViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<CustomerRelationshipViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_customer_relationship> bankHolidayList = _LITSEntities.m_customer_relationship.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<CustomerRelationshipViewModel> resultList = new List<CustomerRelationshipViewModel>();
            foreach (m_customer_relationship temp in bankHolidayList)
            {
                CustomerRelationshipViewModel data = Mapper.Map<m_customer_relationship, CustomerRelationshipViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(CustomerRelationshipViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<CustomerRelationshipViewModel, m_customer_relationship>(model[0]);
                            data.is_active = false;
                            context.m_customer_relationship.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(CustomerRelationshipViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_customer_relationship data = AutoMapper.Mapper.Map<CustomerRelationshipViewModel, m_customer_relationship>(objModel);
                        context.m_customer_relationship.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(CustomerRelationshipViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_customer_relationship data = Mapper.Map<CustomerRelationshipViewModel, m_customer_relationship>(objModel);
                        context.m_customer_relationship.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
