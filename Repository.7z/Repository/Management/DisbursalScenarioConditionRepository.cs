﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class DisbursalScenarioConditionRepository : RepositoryBase<DisbursalScenarioConditionViewModel>, IDisbursalScenarioConditionRepository
    {
        private LITSEntities _LITSEntities;

        public DisbursalScenarioConditionRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_disbursal_scenario_condition entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_disbursal_scenario_condition entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_disbursal_scenario_condition, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_disbursal_scenario_condition Get(Expression<Func<m_disbursal_scenario_condition, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_disbursal_scenario_condition> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_disbursal_scenario_condition GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_disbursal_scenario_condition GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_disbursal_scenario_condition> GetMany(Expression<Func<m_disbursal_scenario_condition, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_disbursal_scenario_condition> GetPage<TOrder>(Page page, Expression<Func<m_disbursal_scenario_condition, bool>> where, Expression<Func<m_disbursal_scenario_condition, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_disbursal_scenario_condition entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<DisbursalScenarioConditionViewModel> GetListActiveAll()
        {
            List<m_disbursal_scenario_condition> bankHolidayList = _LITSEntities.m_disbursal_scenario_condition.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<DisbursalScenarioConditionViewModel> resultList = new List<DisbursalScenarioConditionViewModel>();
            foreach (m_disbursal_scenario_condition temp in bankHolidayList)
            {
                DisbursalScenarioConditionViewModel data = Mapper.Map<m_disbursal_scenario_condition, DisbursalScenarioConditionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioConditionViewModel> GetListActiveById(int Id)
        {
            List<m_disbursal_scenario_condition> bankHolidayList = _LITSEntities.m_disbursal_scenario_condition.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<DisbursalScenarioConditionViewModel> resultList = new List<DisbursalScenarioConditionViewModel>();
            foreach (m_disbursal_scenario_condition temp in bankHolidayList)
            {
                DisbursalScenarioConditionViewModel data = Mapper.Map<m_disbursal_scenario_condition, DisbursalScenarioConditionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioConditionViewModel> GetListActiveByStatusId(int StatusId)
        {
            List<m_disbursal_scenario_condition> bankHolidayList = _LITSEntities.m_disbursal_scenario_condition.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<DisbursalScenarioConditionViewModel> resultList = new List<DisbursalScenarioConditionViewModel>();
            foreach (m_disbursal_scenario_condition temp in bankHolidayList)
            {
                DisbursalScenarioConditionViewModel data = Mapper.Map<m_disbursal_scenario_condition, DisbursalScenarioConditionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioConditionViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_disbursal_scenario_condition> bankHolidayList = _LITSEntities.m_disbursal_scenario_condition.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<DisbursalScenarioConditionViewModel> resultList = new List<DisbursalScenarioConditionViewModel>();
            foreach (m_disbursal_scenario_condition temp in bankHolidayList)
            {
                DisbursalScenarioConditionViewModel data = Mapper.Map<m_disbursal_scenario_condition, DisbursalScenarioConditionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioConditionViewModel> GetListActiveByTypeId(int TypeId)
        {
            List<m_disbursal_scenario_condition> bankHolidayList = _LITSEntities.m_disbursal_scenario_condition.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<DisbursalScenarioConditionViewModel> resultList = new List<DisbursalScenarioConditionViewModel>();
            foreach (m_disbursal_scenario_condition temp in bankHolidayList)
            {
                DisbursalScenarioConditionViewModel data = Mapper.Map<m_disbursal_scenario_condition, DisbursalScenarioConditionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioConditionViewModel> GetListAll()
        {
            List<m_disbursal_scenario_condition> bankHolidayList = _LITSEntities.m_disbursal_scenario_condition.ToList();
            List<DisbursalScenarioConditionViewModel> resultList = new List<DisbursalScenarioConditionViewModel>();
            foreach (m_disbursal_scenario_condition temp in bankHolidayList)
            {
                DisbursalScenarioConditionViewModel data = Mapper.Map<m_disbursal_scenario_condition, DisbursalScenarioConditionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioConditionViewModel> GetListById(int Id)
        {
            List<m_disbursal_scenario_condition> bankHolidayList = _LITSEntities.m_disbursal_scenario_condition.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<DisbursalScenarioConditionViewModel> resultList = new List<DisbursalScenarioConditionViewModel>();
            foreach (m_disbursal_scenario_condition temp in bankHolidayList)
            {
                DisbursalScenarioConditionViewModel data = Mapper.Map<m_disbursal_scenario_condition, DisbursalScenarioConditionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioConditionViewModel> GetListByStatusId(int StatusId)
        {
            List<m_disbursal_scenario_condition> bankHolidayList = _LITSEntities.m_disbursal_scenario_condition.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<DisbursalScenarioConditionViewModel> resultList = new List<DisbursalScenarioConditionViewModel>();
            foreach (m_disbursal_scenario_condition temp in bankHolidayList)
            {
                DisbursalScenarioConditionViewModel data = Mapper.Map<m_disbursal_scenario_condition, DisbursalScenarioConditionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioConditionViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_disbursal_scenario_condition> bankHolidayList = _LITSEntities.m_disbursal_scenario_condition.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<DisbursalScenarioConditionViewModel> resultList = new List<DisbursalScenarioConditionViewModel>();
            foreach (m_disbursal_scenario_condition temp in bankHolidayList)
            {
                DisbursalScenarioConditionViewModel data = Mapper.Map<m_disbursal_scenario_condition, DisbursalScenarioConditionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioConditionViewModel> GetListByTypeId(int TypeId)
        {
            List<m_disbursal_scenario_condition> bankHolidayList = _LITSEntities.m_disbursal_scenario_condition.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<DisbursalScenarioConditionViewModel> resultList = new List<DisbursalScenarioConditionViewModel>();
            foreach (m_disbursal_scenario_condition temp in bankHolidayList)
            {
                DisbursalScenarioConditionViewModel data = Mapper.Map<m_disbursal_scenario_condition, DisbursalScenarioConditionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(DisbursalScenarioConditionViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<DisbursalScenarioConditionViewModel, m_disbursal_scenario_condition>(model[0]);
                            data.is_active = false;
                            context.m_disbursal_scenario_condition.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(DisbursalScenarioConditionViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_disbursal_scenario_condition data = AutoMapper.Mapper.Map<DisbursalScenarioConditionViewModel, m_disbursal_scenario_condition>(objModel);
                        context.m_disbursal_scenario_condition.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(DisbursalScenarioConditionViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_disbursal_scenario_condition data = Mapper.Map<DisbursalScenarioConditionViewModel, m_disbursal_scenario_condition>(objModel);
                        context.m_disbursal_scenario_condition.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
