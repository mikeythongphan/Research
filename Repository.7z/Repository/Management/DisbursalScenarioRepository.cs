﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class DisbursalScenarioRepository : RepositoryBase<DisbursalScenarioViewModel>, IDisbursalScenarioRepository
    {
        private LITSEntities _LITSEntities;

        public DisbursalScenarioRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_disbursal_scenario entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_disbursal_scenario entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_disbursal_scenario, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_disbursal_scenario Get(Expression<Func<m_disbursal_scenario, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_disbursal_scenario> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_disbursal_scenario GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_disbursal_scenario GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_disbursal_scenario> GetMany(Expression<Func<m_disbursal_scenario, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_disbursal_scenario> GetPage<TOrder>(Page page, Expression<Func<m_disbursal_scenario, bool>> where, Expression<Func<m_disbursal_scenario, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_disbursal_scenario entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<DisbursalScenarioViewModel> GetListActiveAll()
        {
            List<m_disbursal_scenario> bankHolidayList = _LITSEntities.m_disbursal_scenario.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<DisbursalScenarioViewModel> resultList = new List<DisbursalScenarioViewModel>();
            foreach (m_disbursal_scenario temp in bankHolidayList)
            {
                DisbursalScenarioViewModel data = Mapper.Map<m_disbursal_scenario, DisbursalScenarioViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioViewModel> GetListActiveById(int Id)
        {
            List<m_disbursal_scenario> bankHolidayList = _LITSEntities.m_disbursal_scenario.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<DisbursalScenarioViewModel> resultList = new List<DisbursalScenarioViewModel>();
            foreach (m_disbursal_scenario temp in bankHolidayList)
            {
                DisbursalScenarioViewModel data = Mapper.Map<m_disbursal_scenario, DisbursalScenarioViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioViewModel> GetListActiveByStatusId(int StatusId)
        {
            List<m_disbursal_scenario> bankHolidayList = _LITSEntities.m_disbursal_scenario.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<DisbursalScenarioViewModel> resultList = new List<DisbursalScenarioViewModel>();
            foreach (m_disbursal_scenario temp in bankHolidayList)
            {
                DisbursalScenarioViewModel data = Mapper.Map<m_disbursal_scenario, DisbursalScenarioViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_disbursal_scenario> bankHolidayList = _LITSEntities.m_disbursal_scenario.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<DisbursalScenarioViewModel> resultList = new List<DisbursalScenarioViewModel>();
            foreach (m_disbursal_scenario temp in bankHolidayList)
            {
                DisbursalScenarioViewModel data = Mapper.Map<m_disbursal_scenario, DisbursalScenarioViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioViewModel> GetListActiveByTypeId(int TypeId)
        {
            List<m_disbursal_scenario> bankHolidayList = _LITSEntities.m_disbursal_scenario.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<DisbursalScenarioViewModel> resultList = new List<DisbursalScenarioViewModel>();
            foreach (m_disbursal_scenario temp in bankHolidayList)
            {
                DisbursalScenarioViewModel data = Mapper.Map<m_disbursal_scenario, DisbursalScenarioViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioViewModel> GetListAll()
        {
            List<m_disbursal_scenario> bankHolidayList = _LITSEntities.m_disbursal_scenario.ToList();
            List<DisbursalScenarioViewModel> resultList = new List<DisbursalScenarioViewModel>();
            foreach (m_disbursal_scenario temp in bankHolidayList)
            {
                DisbursalScenarioViewModel data = Mapper.Map<m_disbursal_scenario, DisbursalScenarioViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioViewModel> GetListById(int Id)
        {
            List<m_disbursal_scenario> bankHolidayList = _LITSEntities.m_disbursal_scenario.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<DisbursalScenarioViewModel> resultList = new List<DisbursalScenarioViewModel>();
            foreach (m_disbursal_scenario temp in bankHolidayList)
            {
                DisbursalScenarioViewModel data = Mapper.Map<m_disbursal_scenario, DisbursalScenarioViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioViewModel> GetListByStatusId(int StatusId)
        {
            List<m_disbursal_scenario> bankHolidayList = _LITSEntities.m_disbursal_scenario.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<DisbursalScenarioViewModel> resultList = new List<DisbursalScenarioViewModel>();
            foreach (m_disbursal_scenario temp in bankHolidayList)
            {
                DisbursalScenarioViewModel data = Mapper.Map<m_disbursal_scenario, DisbursalScenarioViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_disbursal_scenario> bankHolidayList = _LITSEntities.m_disbursal_scenario.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<DisbursalScenarioViewModel> resultList = new List<DisbursalScenarioViewModel>();
            foreach (m_disbursal_scenario temp in bankHolidayList)
            {
                DisbursalScenarioViewModel data = Mapper.Map<m_disbursal_scenario, DisbursalScenarioViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<DisbursalScenarioViewModel> GetListByTypeId(int TypeId)
        {
            List<m_disbursal_scenario> bankHolidayList = _LITSEntities.m_disbursal_scenario.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<DisbursalScenarioViewModel> resultList = new List<DisbursalScenarioViewModel>();
            foreach (m_disbursal_scenario temp in bankHolidayList)
            {
                DisbursalScenarioViewModel data = Mapper.Map<m_disbursal_scenario, DisbursalScenarioViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(DisbursalScenarioViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<DisbursalScenarioViewModel, m_disbursal_scenario>(model[0]);
                            data.is_active = false;
                            context.m_disbursal_scenario.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(DisbursalScenarioViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_disbursal_scenario data = AutoMapper.Mapper.Map<DisbursalScenarioViewModel, m_disbursal_scenario>(objModel);
                        context.m_disbursal_scenario.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(DisbursalScenarioViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_disbursal_scenario data = Mapper.Map<DisbursalScenarioViewModel, m_disbursal_scenario>(objModel);
                        context.m_disbursal_scenario.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
