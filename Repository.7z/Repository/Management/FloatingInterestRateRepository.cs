﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class FloatingInterestRateRepository : RepositoryBase<FloatingInterestRateViewModel>, IFloatingInterestRateRepository
    {
        private LITSEntities _LITSEntities;
        public FloatingInterestRateRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_floating_interest_rate entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_floating_interest_rate entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_floating_interest_rate, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_floating_interest_rate Get(Expression<Func<m_floating_interest_rate, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_floating_interest_rate> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_floating_interest_rate GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_floating_interest_rate GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_floating_interest_rate> GetMany(Expression<Func<m_floating_interest_rate, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_floating_interest_rate> GetPage<TOrder>(Page page, Expression<Func<m_floating_interest_rate, bool>> where, Expression<Func<m_floating_interest_rate, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_floating_interest_rate entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<FloatingInterestRateViewModel> GetListActiveAll()
        {
            List<m_floating_interest_rate> bankHolidayList = _LITSEntities.m_floating_interest_rate.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<FloatingInterestRateViewModel> resultList = new List<FloatingInterestRateViewModel>();
            foreach (m_floating_interest_rate temp in bankHolidayList)
            {
                FloatingInterestRateViewModel data = Mapper.Map<m_floating_interest_rate, FloatingInterestRateViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<FloatingInterestRateViewModel> GetListActiveById(int Id)
        {
            List<m_floating_interest_rate> bankHolidayList = _LITSEntities.m_floating_interest_rate.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<FloatingInterestRateViewModel> resultList = new List<FloatingInterestRateViewModel>();
            foreach (m_floating_interest_rate temp in bankHolidayList)
            {
                FloatingInterestRateViewModel data = Mapper.Map<m_floating_interest_rate, FloatingInterestRateViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<FloatingInterestRateViewModel> GetListActiveByStatusId(int StatusId)
        {
            List<m_floating_interest_rate> bankHolidayList = _LITSEntities.m_floating_interest_rate.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<FloatingInterestRateViewModel> resultList = new List<FloatingInterestRateViewModel>();
            foreach (m_floating_interest_rate temp in bankHolidayList)
            {
                FloatingInterestRateViewModel data = Mapper.Map<m_floating_interest_rate, FloatingInterestRateViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<FloatingInterestRateViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_floating_interest_rate> bankHolidayList = _LITSEntities.m_floating_interest_rate.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<FloatingInterestRateViewModel> resultList = new List<FloatingInterestRateViewModel>();
            foreach (m_floating_interest_rate temp in bankHolidayList)
            {
                FloatingInterestRateViewModel data = Mapper.Map<m_floating_interest_rate, FloatingInterestRateViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<FloatingInterestRateViewModel> GetListActiveByTypeId(int TypeId)
        {
            List<m_floating_interest_rate> bankHolidayList = _LITSEntities.m_floating_interest_rate.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<FloatingInterestRateViewModel> resultList = new List<FloatingInterestRateViewModel>();
            foreach (m_floating_interest_rate temp in bankHolidayList)
            {
                FloatingInterestRateViewModel data = Mapper.Map<m_floating_interest_rate, FloatingInterestRateViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<FloatingInterestRateViewModel> GetListAll()
        {
            List<m_floating_interest_rate> bankHolidayList = _LITSEntities.m_floating_interest_rate.ToList();
            List<FloatingInterestRateViewModel> resultList = new List<FloatingInterestRateViewModel>();
            foreach (m_floating_interest_rate temp in bankHolidayList)
            {
                FloatingInterestRateViewModel data = Mapper.Map<m_floating_interest_rate, FloatingInterestRateViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<FloatingInterestRateViewModel> GetListById(int Id)
        {
            List<m_floating_interest_rate> bankHolidayList = _LITSEntities.m_floating_interest_rate.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<FloatingInterestRateViewModel> resultList = new List<FloatingInterestRateViewModel>();
            foreach (m_floating_interest_rate temp in bankHolidayList)
            {
                FloatingInterestRateViewModel data = Mapper.Map<m_floating_interest_rate, FloatingInterestRateViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<FloatingInterestRateViewModel> GetListByStatusId(int StatusId)
        {
            List<m_floating_interest_rate> bankHolidayList = _LITSEntities.m_floating_interest_rate.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<FloatingInterestRateViewModel> resultList = new List<FloatingInterestRateViewModel>();
            foreach (m_floating_interest_rate temp in bankHolidayList)
            {
                FloatingInterestRateViewModel data = Mapper.Map<m_floating_interest_rate, FloatingInterestRateViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<FloatingInterestRateViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_floating_interest_rate> bankHolidayList = _LITSEntities.m_floating_interest_rate.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<FloatingInterestRateViewModel> resultList = new List<FloatingInterestRateViewModel>();
            foreach (m_floating_interest_rate temp in bankHolidayList)
            {
                FloatingInterestRateViewModel data = Mapper.Map<m_floating_interest_rate, FloatingInterestRateViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<FloatingInterestRateViewModel> GetListByTypeId(int TypeId)
        {
            List<m_floating_interest_rate> bankHolidayList = _LITSEntities.m_floating_interest_rate.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<FloatingInterestRateViewModel> resultList = new List<FloatingInterestRateViewModel>();
            foreach (m_floating_interest_rate temp in bankHolidayList)
            {
                FloatingInterestRateViewModel data = Mapper.Map<m_floating_interest_rate, FloatingInterestRateViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(FloatingInterestRateViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<FloatingInterestRateViewModel, m_floating_interest_rate>(model[0]);
                            data.is_active = false;
                            context.m_floating_interest_rate.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(FloatingInterestRateViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_floating_interest_rate data = AutoMapper.Mapper.Map<FloatingInterestRateViewModel, m_floating_interest_rate>(objModel);
                        context.m_floating_interest_rate.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(FloatingInterestRateViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_floating_interest_rate data = Mapper.Map<FloatingInterestRateViewModel, m_floating_interest_rate>(objModel);
                        context.m_floating_interest_rate.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
