﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class InterestClassificationRepository : RepositoryBase<InterestClassificationViewModel>, IInterestClassificationRepository
    {
        private LITSEntities _LITSEntities;

        public InterestClassificationRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_interest_classification entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_interest_classification entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_interest_classification, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_interest_classification Get(Expression<Func<m_interest_classification, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_interest_classification> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_interest_classification GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_interest_classification GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_interest_classification> GetMany(Expression<Func<m_interest_classification, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_interest_classification> GetPage<TOrder>(Page page, Expression<Func<m_interest_classification, bool>> where, Expression<Func<m_interest_classification, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_interest_classification entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<InterestClassificationViewModel> GetListActiveAll()
        {
            List<m_interest_classification> bankHolidayList = _LITSEntities.m_interest_classification.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<InterestClassificationViewModel> resultList = new List<InterestClassificationViewModel>();
            foreach (m_interest_classification temp in bankHolidayList)
            {
                InterestClassificationViewModel data = Mapper.Map<m_interest_classification, InterestClassificationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InterestClassificationViewModel> GetListActiveById(int? Id)
        {
            List<m_interest_classification> bankHolidayList = _LITSEntities.m_interest_classification.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<InterestClassificationViewModel> resultList = new List<InterestClassificationViewModel>();
            foreach (m_interest_classification temp in bankHolidayList)
            {
                InterestClassificationViewModel data = Mapper.Map<m_interest_classification, InterestClassificationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InterestClassificationViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_interest_classification> bankHolidayList = _LITSEntities.m_interest_classification.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<InterestClassificationViewModel> resultList = new List<InterestClassificationViewModel>();
            foreach (m_interest_classification temp in bankHolidayList)
            {
                InterestClassificationViewModel data = Mapper.Map<m_interest_classification, InterestClassificationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InterestClassificationViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_interest_classification> bankHolidayList = _LITSEntities.m_interest_classification.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<InterestClassificationViewModel> resultList = new List<InterestClassificationViewModel>();
            foreach (m_interest_classification temp in bankHolidayList)
            {
                InterestClassificationViewModel data = Mapper.Map<m_interest_classification, InterestClassificationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InterestClassificationViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_interest_classification> bankHolidayList = _LITSEntities.m_interest_classification.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<InterestClassificationViewModel> resultList = new List<InterestClassificationViewModel>();
            foreach (m_interest_classification temp in bankHolidayList)
            {
                InterestClassificationViewModel data = Mapper.Map<m_interest_classification, InterestClassificationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InterestClassificationViewModel> GetListAll()
        {
            List<m_interest_classification> bankHolidayList = _LITSEntities.m_interest_classification.ToList();
            List<InterestClassificationViewModel> resultList = new List<InterestClassificationViewModel>();
            foreach (m_interest_classification temp in bankHolidayList)
            {
                InterestClassificationViewModel data = Mapper.Map<m_interest_classification, InterestClassificationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InterestClassificationViewModel> GetListById(int? Id)
        {
            List<m_interest_classification> bankHolidayList = _LITSEntities.m_interest_classification.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<InterestClassificationViewModel> resultList = new List<InterestClassificationViewModel>();
            foreach (m_interest_classification temp in bankHolidayList)
            {
                InterestClassificationViewModel data = Mapper.Map<m_interest_classification, InterestClassificationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InterestClassificationViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_interest_classification> bankHolidayList = _LITSEntities.m_interest_classification.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<InterestClassificationViewModel> resultList = new List<InterestClassificationViewModel>();
            foreach (m_interest_classification temp in bankHolidayList)
            {
                InterestClassificationViewModel data = Mapper.Map<m_interest_classification, InterestClassificationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InterestClassificationViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_interest_classification> bankHolidayList = _LITSEntities.m_interest_classification.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<InterestClassificationViewModel> resultList = new List<InterestClassificationViewModel>();
            foreach (m_interest_classification temp in bankHolidayList)
            {
                InterestClassificationViewModel data = Mapper.Map<m_interest_classification, InterestClassificationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<InterestClassificationViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_interest_classification> bankHolidayList = _LITSEntities.m_interest_classification.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<InterestClassificationViewModel> resultList = new List<InterestClassificationViewModel>();
            foreach (m_interest_classification temp in bankHolidayList)
            {
                InterestClassificationViewModel data = Mapper.Map<m_interest_classification, InterestClassificationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(InterestClassificationViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<InterestClassificationViewModel, m_interest_classification>(model[0]);
                            data.is_active = false;
                            context.m_interest_classification.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(InterestClassificationViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_interest_classification data = AutoMapper.Mapper.Map<InterestClassificationViewModel, m_interest_classification>(objModel);
                        context.m_interest_classification.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(InterestClassificationViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_interest_classification data = Mapper.Map<InterestClassificationViewModel, m_interest_classification>(objModel);
                        context.m_interest_classification.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
