﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class MessageRepository : RepositoryBase<MessageViewModel>, IMessageRepository
    {
        private LITSEntities _LITSEntities;

        public MessageRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_message entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_message entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_message, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_message Get(Expression<Func<m_message, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_message> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_message GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_message GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_message> GetMany(Expression<Func<m_message, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_message> GetPage<TOrder>(Page page, Expression<Func<m_message, bool>> where, Expression<Func<m_message, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_message entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<MessageViewModel> GetListActiveAll()
        {
            List<m_message> bankHolidayList = _LITSEntities.m_message.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<MessageViewModel> resultList = new List<MessageViewModel>();
            foreach (m_message temp in bankHolidayList)
            {
                MessageViewModel data = Mapper.Map<m_message, MessageViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageViewModel> GetListActiveById(int Id)
        {
            List<m_message> bankHolidayList = _LITSEntities.m_message.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<MessageViewModel> resultList = new List<MessageViewModel>();
            foreach (m_message temp in bankHolidayList)
            {
                MessageViewModel data = Mapper.Map<m_message, MessageViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageViewModel> GetListActiveByStatusId(int StatusId)
        {
            List<m_message> bankHolidayList = _LITSEntities.m_message.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<MessageViewModel> resultList = new List<MessageViewModel>();
            foreach (m_message temp in bankHolidayList)
            {
                MessageViewModel data = Mapper.Map<m_message, MessageViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_message> bankHolidayList = _LITSEntities.m_message.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<MessageViewModel> resultList = new List<MessageViewModel>();
            foreach (m_message temp in bankHolidayList)
            {
                MessageViewModel data = Mapper.Map<m_message, MessageViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageViewModel> GetListActiveByTypeId(int TypeId)
        {
            List<m_message> bankHolidayList = _LITSEntities.m_message.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<MessageViewModel> resultList = new List<MessageViewModel>();
            foreach (m_message temp in bankHolidayList)
            {
                MessageViewModel data = Mapper.Map<m_message, MessageViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageViewModel> GetListAll()
        {
            List<m_message> bankHolidayList = _LITSEntities.m_message.ToList();
            List<MessageViewModel> resultList = new List<MessageViewModel>();
            foreach (m_message temp in bankHolidayList)
            {
                MessageViewModel data = Mapper.Map<m_message, MessageViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageViewModel> GetListById(int Id)
        {
            List<m_message> bankHolidayList = _LITSEntities.m_message.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<MessageViewModel> resultList = new List<MessageViewModel>();
            foreach (m_message temp in bankHolidayList)
            {
                MessageViewModel data = Mapper.Map<m_message, MessageViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageViewModel> GetListByStatusId(int StatusId)
        {
            List<m_message> bankHolidayList = _LITSEntities.m_message.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<MessageViewModel> resultList = new List<MessageViewModel>();
            foreach (m_message temp in bankHolidayList)
            {
                MessageViewModel data = Mapper.Map<m_message, MessageViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_message> bankHolidayList = _LITSEntities.m_message.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<MessageViewModel> resultList = new List<MessageViewModel>();
            foreach (m_message temp in bankHolidayList)
            {
                MessageViewModel data = Mapper.Map<m_message, MessageViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<MessageViewModel> GetListByTypeId(int TypeId)
        {
            List<m_message> bankHolidayList = _LITSEntities.m_message.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<MessageViewModel> resultList = new List<MessageViewModel>();
            foreach (m_message temp in bankHolidayList)
            {
                MessageViewModel data = Mapper.Map<m_message, MessageViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(MessageViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<MessageViewModel, m_message>(model[0]);
                            data.is_active = false;
                            context.m_message.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(MessageViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_message data = AutoMapper.Mapper.Map<MessageViewModel, m_message>(objModel);
                        context.m_message.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(MessageViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_message data = Mapper.Map<MessageViewModel, m_message>(objModel);
                        context.m_message.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
