﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class OccupationRepository : RepositoryBase<OccupationViewModel>, IOccupationRepository
    {
        private LITSEntities _LITSEntities;

        public OccupationRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_occupation entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_occupation entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_occupation, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_occupation Get(Expression<Func<m_occupation, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_occupation> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_occupation GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_occupation GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_occupation> GetMany(Expression<Func<m_occupation, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_occupation> GetPage<TOrder>(Page page, Expression<Func<m_occupation, bool>> where, Expression<Func<m_occupation, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_occupation entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<OccupationViewModel> GetListActiveAll()
        {
            List<m_occupation> bankHolidayList = _LITSEntities.m_occupation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<OccupationViewModel> resultList = new List<OccupationViewModel>();
            foreach (m_occupation temp in bankHolidayList)
            {
                OccupationViewModel data = Mapper.Map<m_occupation, OccupationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<OccupationViewModel> GetListActiveById(int Id)
        {
            List<m_occupation> bankHolidayList = _LITSEntities.m_occupation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<OccupationViewModel> resultList = new List<OccupationViewModel>();
            foreach (m_occupation temp in bankHolidayList)
            {
                OccupationViewModel data = Mapper.Map<m_occupation, OccupationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<OccupationViewModel> GetListActiveByStatusId(int StatusId)
        {
            List<m_occupation> bankHolidayList = _LITSEntities.m_occupation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<OccupationViewModel> resultList = new List<OccupationViewModel>();
            foreach (m_occupation temp in bankHolidayList)
            {
                OccupationViewModel data = Mapper.Map<m_occupation, OccupationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<OccupationViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_occupation> bankHolidayList = _LITSEntities.m_occupation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<OccupationViewModel> resultList = new List<OccupationViewModel>();
            foreach (m_occupation temp in bankHolidayList)
            {
                OccupationViewModel data = Mapper.Map<m_occupation, OccupationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<OccupationViewModel> GetListActiveByTypeId(int TypeId)
        {
            List<m_occupation> bankHolidayList = _LITSEntities.m_occupation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<OccupationViewModel> resultList = new List<OccupationViewModel>();
            foreach (m_occupation temp in bankHolidayList)
            {
                OccupationViewModel data = Mapper.Map<m_occupation, OccupationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<OccupationViewModel> GetListAll()
        {
            List<m_occupation> bankHolidayList = _LITSEntities.m_occupation.ToList();
            List<OccupationViewModel> resultList = new List<OccupationViewModel>();
            foreach (m_occupation temp in bankHolidayList)
            {
                OccupationViewModel data = Mapper.Map<m_occupation, OccupationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<OccupationViewModel> GetListById(int Id)
        {
            List<m_occupation> bankHolidayList = _LITSEntities.m_occupation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<OccupationViewModel> resultList = new List<OccupationViewModel>();
            foreach (m_occupation temp in bankHolidayList)
            {
                OccupationViewModel data = Mapper.Map<m_occupation, OccupationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<OccupationViewModel> GetListByStatusId(int StatusId)
        {
            List<m_occupation> bankHolidayList = _LITSEntities.m_occupation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<OccupationViewModel> resultList = new List<OccupationViewModel>();
            foreach (m_occupation temp in bankHolidayList)
            {
                OccupationViewModel data = Mapper.Map<m_occupation, OccupationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<OccupationViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_occupation> bankHolidayList = _LITSEntities.m_occupation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<OccupationViewModel> resultList = new List<OccupationViewModel>();
            foreach (m_occupation temp in bankHolidayList)
            {
                OccupationViewModel data = Mapper.Map<m_occupation, OccupationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<OccupationViewModel> GetListByTypeId(int TypeId)
        {
            List<m_occupation> bankHolidayList = _LITSEntities.m_occupation.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<OccupationViewModel> resultList = new List<OccupationViewModel>();
            foreach (m_occupation temp in bankHolidayList)
            {
                OccupationViewModel data = Mapper.Map<m_occupation, OccupationViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(OccupationViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<OccupationViewModel, m_occupation>(model[0]);
                            data.is_active = false;
                            context.m_occupation.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(OccupationViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_occupation data = AutoMapper.Mapper.Map<OccupationViewModel, m_occupation>(objModel);
                        context.m_occupation.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(OccupationViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_occupation data = Mapper.Map<OccupationViewModel, m_occupation>(objModel);
                        context.m_occupation.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
