﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class PaymentMethodRepository : RepositoryBase<PaymentMethodViewModel>, IPaymentMethodRepository
    {
        private LITSEntities _LITSEntities;

        public PaymentMethodRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_payment_method entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_payment_method entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_payment_method, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_payment_method Get(Expression<Func<m_payment_method, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_payment_method> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_payment_method GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_payment_method GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_payment_method> GetMany(Expression<Func<m_payment_method, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_payment_method> GetPage<TOrder>(Page page, Expression<Func<m_payment_method, bool>> where, Expression<Func<m_payment_method, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_payment_method entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<PaymentMethodViewModel> GetListActiveAll()
        {
            List<m_payment_method> bankHolidayList = _LITSEntities.m_payment_method.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<PaymentMethodViewModel> resultList = new List<PaymentMethodViewModel>();
            foreach (m_payment_method temp in bankHolidayList)
            {
                PaymentMethodViewModel data = Mapper.Map<m_payment_method, PaymentMethodViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PaymentMethodViewModel> GetListActiveById(int? Id)
        {
            List<m_payment_method> bankHolidayList = _LITSEntities.m_payment_method.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<PaymentMethodViewModel> resultList = new List<PaymentMethodViewModel>();
            foreach (m_payment_method temp in bankHolidayList)
            {
                PaymentMethodViewModel data = Mapper.Map<m_payment_method, PaymentMethodViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PaymentMethodViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_payment_method> bankHolidayList = _LITSEntities.m_payment_method.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<PaymentMethodViewModel> resultList = new List<PaymentMethodViewModel>();
            foreach (m_payment_method temp in bankHolidayList)
            {
                PaymentMethodViewModel data = Mapper.Map<m_payment_method, PaymentMethodViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PaymentMethodViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_payment_method> bankHolidayList = _LITSEntities.m_payment_method.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<PaymentMethodViewModel> resultList = new List<PaymentMethodViewModel>();
            foreach (m_payment_method temp in bankHolidayList)
            {
                PaymentMethodViewModel data = Mapper.Map<m_payment_method, PaymentMethodViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PaymentMethodViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_payment_method> bankHolidayList = _LITSEntities.m_payment_method.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<PaymentMethodViewModel> resultList = new List<PaymentMethodViewModel>();
            foreach (m_payment_method temp in bankHolidayList)
            {
                PaymentMethodViewModel data = Mapper.Map<m_payment_method, PaymentMethodViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PaymentMethodViewModel> GetListAll()
        {
            List<m_payment_method> bankHolidayList = _LITSEntities.m_payment_method.ToList();
            List<PaymentMethodViewModel> resultList = new List<PaymentMethodViewModel>();
            foreach (m_payment_method temp in bankHolidayList)
            {
                PaymentMethodViewModel data = Mapper.Map<m_payment_method, PaymentMethodViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PaymentMethodViewModel> GetListById(int? Id)
        {
            List<m_payment_method> bankHolidayList = _LITSEntities.m_payment_method.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<PaymentMethodViewModel> resultList = new List<PaymentMethodViewModel>();
            foreach (m_payment_method temp in bankHolidayList)
            {
                PaymentMethodViewModel data = Mapper.Map<m_payment_method, PaymentMethodViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PaymentMethodViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_payment_method> bankHolidayList = _LITSEntities.m_payment_method.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<PaymentMethodViewModel> resultList = new List<PaymentMethodViewModel>();
            foreach (m_payment_method temp in bankHolidayList)
            {
                PaymentMethodViewModel data = Mapper.Map<m_payment_method, PaymentMethodViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PaymentMethodViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_payment_method> bankHolidayList = _LITSEntities.m_payment_method.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<PaymentMethodViewModel> resultList = new List<PaymentMethodViewModel>();
            foreach (m_payment_method temp in bankHolidayList)
            {
                PaymentMethodViewModel data = Mapper.Map<m_payment_method, PaymentMethodViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PaymentMethodViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_payment_method> bankHolidayList = _LITSEntities.m_payment_method.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<PaymentMethodViewModel> resultList = new List<PaymentMethodViewModel>();
            foreach (m_payment_method temp in bankHolidayList)
            {
                PaymentMethodViewModel data = Mapper.Map<m_payment_method, PaymentMethodViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(PaymentMethodViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<PaymentMethodViewModel, m_payment_method>(model[0]);
                            data.is_active = false;
                            context.m_payment_method.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(PaymentMethodViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_payment_method data = AutoMapper.Mapper.Map<PaymentMethodViewModel, m_payment_method>(objModel);
                        context.m_payment_method.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(PaymentMethodViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_payment_method data = Mapper.Map<PaymentMethodViewModel, m_payment_method>(objModel);
                        context.m_payment_method.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
