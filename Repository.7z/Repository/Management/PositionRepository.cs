﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class PositionRepository : RepositoryBase<PositionViewModel>, IPositionRepository
    {
        private LITSEntities _LITSEntities;

        public PositionRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_position entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_position entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_position, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_position Get(Expression<Func<m_position, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_position> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_position GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_position GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_position> GetMany(Expression<Func<m_position, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_position> GetPage<TOrder>(Page page, Expression<Func<m_position, bool>> where, Expression<Func<m_position, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_position entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<PositionViewModel> GetListActiveAll()
        {
            List<m_position> bankHolidayList = _LITSEntities.m_position.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<PositionViewModel> resultList = new List<PositionViewModel>();
            foreach (m_position temp in bankHolidayList)
            {
                PositionViewModel data = Mapper.Map<m_position, PositionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PositionViewModel> GetListActiveById(int? Id)
        {
            List<m_position> bankHolidayList = _LITSEntities.m_position.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<PositionViewModel> resultList = new List<PositionViewModel>();
            foreach (m_position temp in bankHolidayList)
            {
                PositionViewModel data = Mapper.Map<m_position, PositionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PositionViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_position> bankHolidayList = _LITSEntities.m_position.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<PositionViewModel> resultList = new List<PositionViewModel>();
            foreach (m_position temp in bankHolidayList)
            {
                PositionViewModel data = Mapper.Map<m_position, PositionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PositionViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_position> bankHolidayList = _LITSEntities.m_position.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<PositionViewModel> resultList = new List<PositionViewModel>();
            foreach (m_position temp in bankHolidayList)
            {
                PositionViewModel data = Mapper.Map<m_position, PositionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PositionViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_position> bankHolidayList = _LITSEntities.m_position.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<PositionViewModel> resultList = new List<PositionViewModel>();
            foreach (m_position temp in bankHolidayList)
            {
                PositionViewModel data = Mapper.Map<m_position, PositionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PositionViewModel> GetListAll()
        {
            List<m_position> bankHolidayList = _LITSEntities.m_position.ToList();
            List<PositionViewModel> resultList = new List<PositionViewModel>();
            foreach (m_position temp in bankHolidayList)
            {
                PositionViewModel data = Mapper.Map<m_position, PositionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PositionViewModel> GetListById(int? Id)
        {
            List<m_position> bankHolidayList = _LITSEntities.m_position.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<PositionViewModel> resultList = new List<PositionViewModel>();
            foreach (m_position temp in bankHolidayList)
            {
                PositionViewModel data = Mapper.Map<m_position, PositionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PositionViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_position> bankHolidayList = _LITSEntities.m_position.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<PositionViewModel> resultList = new List<PositionViewModel>();
            foreach (m_position temp in bankHolidayList)
            {
                PositionViewModel data = Mapper.Map<m_position, PositionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PositionViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_position> bankHolidayList = _LITSEntities.m_position.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<PositionViewModel> resultList = new List<PositionViewModel>();
            foreach (m_position temp in bankHolidayList)
            {
                PositionViewModel data = Mapper.Map<m_position, PositionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<PositionViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_position> bankHolidayList = _LITSEntities.m_position.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<PositionViewModel> resultList = new List<PositionViewModel>();
            foreach (m_position temp in bankHolidayList)
            {
                PositionViewModel data = Mapper.Map<m_position, PositionViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(PositionViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<PositionViewModel, m_position>(model[0]);
                            data.is_active = false;
                            context.m_position.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(PositionViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_position data = AutoMapper.Mapper.Map<PositionViewModel, m_position>(objModel);
                        context.m_position.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(PositionViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_position data = Mapper.Map<PositionViewModel, m_position>(objModel);
                        context.m_position.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
