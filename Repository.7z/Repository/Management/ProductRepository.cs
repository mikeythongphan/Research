﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class ProductRepository : RepositoryBase<ProductViewModel>, IProductRepository
    {
        private LITSEntities _LITSEntities;

        public ProductRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_product entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_product entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_product, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_product Get(Expression<Func<m_product, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_product> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_product GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_product GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_product> GetMany(Expression<Func<m_product, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_product> GetPage<TOrder>(Page page, Expression<Func<m_product, bool>> where, Expression<Func<m_product, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_product entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<ProductViewModel> GetListActiveAll()
        {
            List<m_product> ProductList = _LITSEntities.m_product.ToList();
            ProductList = ProductList.Where(p => p.is_active == true).ToList();
            List<ProductViewModel> resultList = new List<ProductViewModel>();
            foreach (m_product temp in ProductList)
            {
                ProductViewModel data = Mapper.Map<m_product, ProductViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ProductViewModel> GetListActiveById(int Id)
        {
            List<m_product> ProductList = _LITSEntities.m_product.ToList();
            ProductList = ProductList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<ProductViewModel> resultList = new List<ProductViewModel>();
            foreach (m_product temp in ProductList)
            {
                ProductViewModel data = Mapper.Map<m_product, ProductViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ProductViewModel> GetListActiveByStatusId(int StatusId)
        {
            List<m_product> ProductList = _LITSEntities.m_product.ToList();
            ProductList = ProductList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<ProductViewModel> resultList = new List<ProductViewModel>();
            foreach (m_product temp in ProductList)
            {
                ProductViewModel data = Mapper.Map<m_product, ProductViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ProductViewModel> GetListActiveByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_product> ProductList = _LITSEntities.m_product.ToList();
            ProductList = ProductList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<ProductViewModel> resultList = new List<ProductViewModel>();
            foreach (m_product temp in ProductList)
            {
                ProductViewModel data = Mapper.Map<m_product, ProductViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ProductViewModel> GetListActiveByTypeId(int TypeId)
        {
            List<m_product> ProductList = _LITSEntities.m_product.ToList();
            ProductList = ProductList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<ProductViewModel> resultList = new List<ProductViewModel>();
            foreach (m_product temp in ProductList)
            {
                ProductViewModel data = Mapper.Map<m_product, ProductViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ProductViewModel> GetListAll()
        {
            List<m_product> ProductList = _LITSEntities.m_product.ToList();
            List<ProductViewModel> resultList = new List<ProductViewModel>();
            foreach (m_product temp in ProductList)
            {
                ProductViewModel data = Mapper.Map<m_product, ProductViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ProductViewModel> GetListById(int Id)
        {
            List<m_product> ProductList = _LITSEntities.m_product.ToList();
            ProductList = ProductList.Where(p => p.pk_id == Id).ToList();
            List<ProductViewModel> resultList = new List<ProductViewModel>();
            foreach (m_product temp in ProductList)
            {
                ProductViewModel data = Mapper.Map<m_product, ProductViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ProductViewModel> GetListByStatusId(int StatusId)
        {
            List<m_product> ProductList = _LITSEntities.m_product.ToList();
            ProductList = ProductList.Where(p => p.fk_status_id == StatusId).ToList();
            List<ProductViewModel> resultList = new List<ProductViewModel>();
            foreach (m_product temp in ProductList)
            {
                ProductViewModel data = Mapper.Map<m_product, ProductViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ProductViewModel> GetListByStatusIdAndTypeId(int StatusId, int TypeId)
        {
            List<m_product> ProductList = _LITSEntities.m_product.ToList();
            ProductList = ProductList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<ProductViewModel> resultList = new List<ProductViewModel>();
            foreach (m_product temp in ProductList)
            {
                ProductViewModel data = Mapper.Map<m_product, ProductViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<ProductViewModel> GetListByTypeId(int TypeId)
        {
            List<m_product> ProductList = _LITSEntities.m_product.ToList();
            ProductList = ProductList.Where(p => p.fk_type_id == TypeId).ToList();
            List<ProductViewModel> resultList = new List<ProductViewModel>();
            foreach (m_product temp in ProductList)
            {
                ProductViewModel data = Mapper.Map<m_product, ProductViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(ProductViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<ProductViewModel, m_product>(model[0]);
                            data.is_active = false;
                            context.m_product.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(ProductViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_product data = AutoMapper.Mapper.Map<ProductViewModel, m_product>(objModel);
                        context.m_product.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(ProductViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_product data = Mapper.Map<ProductViewModel, m_product>(objModel);
                        context.m_product.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
