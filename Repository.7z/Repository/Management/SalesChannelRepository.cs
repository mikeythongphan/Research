﻿using System;
using PagedList;
using AutoMapper;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using LITS.Infrastructure.Context;
using LITS.Infrastructure.Factory;
using LITS.Interface.Repository.Management;
using LITS.Model.Views.Management;

namespace LITS.Data.Repository.Management
{
    public class SalesChannelRepository : RepositoryBase<SalesChannelViewModel>, ISalesChannelRepository
    {
        private LITSEntities _LITSEntities;

        public SalesChannelRepository(IDatabaseFactory databaseFactory, LITSEntities _litsEntities) : base(databaseFactory)
        {
            this._LITSEntities = _litsEntities;
        }

        #region Base

        public void Add(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(Expression<Func<m_sales_channel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public m_sales_channel Get(Expression<Func<m_sales_channel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_sales_channel> GetAll()
        {
            throw new NotImplementedException();
        }

        public m_sales_channel GetById(long id)
        {
            throw new NotImplementedException();
        }

        public m_sales_channel GetById(string id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<m_sales_channel> GetMany(Expression<Func<m_sales_channel, bool>> where)
        {
            throw new NotImplementedException();
        }

        public IPagedList<m_sales_channel> GetPage<TOrder>(Page page, Expression<Func<m_sales_channel, bool>> where, Expression<Func<m_sales_channel, TOrder>> order)
        {
            throw new NotImplementedException();
        }

        public void Update(m_sales_channel entity)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Custom

        public List<SalesChannelViewModel> GetListActiveAll()
        {
            List<m_sales_channel> bankHolidayList = _LITSEntities.m_sales_channel.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true).ToList();
            List<SalesChannelViewModel> resultList = new List<SalesChannelViewModel>();
            foreach (m_sales_channel temp in bankHolidayList)
            {
                SalesChannelViewModel data = Mapper.Map<m_sales_channel, SalesChannelViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SalesChannelViewModel> GetListActiveById(int? Id)
        {
            List<m_sales_channel> bankHolidayList = _LITSEntities.m_sales_channel.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.pk_id == Id).ToList();
            List<SalesChannelViewModel> resultList = new List<SalesChannelViewModel>();
            foreach (m_sales_channel temp in bankHolidayList)
            {
                SalesChannelViewModel data = Mapper.Map<m_sales_channel, SalesChannelViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SalesChannelViewModel> GetListActiveByStatusId(int? StatusId)
        {
            List<m_sales_channel> bankHolidayList = _LITSEntities.m_sales_channel.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId).ToList();
            List<SalesChannelViewModel> resultList = new List<SalesChannelViewModel>();
            foreach (m_sales_channel temp in bankHolidayList)
            {
                SalesChannelViewModel data = Mapper.Map<m_sales_channel, SalesChannelViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SalesChannelViewModel> GetListActiveByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_sales_channel> bankHolidayList = _LITSEntities.m_sales_channel.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<SalesChannelViewModel> resultList = new List<SalesChannelViewModel>();
            foreach (m_sales_channel temp in bankHolidayList)
            {
                SalesChannelViewModel data = Mapper.Map<m_sales_channel, SalesChannelViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SalesChannelViewModel> GetListActiveByTypeId(int? TypeId)
        {
            List<m_sales_channel> bankHolidayList = _LITSEntities.m_sales_channel.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.is_active == true && p.fk_type_id == TypeId).ToList();
            List<SalesChannelViewModel> resultList = new List<SalesChannelViewModel>();
            foreach (m_sales_channel temp in bankHolidayList)
            {
                SalesChannelViewModel data = Mapper.Map<m_sales_channel, SalesChannelViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SalesChannelViewModel> GetListAll()
        {
            List<m_sales_channel> bankHolidayList = _LITSEntities.m_sales_channel.ToList();
            List<SalesChannelViewModel> resultList = new List<SalesChannelViewModel>();
            foreach (m_sales_channel temp in bankHolidayList)
            {
                SalesChannelViewModel data = Mapper.Map<m_sales_channel, SalesChannelViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SalesChannelViewModel> GetListById(int? Id)
        {
            List<m_sales_channel> bankHolidayList = _LITSEntities.m_sales_channel.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.pk_id == Id).ToList();
            List<SalesChannelViewModel> resultList = new List<SalesChannelViewModel>();
            foreach (m_sales_channel temp in bankHolidayList)
            {
                SalesChannelViewModel data = Mapper.Map<m_sales_channel, SalesChannelViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SalesChannelViewModel> GetListByStatusId(int? StatusId)
        {
            List<m_sales_channel> bankHolidayList = _LITSEntities.m_sales_channel.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId).ToList();
            List<SalesChannelViewModel> resultList = new List<SalesChannelViewModel>();
            foreach (m_sales_channel temp in bankHolidayList)
            {
                SalesChannelViewModel data = Mapper.Map<m_sales_channel, SalesChannelViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SalesChannelViewModel> GetListByStatusIdAndTypeId(int? StatusId, int? TypeId)
        {
            List<m_sales_channel> bankHolidayList = _LITSEntities.m_sales_channel.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_status_id == StatusId && p.fk_type_id == TypeId).ToList();
            List<SalesChannelViewModel> resultList = new List<SalesChannelViewModel>();
            foreach (m_sales_channel temp in bankHolidayList)
            {
                SalesChannelViewModel data = Mapper.Map<m_sales_channel, SalesChannelViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public List<SalesChannelViewModel> GetListByTypeId(int? TypeId)
        {
            List<m_sales_channel> bankHolidayList = _LITSEntities.m_sales_channel.ToList();
            bankHolidayList = bankHolidayList.Where(p => p.fk_type_id == TypeId).ToList();
            List<SalesChannelViewModel> resultList = new List<SalesChannelViewModel>();
            foreach (m_sales_channel temp in bankHolidayList)
            {
                SalesChannelViewModel data = Mapper.Map<m_sales_channel, SalesChannelViewModel>(temp);
                resultList.Add(data);
            }
            return resultList;
        }

        public bool Delete(SalesChannelViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        var model = GetListById(objModel.ID);
                        if (model.Count() > 0)
                        {
                            var data = AutoMapper.Mapper.Map<SalesChannelViewModel, m_sales_channel>(model[0]);
                            data.is_active = false;
                            context.m_sales_channel.Attach(data);
                            context.Entry(data).State = EntityState.Modified;
                            context.SaveChanges();

                            transaction.Commit();
                            return true;
                        }
                        return false;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Create(SalesChannelViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_sales_channel data = AutoMapper.Mapper.Map<SalesChannelViewModel, m_sales_channel>(objModel);
                        context.m_sales_channel.Add(data);
                        //  context.Entry(data).State = EntityState.Added;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }

        public bool Update(SalesChannelViewModel objModel)
        {
            using (var context = new LITSEntities())
            {
                using (DbContextTransaction transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        m_sales_channel data = Mapper.Map<SalesChannelViewModel, m_sales_channel>(objModel);
                        context.m_sales_channel.Attach(data);
                        context.Entry(data).State = EntityState.Modified;
                        context.SaveChanges();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
            }

        }
        #endregion
    }
}
