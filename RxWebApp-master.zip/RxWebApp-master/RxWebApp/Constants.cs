﻿using System;

namespace RxWebApp
{
    public static class Constants
    {
        public static readonly TimeSpan DefaultTimeout = TimeSpan.FromSeconds(60);
    }
}