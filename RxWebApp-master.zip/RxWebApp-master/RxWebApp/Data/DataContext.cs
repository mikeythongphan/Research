﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace RxWebApp.Data
{
    public class DataContext : IdentityDbContext<User>
    {
         
    }
}
