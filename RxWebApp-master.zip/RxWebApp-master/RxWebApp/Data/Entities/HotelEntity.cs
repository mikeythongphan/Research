﻿namespace RxWebApp.Data.Entities
{
    internal class HotelEntity : Entity
    {
        public string Name { get; set; }

        public string City { get; set; }

        public string Description { get; set; }
    }
}
