﻿using RxWebApp.Data.Entities;

namespace RxWebApp.Data
{
    internal interface IEntityRepository<T> where T : Entity
    {
    }
}