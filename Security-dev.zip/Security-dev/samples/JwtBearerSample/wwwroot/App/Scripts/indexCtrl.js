﻿'use strict';
angular.module('todoApp')
.controller('indexCtrl', ['$scope', 'adalAuthenticationService', function ($scope, adalService) {

}]);