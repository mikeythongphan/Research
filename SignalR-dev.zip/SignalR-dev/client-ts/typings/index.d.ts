/// <reference path="globals/jasmine/index.d.ts" />
/// <reference path="globals/EventSource/EventSource.d.ts" />
