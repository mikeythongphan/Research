﻿using System;

namespace TasksProject.Shared.Attributes
{
    [AttributeUsage(AttributeTargets.Parameter)]
    public class NotNullAttribute : Attribute
    {
    }
}
